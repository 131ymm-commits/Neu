-- Витрина Magnetics для графического клиента: /magnetics-showroom ставит все 26 построек рядом с ванильными основами
-- на отдельной поверхности и делает снимки в script-output/magnetics/. В обычную игру не влияет (ничего не делает без команды).
local showroom = require("showroom")
commands.add_command("magnetics-showroom", "Magnetics: витрина всех 26 построек рядом с ванильными основами", function(cmd)
  local p = cmd.player_index and game.get_player(cmd.player_index)
  local r = showroom.build { player_index = cmd.player_index, force = p and p.force or "player", teleport = true }
  ;(p or game).print("magnetics-showroom: построек " .. r.count .. "/26, основ " .. r.base_count .. "/26, ошибок " .. #r.errors .. ", снимков " .. r.screenshots)
end)
