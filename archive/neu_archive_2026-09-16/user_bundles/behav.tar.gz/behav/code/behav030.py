"""
BEHAV-030 / AJ1 — возвращается ли утраченное содержание в LTEE?
Ворота пройдены (gate.py), предрегистрация в PREREG.md.
"""
import numpy as np
D = "/home/claude/ltee/data_files"
NON = ['m5', 'm6', 'p1', 'p2', 'p4', 'p5']
F_, E_ = 2, 1


def load(pop):
    st = []
    with open(f"{D}/{pop}_well_mixed_state_timecourse.txt") as fh:
        fh.readline(); fh.readline()
        for l in fh:
            v = [x for x in l.rstrip("\n").rstrip(",").split(",") if x.strip()]
            try: st.append([int(float(x)) for x in v])
            except ValueError: pass
    pos, gene = [], []
    with open(f"{D}/{pop}_annotated_timecourse.txt") as fh:
        fh.readline()
        for l in fh:
            p = l.split(", ")
            if len(p) >= 15:
                pos.append(int(p[0])); gene.append(p[1].strip())
    n = min(len(st), len(pos))
    return st[:n], pos[:n], gene[:n]


def events(pop):
    """Для каждой мутации: время первого F, время утраты (F->E), есть ли утрата."""
    st, pos, gene = load(pop)
    out = []
    for s, p, g in zip(st, pos, gene):
        if not g or g in ("intergenic", "."):
            continue
        a = np.array(s)
        fi = np.where(a == F_)[0]
        if len(fi) == 0:
            continue
        t_fix = int(fi[0])
        lost = np.where((a[:-1] == F_) & (a[1:] == E_))[0]
        out.append(dict(gene=g, pos=p, t_fix=t_fix,
                        t_lost=int(lost[0]) if len(lost) else None))
    return out


def analyse(pop, win=5000):
    ev = events(pop)
    lost = [e for e in ev if e["t_lost"] is not None]
    kept = [e for e in ev if e["t_lost"] is None]
    def later_same_gene(e):
        return any(o["gene"] == e["gene"] and o["t_fix"] > e["t_lost"] for o in ev)
    def later_neighbour(e):
        return any(o["gene"] != e["gene"] and abs(o["pos"] - e["pos"]) <= win
                   and o["t_fix"] > e["t_lost"] for o in ev)
    def later_after_fix_same(e):
        return any(o is not e and o["gene"] == e["gene"] and o["t_fix"] > e["t_fix"]
                   for o in ev)
    r_same = np.mean([later_same_gene(e) for e in lost]) if lost else np.nan
    r_nb = np.mean([later_neighbour(e) for e in lost]) if lost else np.nan
    r_base = np.mean([later_after_fix_same(e) for e in kept]) if kept else np.nan
    return len(ev), len(lost), r_same, r_nb, r_base


if __name__ == "__main__":
    print(f"{'поп':>4}{'закрепл.':>10}{'утрачено':>10}{'ВОЗВРАТ в тот же ген':>22}"
          f"{'K2 соседи <5кб':>16}{'K1 база':>10}")
    S, N, B, W = [], [], [], []
    for pop in NON:
        n, nl, rs, rn, rb = analyse(pop)
        S.append(rs); N.append(rn); B.append(rb); W.append(nl)
        print(f"{pop:>4}{n:>10}{nl:>10}{rs:>22.3f}{rn:>16.3f}{rb:>10.3f}", flush=True)
    S, N, B, W = map(np.array, (S, N, B, W))
    print(f"\n  взвеш. по числу утрат:  тот же ген {np.average(S,weights=W):.3f}"
          f"   соседи {np.average(N,weights=W):.3f}"
          f"   база {np.average(B,weights=W):.3f}")
    print(f"  ПРОГНОЗ: возврат > 0.2 И вдвое выше соседей")
    print(f"  УСЛОВИЕ СМЕРТИ: возврат ~ соседи -> это сцепление")
