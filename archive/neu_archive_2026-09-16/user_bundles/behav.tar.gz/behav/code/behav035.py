"""BEHAV-035 / AO1(в) — объясняет ли АВТОР падение возврата с глубиной?"""
import numpy as np
import behav031 as B

BINS = [(0, 1, "<1д"), (1, 3, "1-3д"), (3, 10, "3-10д"), (10, 1e9, ">10д")]


def build(path="/home/claude/pt_log2.txt"):
    rows = []
    for l in open(path, encoding="utf-8", errors="replace"):
        p = l.rstrip("\n").split("|", 3)
        if len(p) == 4: rows.append((p[0], int(p[1]), p[2], p[3]))
    rows.sort(key=lambda r: r[1])
    ts = [r[1] for r in rows]; au = [r[2] for r in rows]; subj = [r[3] for r in rows]
    key = [B.norm(s) for s in subj]
    idx = {}
    for i, k in enumerate(key): idx.setdefault(k, []).append(i)
    rel = {}
    for i, s in enumerate(subj):
        m = B.RELAND.match(s.strip())
        if m and m.group(1): rel.setdefault(B.norm(m.group(1)), []).append(i)
    out = []
    for i, s in enumerate(subj):
        m = B.REV.match(s.strip())
        if not m: continue
        o = B.norm(m.group(1))
        pre = [j for j in idx.get(o, []) if j < i]
        if not pre: continue
        p0 = max(pre)
        post = [j for j in idx.get(o, []) if j > i] + [j for j in rel.get(o, []) if j > i]
        out.append(dict(back=bool(post), life=(ts[i]-ts[p0])/86400.0,
                        same=au[i] == au[p0],
                        back_same=bool(post) and au[min(post)] == au[p0]))
    return out


def curve(g, f="back"):
    c = []
    for a, b, _ in BINS:
        gg = [o for o in g if a <= o["life"] < b]
        c.append(f"{np.mean([x[f] for x in gg]):.3f}({len(gg)})" if len(gg) >= 20 else "—")
    return c


if __name__ == "__main__":
    out = build()
    same = [o for o in out if o["same"]]; diff = [o for o in out if not o["same"]]
    print(f"откатов: {len(out)}   автор отката = автор оригинала: "
          f"{len(same)} ({len(same)/len(out):.2f})")
    print(f"\n  ВОЗВРАТ: свой откат {np.mean([o['back'] for o in same]):.3f}   "
          f"чужой откат {np.mean([o['back'] for o in diff]):.3f}")
    print(f"  доля возвратов, сделанных автором оригинала: "
          f"{np.mean([o['back_same'] for o in out if o['back']]):.3f}")
    print(f"\n=== меняется ли ДОЛЯ СВОИХ ОТКАТОВ с глубиной? ===")
    print(f"{'':<20}" + "".join(f"{t:>13}" for _, _, t in BINS))
    print(f"{'доля своих':<20}" + "".join(f"{c:>13}" for c in curve(out, "same")))
    print(f"\n=== выживает ли падение ВНУТРИ групп по автору? ===")
    print(f"{'свой откат':<20}" + "".join(f"{c:>13}" for c in curve(same)))
    print(f"{'чужой откат':<20}" + "".join(f"{c:>13}" for c in curve(diff)))
