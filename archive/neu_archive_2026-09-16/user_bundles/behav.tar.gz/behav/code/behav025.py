"""
BEHAV-025 / AC1+AC2 — развести частоту сбоев и уровень удержания.

Проблема BEHAV-024: flip и |m| задаются одними (eps, mu) и не разделяются,
поэтому AB2 («Delta не объясняется уровнем удержания») недоказан.

Развязка: АСИММЕТРИЧНЫЙ шум. Испорченный носитель принимает 1 с
вероятностью (1+bias)/2 вместо 1/2. Смещение поднимает |m| и РЕЗКО
давит частоту переворотов, не меняя интенсивность порчи eps.
=> два рычага вместо одного: eps/mu двигают |m|, bias двигает flip.

ПРЕДРЕГИСТРАЦИЯ:
  AD1 при фиксированном |m| (подобраны eps,mu) рост bias снижает flip
  AD2 при фиксированном |m| Delta падает вместе с flip
      => AB2 ДОКАЗАН: дело в сбоях, а не в уровне
  AD3 если Delta держится при падающем flip и фиксированном |m| —
      наш тезис ОПРОВЕРГНУТ, дело в уровне удержания
  AD4 окно наблюдаемости в осях (flip, |m|) — связная полоса, а не
      произвольное пятно
"""
import numpy as np


def series(N, eps, mu, mode, T, bias=0.0, seed=0, burn=400):
    rng = np.random.default_rng(seed)
    s = np.ones(N, bool)
    p1 = (1.0 + bias) / 2.0
    S = np.empty(T); A = np.empty(T)
    for t in range(T + burn):
        before = s.copy()
        nz = rng.random(N) < eps
        if nz.any():
            s[nz] = rng.random(int(nz.sum())) < p1
        if mu > 0:
            fix = rng.random(N) < mu
            s[fix] = True if mode == "ext" else (s.sum() * 2 > N)
        if t >= burn:
            i = t - burn
            S[i] = 2 * s.mean() - 1
            A[i] = (s != before).mean()
    return S, A


def gF(y, x, p=4):
    n = len(y) - p
    Y = y[p:]
    Ly = np.column_stack([y[p - k - 1:-k - 1] for k in range(p)])
    Lx = np.column_stack([x[p - k - 1:-k - 1] for k in range(p)])
    def rss(D):
        D = np.column_stack([np.ones(n), D])
        b, *_ = np.linalg.lstsq(D, Y, rcond=None)
        r = Y - D @ b
        return float(r @ r)
    a, u = rss(Ly), rss(np.column_stack([Ly, Lx]))
    return max(((a - u) / p) / (u / (n - 2 * p - 1)), 0.0)


def stats(N, eps, mu, bias, T=3000, seeds=7):
    res = {}
    for mode in ("ext", "template"):
        rr, mm, ff = [], [], []
        for sd in range(seeds):
            S, A = series(N, eps, mu, mode, T, bias=bias, seed=sd)
            dS, dA = np.diff(S), np.diff(A)
            f_as, f_sa = gF(dS, dA), gF(dA, dS)
            lo, hi = min(f_as, f_sa), max(f_as, f_sa)
            rr.append(lo / hi if hi > 0 else np.nan)
            mm.append(np.mean(np.abs(S)))
            sg = np.sign(S); sg[sg == 0] = 1
            ff.append(float(np.mean(sg[1:] != sg[:-1])))
        res[mode] = (float(np.nanmedian(rr)), float(np.mean(mm)), float(np.mean(ff)))
    d = res["template"][0] - res["ext"][0]
    return d, res["template"][2], res["template"][1]


if __name__ == "__main__":
    N = 101
    print("=== AD1/AD2: смещение при примерно фиксированном |m| ===")
    print(f"{'eps':>6}{'mu':>6}{'bias':>7}{'flip':>9}{'|m|':>7}{'Delta':>9}")
    for eps, mu in ((0.45, 0.05), (0.35, 0.05), (0.45, 0.10)):
        for bias in (0.0, 0.05, 0.10, 0.20, 0.35):
            d, f, m = stats(N, eps, mu, bias)
            print(f"{eps:>6.2f}{mu:>6.2f}{bias:>7.2f}{f:>9.4f}{m:>7.2f}{d:>9.3f}",
                  flush=True)
        print()
