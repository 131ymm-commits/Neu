"""
BEHAV-017 / M1+M2 — экспонента как подпись механизма: прямой тест.

Гипотеза M1: a в mu_c ~ N^(-a) задаётся законом агрегации коррекции.
Четыре ЧИСТЫХ механизма (один бит, N носителей, симметричный шум eps):

  ext     каждый чинящийся носитель ставится по внешнему эталону
  global  по глобальному большинству (наша старая модель)
  sample  по большинству СЛУЧАЙНОЙ ВЫБОРКИ из k=3 других носителей
  voter   копирует ОДНОГО случайного другого (модель избирателя / Кирман)

ПРЕДРЕГИСТРАЦИЯ (до прогона):
  N1 ext:    a ~ 0   (порог не зависит от N)
  N2 voter:  a ~ -1  (!!) mu_c РАСТЁТ с N: по Кирману консенсус держится
             при eps < mu/N, т.е. mu_c ~ N * eps. Парное копирование
             ХУЖЕ масштабируется, чем глобальное большинство.
  N3 sample(k=3): между global и voter, ближе к нулю.
  N4 global (M2): локальный наклон |a| ПАДАЕТ с ростом N (кроссовер,
             объясняющий 0.81 как среднее по диапазону).
  N5 НИ ОДИН дискретный механизм не даст a=0.5. Если так — гипотеза
     «0.5 = усреднение» в дискретной форме мертва; уточнение M1':
     0.5 требует НЕПРЕРЫВНОГО состояния (ошибка выборочного среднего ~ 1/sqrt).
"""
import sys
import numpy as np


def hold(N, eps, mu, steps, mech, seed=0, k=3):
    rng = np.random.default_rng(seed)
    s = np.ones(N, bool)
    for t in range(steps):
        nz = rng.random(N) < eps
        if nz.any():
            s[nz] = rng.random(int(nz.sum())) < 0.5
        if mu > 0:
            fix = rng.random(N) < mu
            nf = int(fix.sum())
            if nf:
                if mech == "ext":
                    s[fix] = True
                elif mech == "global":
                    s[fix] = s.sum() * 2 > N
                elif mech == "voter":
                    src = s.copy()
                    s[fix] = src[rng.integers(0, N, nf)]
                elif mech == "sample":
                    src = s.copy()
                    sm = src[rng.integers(0, N, (nf, k))].sum(1) * 2 > k
                    s[fix] = sm
        if s.sum() * 2 <= N:
            return t
    return steps


def mu_c(N, mech, eps=0.05, T=2000, seeds=7, hi=1.0):
    lo = 0.0
    for _ in range(11):
        mid = (lo + hi) / 2
        t = np.median([hold(N, eps, mid, T, mech, seed=s) for s in range(seeds)])
        if t >= T:
            hi = mid
        else:
            lo = mid
    return hi


if __name__ == "__main__":
    mech = sys.argv[1]
    Ns = [11, 21, 41, 81, 161, 321] if len(sys.argv) < 3 else \
         [int(x) for x in sys.argv[2].split(",")]
    out = []
    for N in Ns:
        m = mu_c(N, mech)
        out.append((N, m))
        print(f"  N={N:>5}  mu_c={m:.4f}", flush=True)
    x = np.log([o[0] for o in out]); y = np.log([max(o[1], 1e-6) for o in out])
    a = -np.polyfit(x, y, 1)[0]
    print(f"{mech}: a = {a:+.2f}   (mu_c ~ N^-a)")
    if len(out) >= 4:
        h = len(out) // 2
        a1 = -np.polyfit(x[:h + 1], y[:h + 1], 1)[0]
        a2 = -np.polyfit(x[h:], y[h:], 1)[0]
        print(f"{mech}: локальные наклоны: низ {a1:+.2f}, верх {a2:+.2f}")
