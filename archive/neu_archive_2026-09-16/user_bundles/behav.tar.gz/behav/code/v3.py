import sys, os, numpy as np, behav020 as B
def slam_k(N,k,target=0.75,seeds=41):
    lo,hi=1,1024
    while lo<hi:
        mid=(lo+hi)//2; ok=0
        for sd in range(seeds):
            rng=np.random.default_rng(sd); s=np.ones(N,bool)
            s=B.phase(N,0.05,0.25,'sample',800,rng,s,k=k)
            s=B.phase(N,0.05,0.0,'sample',mid,rng,s,k=k)
            s=B.phase(N,0.05,0.25,'sample',800,rng,s,k=k)
            ok+=(s.sum()*2>N)
        if ok/seeds>target: lo=mid+1
        else: hi=mid
    return lo
k=int(sys.argv[1]); f=f"/home/claude/v3_{k}.txt"
if not os.path.exists(f):
    open(f,'w').write(str(slam_k(81,k)))
print(k, open(f).read())
