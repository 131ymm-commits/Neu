"""BEHAV-033 / AM1 — объясняет ли ПРИЧИНА отката и возврат, и падение с глубиной?"""
import re
import numpy as np
import behav031 as B
import behav032 as C

TRANS = re.compile(r'\b(build|ci|test|tests|lint|compil\w*|broke|broken|breakage|'
                   r'failing|failure|flaky|timeout|sanitiz\w*|green|red|'
                   r'internal[- ]?error)\b', re.I)
SUBST = re.compile(r'\b(wrong|incorrect|bad|regress\w*|perf\w*|slow\w*|design|'
                   r'approach|requirement|unnecessary|not needed|revisit|'
                   r'discuss\w*|premature|nack)\b', re.I)


def classify(msg):
    t, s = bool(TRANS.search(msg)), bool(SUBST.search(msg))
    if t and not s: return "транз."
    if s and not t: return "сущест."
    if t and s: return "оба"
    return "нет метки"


def run(path, label):
    rows = []
    for l in open(path, encoding="utf-8", errors="replace"):
        p = l.rstrip("\n").split("|", 2)
        if len(p) == 3: rows.append((p[0], int(p[1]), p[2]))
    rows.sort(key=lambda r: r[1])
    subj = [r[2] for r in rows]; ts = [r[1] for r in rows]
    key = [B.norm(s) for s in subj]
    idx = {}
    for i, k in enumerate(key): idx.setdefault(k, []).append(i)
    rel = {}
    for i, s in enumerate(subj):
        m = B.RELAND.match(s.strip())
        if m and m.group(1): rel.setdefault(B.norm(m.group(1)), []).append(i)
    out = []
    for i, s in enumerate(subj):
        m = B.REV.match(s.strip())
        if not m: continue
        o = B.norm(m.group(1))
        pre = [j for j in idx.get(o, []) if j < i]
        post = [j for j in idx.get(o, []) if j > i] + [j for j in rel.get(o, []) if j > i]
        out.append(dict(back=bool(post), cls=classify(s),
                        life=(ts[i]-ts[max(pre)])/86400.0 if pre else None))
    print(f"\n=== {label}: возврат по ПРИЧИНЕ отката ===")
    print(f"{'класс':<12}{'n':>7}{'доля':>8}{'ВОЗВРАТ':>10}{'мед.жизнь,д':>13}")
    for c in ("транз.", "сущест.", "оба", "нет метки"):
        g = [o for o in out if o["cls"] == c]
        if not g: continue
        lv = [o["life"] for o in g if o["life"] is not None]
        print(f"{c:<12}{len(g):>7}{len(g)/len(out):>8.2f}"
              f"{np.mean([o['back'] for o in g]):>10.3f}"
              f"{np.median(lv) if lv else float('nan'):>13.2f}")
    print(f"\n  КОНТРОЛЬ: выживает ли падение с глубиной ВНУТРИ класса?")
    print(f"{'класс':<12}{'<1д':>10}{'1-3д':>10}{'3-10д':>10}{'>10д':>10}")
    for c in ("транз.", "сущест.", "нет метки"):
        g = [o for o in out if o["cls"] == c and o["life"] is not None]
        if len(g) < 40: continue
        cells = []
        for a, b in ((0, 1), (1, 3), (3, 10), (10, 1e9)):
            gg = [o for o in g if a <= o["life"] < b]
            cells.append(f"{np.mean([x['back'] for x in gg]):.3f}({len(gg)})"
                         if len(gg) >= 15 else "—")
        print(f"{c:<12}" + "".join(f"{x:>10}" for x in cells))
    return out


if __name__ == "__main__":
    run("/home/claude/pt_log.txt", "pytorch")
    run("/home/claude/node_log.txt", "node")
