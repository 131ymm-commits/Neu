"""
BEHAV-004 — конструктивное направление и тест самодостаточности.

До сих пор все утверждения были запрещающими. Здесь первое конструктивное:
существует инвариант, который R2 не может удержать НИ ПРИ КАКИХ ресурсах,
а R3 удерживает.

Инвариант: ВЫРОЖДЕННЫЙ выбор. Бит b in {0,1}, законы симметричны — ничто
снаружи не говорит, какое значение "правильное". Это спонтанно нарушенная
симметрия (гомохиральность), а не навязанная.

Три механизма удержания:
  none      симметричный шум, коррекции нет            -> R2 без ресурса
  ext       починка по ВНЕШНЕМУ эталону                -> R2 с внешним эталоном
  template  переписывание по большинству носителей     -> R3, эталон внутри

ПРЕДРЕГИСТРАЦИЯ (до прогона):
  P6  none: m -> 0 за время ~1/eps, НЕ зависит от N. H6 теряется всегда.
  P7  ext:  m держится; но при ОТКЛЮЧЕНИИ эталона схлопывается как none.
  P8  template: m держится выше порога БЕЗ внешнего эталона; отключение
      внешнего входа не влияет вообще.
  P9  время удержания H6: плоское по N у R2, растущее по N у R3.
  P10 порог по mu у template движется вниз с ростом N (как в BEHAV-002).
"""
import numpy as np

EPS_DEF = 0.02
G_CRIT = 0.20          # поведенческий порог, измерен в BEHAV-003 (k_deep/k0)


def carrier_traj(N, eps, mu, mode, steps, seed=0, cut_at=None):
    """
    Симметричный шум: с вероятностью eps носитель принимает СЛУЧАЙНЫЙ бит
    (а не портится в заданную сторону) — законы не выделяют направления.
    cut_at: шаг, на котором пропадает внешний эталон (только для mode='ext').
    Возвращает траекторию параметра порядка m = 2*<s> - 1.
    """
    rng = np.random.default_rng(seed)
    s = np.ones(N, bool)                      # исходный выбор: все 1
    m = np.empty(steps)
    for k in range(steps):
        nz = rng.random(N) < eps
        if nz.any():
            s[nz] = rng.random(int(nz.sum())) < 0.5      # симметричный шум
        if mu > 0:
            if mode == "ext":
                if cut_at is None or k < cut_at:
                    fix = rng.random(N) < mu
                    s[fix] = True                        # эталон снаружи: "1"
            elif mode == "template":
                maj = s.sum() * 2 > N
                fix = rng.random(N) < mu
                s[fix] = maj                             # эталон внутри
        m[k] = 2.0 * s.mean() - 1.0
    return m


def hold_time(N, eps, mu, mode, steps, seeds=9, cut_at=None):
    """Первый шаг, на котором g = max(0,m) падает ниже поведенческого порога."""
    out = []
    for sd in range(seeds):
        m = carrier_traj(N, eps, mu, mode, steps, seed=sd, cut_at=cut_at)
        g = np.maximum(m, 0.0)
        below = np.where(g < G_CRIT)[0]
        out.append(int(below[0]) if len(below) else steps)
    return float(np.median(out))


if __name__ == "__main__":
    EPS, STEPS = EPS_DEF, 4000

    print("=== P6/P9: время удержания H6 в шагах (потолок 4000) ===")
    print(f"порог поведения g_c={G_CRIT} (измерен в BEHAV-003), eps={EPS}")
    print(f"{'механизм':<26}" + "".join(f"{'N='+str(n):>9}" for n in (11, 41, 161, 641)))
    rows = [("none  (R2, без коррекции)", "none", 0.0),
            ("ext   (R2, эталон снаружи) mu=.05", "ext", 0.05),
            ("ext   (R2, эталон снаружи) mu=.20", "ext", 0.20),
            ("templ (R3, эталон внутри)  mu=.05", "template", 0.05),
            ("templ (R3, эталон внутри)  mu=.20", "template", 0.20)]
    for lab, mode, mu in rows:
        vals = [hold_time(n, EPS, mu, mode, STEPS) for n in (11, 41, 161, 641)]
        print(f"{lab:<26}" + "".join(f"{int(v):>9}" for v in vals))

    print("\n=== P7/P8: отключение ВНЕШНЕГО эталона на шаге 400 ===")
    print("m(t) до и после отключения, N=161, mu=0.20")
    for mode in ("ext", "template"):
        m = carrier_traj(161, EPS, 0.20, mode, 1600, seed=0, cut_at=400)
        pts = [0, 200, 399, 450, 600, 900, 1300, 1599]
        print(f"  {mode:<9}" + "".join(f"{m[p]:>8.3f}" for p in pts))
    print("  шаги:    " + "".join(f"{p:>8}" for p in [0, 200, 399, 450, 600, 900, 1300, 1599]))

    print("\n=== P10: порог по mu у template, зависимость от N ===")
    print(f"{'mu':>6}" + "".join(f"{'N='+str(n):>9}" for n in (11, 41, 161, 641)))
    for mu in (0.0, 0.02, 0.04, 0.06, 0.10, 0.15, 0.25):
        vals = [hold_time(n, EPS, mu, "template", STEPS) for n in (11, 41, 161, 641)]
        print(f"{mu:>6.2f}" + "".join(f"{int(v):>9}" for v in vals))
