"""BEHAV-037 / AQ1 — падение с глубиной: только на ВНЕШНИХ откатах?
Учтён п.5 списка: откат отката = возврат."""
import re
import numpy as np
import behav031 as B

RR = re.compile(r'^Revert\s+"Revert\s', re.I)
BINS = [(0, 1, "<1д"), (1, 3, "1-3д"), (3, 10, "3-10д"), (10, 1e9, ">10д")]


def build(path):
    rows = []
    for l in open(path, encoding="utf-8", errors="replace"):
        p = l.rstrip("\n").split("|", 3)
        if len(p) == 4: rows.append((p[0], int(p[1]), p[2], p[3]))
    rows.sort(key=lambda r: r[1])
    ts = [r[1] for r in rows]; au = [r[2] for r in rows]; subj = [r[3] for r in rows]
    key = [B.norm(s) for s in subj]
    idx, rel, rrv = {}, {}, {}
    for i, k in enumerate(key): idx.setdefault(k, []).append(i)
    for i, s in enumerate(subj):
        m = B.RELAND.match(s.strip())
        if m and m.group(1): rel.setdefault(B.norm(m.group(1)), []).append(i)
        if RR.match(s.strip()):                     # п.5: откат отката = ВОЗВРАТ
            inner = B.REV.match(s.strip())
            if inner:
                m2 = B.REV.match(inner.group(1).strip())
                if m2: rrv.setdefault(B.norm(m2.group(1)), []).append(i)
    out = []
    for i, s in enumerate(subj):
        if RR.match(s.strip()):                     # сам не считается откатом
            continue
        m = B.REV.match(s.strip())
        if not m: continue
        o = B.norm(m.group(1))
        pre = [j for j in idx.get(o, []) if j < i]
        if not pre: continue
        p0 = max(pre)
        post = [j for j in idx.get(o, []) if j > i] + \
               [j for j in rel.get(o, []) if j > i] + \
               [j for j in rrv.get(o, []) if j > i]
        out.append(dict(back=bool(post), life=(ts[i]-ts[p0])/86400.0,
                        ext=au[i] != au[p0]))
    return out


def curve(g):
    c = []
    for a, b, _ in BINS:
        gg = [o for o in g if a <= o["life"] < b]
        c.append(f"{np.mean([x['back'] for x in gg]):.3f}({len(gg)})"
                 if len(gg) >= 20 else "—")
    return c


if __name__ == "__main__":
    for nm, p in (("pytorch", "/home/claude/pt_log2.txt"),
                  ("node", "/home/claude/node_log2.txt"),
                  ("django", "/home/claude/django_log2.txt")):
        o = build(p)
        e = [x for x in o if x["ext"]]; s = [x for x in o if not x["ext"]]
        print(f"\n=== {nm}: откатов {len(o)} (внешних {len(e)}, самооткатов {len(s)})")
        print(f"  возврат: внешние {np.mean([x['back'] for x in e]) if e else float('nan'):.3f}"
              f"   самооткаты {np.mean([x['back'] for x in s]) if s else float('nan'):.3f}")
        print(f"  {'':<14}" + "".join(f"{t:>13}" for _, _, t in BINS))
        print(f"  {'внешние':<14}" + "".join(f"{c:>13}" for c in curve(e)))
        if len(s) >= 40:
            print(f"  {'самооткаты':<14}" + "".join(f"{c:>13}" for c in curve(s)))
