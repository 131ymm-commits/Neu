"""
BEHAV-019 — ТЕОРИЯ ОШИБОК: асимметрия потери и возврата.

Смена хребта: смотрим не на удержание, а на ПОЛОМКУ.
Гипотеза (предрегистрируется): уровни различаются тем, КАК держат,
но сходятся тем, КАК ломаются — поломка есть ХРАПОВИК (необратимое
накопление), даже когда механизмы удержания разные.

Операционально различаем ДВЕ вещи, которые обычно смешивают:
  СПОСОБНОСТЬ держать  — вернётся ли система в поляризованное состояние
  СОДЕРЖАНИЕ           — вернётся ли ИМЕННО ИСХОДНЫЙ выбор

ПРЕДРЕГИСТРАЦИЯ:
  S1 template: способность возвращается, СОДЕРЖАНИЕ — с вероятностью 1/2
     (симметричный шум не помнит, куда было). Храповик по содержанию.
  S2 ext: возвращается И способность, И содержание (эталон помнит).
     НЕ храповик.
  S3 => R2-ext ломается ОБРАТИМО, R3-template ломается НЕОБРАТИМО.
     Это подпись ПОЛОМКИ, различающая механизмы — второй интервенционный
     тест после отключения эталона, и он не требует ничего отключать.
  S4 асимметрия: T_возврата_содержания >> T_потери у template.
"""
import numpy as np


def run(N, eps, mu, mode, steps, seed=0, start=None):
    rng = np.random.default_rng(seed)
    s = np.ones(N, bool) if start is None else start.copy()
    tr = np.empty(steps)
    for t in range(steps):
        nz = rng.random(N) < eps
        if nz.any():
            s[nz] = rng.random(int(nz.sum())) < 0.5
        if mu > 0:
            fix = rng.random(N) < mu
            if mode == "ext":
                s[fix] = True
            elif mode == "template":
                s[fix] = s.sum() * 2 > N
        tr[t] = 2 * s.mean() - 1
    return tr, s


def experiment(mode, N=101, eps=0.05, mu=0.25, T1=4000, T2=4000, seeds=41):
    """Фаза 1: держим. Фаза 2: ЛОМАЕМ (mu=0 на время slam). Фаза 3: чиним."""
    lose, cap, cont = [], [], []
    for sd in range(seeds):
        tr, s = run(N, eps, mu, mode, T1, seed=sd)              # держит
        held = tr[-1]
        tr2, s2 = run(N, eps, 0.0, mode, 300, seed=sd + 999, start=s)  # поломка
        broke = tr2[-1]
        lose.append(abs(held) - abs(broke))
        tr3, s3 = run(N, eps, mu, mode, T2, seed=sd + 555, start=s2)   # починка
        cap.append(abs(tr3[-1]))               # вернулась ли СПОСОБНОСТЬ
        cont.append(np.sign(tr3[-1]) > 0)      # вернулось ли СОДЕРЖАНИЕ
    return (float(np.mean(lose)), float(np.mean(cap)),
            float(np.mean(cont)), float(np.mean([abs(x) for x in lose])))


if __name__ == "__main__":
    print("=== S1-S3: обратимость поломки ===")
    print("фазы: держим 4000 -> ломаем 300 (коррекция off) -> чиним 4000")
    print(f"{'режим':<10}{'|m| после починки':>19}{'содержание вернулось':>23}")
    for mode in ("ext", "template"):
        _, cap, cont, _ = experiment(mode)
        print(f"{mode:<10}{cap:>19.3f}{cont*100:>22.0f}%")
    print("\nпрогноз: ext -> ~100% (эталон помнит), template -> ~50% (не помнит)")
