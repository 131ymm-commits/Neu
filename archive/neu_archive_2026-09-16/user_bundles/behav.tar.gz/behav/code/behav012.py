"""
BEHAV-012 — чёрные ящики: что заставляет систему СИДЕТЬ на границе.

Рамка даёт потолок. Реальность на потолке (u*G ~ 0.003 постоянно, РНК-вирусы
на пределе Эйгена). Насыщения в рамке нет. Добавляю ящики до работоспособности,
затем снимаю по одному — минимальное описание.

ЯЩИКИ:
  X_self  корректор занимает геномное место, которое САМО требует поддержания
          (самореференция фон Неймана; у нас же — критерий самодостаточности)
  X_cost  метаболическая цена точности (корректор надо кормить)
  X_drift конечная Ne: отбор не различает выигрыш меньше 1/Ne (барьер дрейфа)

МОДЕЛЬ: линии с наследуемым вложением в точность f.
  e(f)  = e0 * exp(-f/f0)                 частота ошибок на основание
  Ltot  = L + X_self * f * gsize          что надо поддерживать
  U     = e(f) * Ltot                     геномная нагрузка
  w     = exp(-U - X_cost*f)              приспособленность
  Райт-Фишер с размером Ne (X_drift)

ЦЕЛИ: T_A U оседает на конечном ненулевом; T_B U не зависит от L (Дрейк).

ПРЕДРЕГИСТРАЦИЯ:
  G1 все три ящика -> T_A и T_B выполнены
  G2 без X_cost    -> U -> 0, если X_self не удержит
  G3 без X_drift   -> U -> 0
  G4 минимальный рабочий набор = 2 ящика; ставлю на {X_drift, X_cost},
     X_self — костыль
"""
import numpy as np

E0, F0, GSIZE, SIGMA, GEN = 1e-3, 3.0, 300.0, 0.06, 3000
COST = 2e-3


def evolve(L, x_self, x_cost, Ne, seed=0, gen=GEN):
    rng = np.random.default_rng(seed)
    f = np.full(Ne, 3.0)
    hist = []
    for g in range(gen):
        f = np.clip(f + rng.normal(0, SIGMA, Ne), 0.0, 60.0)
        e = E0 * np.exp(-f / F0)
        Ltot = L + (f * GSIZE if x_self else 0.0)
        U = e * Ltot
        w = np.exp(-U - (COST * f if x_cost else 0.0))
        p = w / w.sum()
        f = f[rng.choice(Ne, Ne, p=p)]
        if g >= gen - 300:
            e = E0 * np.exp(-f / F0)
            Ltot = L + (f * GSIZE if x_self else 0.0)
            hist.append(float(np.mean(e * Ltot)))
    return float(np.mean(hist)), float(np.mean(f))


if __name__ == "__main__":
    NE_SMALL, NE_BIG = 60, 3000
    Ls = (1e3, 1e4, 1e5)
    print("=== U на равновесии (ЦЕЛЬ: конечное, ненулевое, НЕ зависит от L) ===")
    print(f"{'X_self':>7}{'X_cost':>7}{'X_drift':>8} | "
          + "".join(f"{'L=%.0e' % L:>11}" for L in Ls) + "   разброс   вердикт")
    rows = []
    for xs in (1, 0):
        for xc in (1, 0):
            for xd in (1, 0):
                Ne = NE_SMALL if xd else NE_BIG
                us = [evolve(L, xs, xc, Ne, seed=1)[0] for L in Ls]
                a = np.array(us)
                alive = a.min() > 1e-6
                spread = a.std() / max(a.mean(), 1e-12) * 100
                ok = alive and spread < 60
                rows.append((xs, xc, xd, a, spread, ok))
                print(f"{xs:>7}{xc:>7}{xd:>8} | "
                      + "".join(f"{u:>11.2e}" for u in us)
                      + f"{spread:>8.0f}%   {'РАБОТАЕТ' if ok else '—'}")
    print("\n=== минимальный набор ===")
    work = [(xs, xc, xd) for xs, xc, xd, _, _, ok in rows if ok]
    if work:
        mn = min(sum(w) for w in work)
        print(f"  рабочих комбинаций: {len(work)}, минимум ящиков: {mn}")
        for w in work:
            if sum(w) == mn:
                nm = [n for n, v in zip(("X_self", "X_cost", "X_drift"), w) if v]
                print(f"    {nm}")
    else:
        print("  ни одна комбинация не даёт обе цели")
