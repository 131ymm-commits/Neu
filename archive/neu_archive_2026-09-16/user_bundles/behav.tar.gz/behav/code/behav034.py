"""BEHAV-034 / AN1+AN2 — артефакты наблюдения ПЕРЕД содержательными объяснениями."""
import datetime as dt
import numpy as np
import behav031 as B

BINS = [(0, 1, "<1д"), (1, 3, "1-3д"), (3, 10, "3-10д"), (10, 1e9, ">10д")]


def build(path):
    rows = []
    for l in open(path, encoding="utf-8", errors="replace"):
        p = l.rstrip("\n").split("|", 2)
        if len(p) == 3: rows.append((p[0], int(p[1]), p[2]))
    rows.sort(key=lambda r: r[1])
    subj = [r[2] for r in rows]; ts = [r[1] for r in rows]; end = ts[-1]
    key = [B.norm(s) for s in subj]
    idx = {}
    for i, k in enumerate(key): idx.setdefault(k, []).append(i)
    rel = {}
    for i, s in enumerate(subj):
        m = B.RELAND.match(s.strip())
        if m and m.group(1): rel.setdefault(B.norm(m.group(1)), []).append(i)
    out = []
    for i, s in enumerate(subj):
        m = B.REV.match(s.strip())
        if not m: continue
        o = B.norm(m.group(1))
        pre = [j for j in idx.get(o, []) if j < i]
        if not pre: continue
        post = [j for j in idx.get(o, []) if j > i] + [j for j in rel.get(o, []) if j > i]
        out.append(dict(back=bool(post), life=(ts[i]-ts[max(pre)])/86400.0,
                        remain=(end-ts[i])/86400.0,
                        year=dt.datetime.utcfromtimestamp(ts[i]).year))
    return out


def curve(g):
    cells = []
    for a, b, t in BINS:
        gg = [o for o in g if a <= o["life"] < b]
        cells.append(f"{np.mean([x['back'] for x in gg]):.3f}({len(gg)})"
                     if len(gg) >= 20 else "—")
    return cells


if __name__ == "__main__":
    out = build("/home/claude/pt_log.txt")
    print(f"откатов с известным оригиналом: {len(out)}")
    print(f"\n=== AN1: контроль на ЦЕНЗУРИРОВАНИЕ ===")
    print(f"{'выборка':<26}" + "".join(f"{t:>13}" for _, _, t in BINS))
    print(f"{'все':<26}" + "".join(f"{c:>13}" for c in curve(out)))
    for lim in (365, 730):
        g = [o for o in out if o["remain"] >= lim]
        print(f"{'остаток истории >=' + str(lim) + 'д':<26}"
              + "".join(f"{c:>13}" for c in curve(g)))
    r = np.array([o["remain"] for o in out]); L = np.array([o["life"] for o in out])
    print(f"\n  корреляция life vs remain: {np.corrcoef(np.log1p(L), r)[0,1]:+.3f}")
    print(f"  медиана остатка истории: {np.median(r):.0f} дней "
          f"(медиана задержки возврата была 1.11 дня)")

    print(f"\n=== AN2: контроль на ЭПОХУ ===")
    print(f"{'год':<26}" + "".join(f"{t:>13}" for _, _, t in BINS))
    for y in sorted({o["year"] for o in out}):
        g = [o for o in out if o["year"] == y]
        if len(g) < 150: continue
        print(f"{str(y) + f'  (n={len(g)})':<26}" + "".join(f"{c:>13}" for c in curve(g)))
