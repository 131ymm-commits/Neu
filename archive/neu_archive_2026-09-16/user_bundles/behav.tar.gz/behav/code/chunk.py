import sys, os, numpy as np, behav009 as S
a, b = int(sys.argv[1]), int(sys.argv[2])
out = f"/home/claude/rb_{a}_{b}.npy"
if os.path.exists(out):
    print("skip", a, b); sys.exit()
rows = [[S.scores(S.cfg_of(m))[n] for n in S.NAMES] for m in range(a, b)]
np.save(out, np.array(rows)); print("ok", a, b)
