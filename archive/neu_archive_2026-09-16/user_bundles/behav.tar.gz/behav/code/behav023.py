"""
BEHAV-023 / R1 — ЛОБОВОЙ ТЕСТ (переносился 4 раза).

Против: Gosme, arXiv:2512.09352 — «каузальная симметризация» как
НАБЛЮДАТЕЛЬНАЯ подпись операционной автономии. Мера: отношение
грейнджеровских связей структура<->активность; ->1 = симметрия = замкнутость.
Их прямое утверждение: «крайняя асимметрия — когда структура целиком
определяет активность (внешнее навязывание) — несовместима с замкнутостью».

Наш результат (BEHAV-004, 017): ext и template НАБЛЮДАТЕЛЬНО эквивалентны,
различимы только вмешательством.

Оба не могут быть верны. ПРЕДРЕГИСТРАЦИЯ:
  Z1 их мера различает: ext асимметричен (ratio низкий), template
     симметричен (ratio ~1)  =>  НАШ тезис опровергнут
  Z2 обе системы дают близкие ratio  =>  их подпись здесь недостаточна
  Z3 промежуточное: различает, но слабо  =>  ничья, нужен размер эффекта

Переменные (по их определениям):
  Структура S(t) = структурная сохранность = |m|, доля, удерживающая тождество
  Активность A(t) = оборот = доля носителей, сменивших состояние за шаг
"""
import numpy as np


def series(N, eps, mu, mode, T, seed=0, burn=500):
    rng = np.random.default_rng(seed)
    s = np.ones(N, bool)
    S = np.empty(T); A = np.empty(T)
    for t in range(T + burn):
        before = s.copy()
        nz = rng.random(N) < eps
        if nz.any():
            s[nz] = rng.random(int(nz.sum())) < 0.5
        if mu > 0:
            fix = rng.random(N) < mu
            s[fix] = True if mode == "ext" else (s.sum() * 2 > N)
        if t >= burn:
            i = t - burn
            S[i] = 2 * s.mean() - 1
            A[i] = (s != before).mean()
    return S, A


def granger_F(y, x, p=4):
    """F-статистика: помогают ли лаги x предсказывать y сверх лагов y."""
    n = len(y) - p
    Y = y[p:]
    Ly = np.column_stack([y[p - k - 1:-k - 1] for k in range(p)])
    Lx = np.column_stack([x[p - k - 1:-k - 1] for k in range(p)])
    def rss(D):
        D = np.column_stack([np.ones(n), D])
        b, *_ = np.linalg.lstsq(D, Y, rcond=None)
        r = Y - D @ b
        return float(r @ r)
    r_res, r_unr = rss(Ly), rss(np.column_stack([Ly, Lx]))
    df2 = n - 2 * p - 1
    return max(((r_res - r_unr) / p) / (r_unr / df2), 0.0)


def coupling_ratio(S, A, p=4, diff=True):
    if diff:
        S, A = np.diff(S), np.diff(A)
    f_as = granger_F(S, A, p)      # активность -> структура
    f_sa = granger_F(A, S, p)      # структура -> активность
    lo, hi = min(f_as, f_sa), max(f_as, f_sa)
    return f_as, f_sa, (lo / hi if hi > 0 else np.nan)


if __name__ == "__main__":
    N, eps, mu, T = 101, 0.05, 0.25, 4000
    print("=== R1: каузальная симметризация на наших системах ===")
    print(f"{'режим':<10}{'A->S (F)':>11}{'S->A (F)':>11}{'ratio':>9}   (их: 0.65 ранн., 0.94 зрел.)")
    res = {}
    for mode in ("ext", "template"):
        rs = [coupling_ratio(*series(N, eps, mu, mode, T, seed=s)) for s in range(9)]
        a = float(np.median([r[0] for r in rs]))
        b = float(np.median([r[1] for r in rs]))
        c = float(np.median([r[2] for r in rs]))
        res[mode] = c
        print(f"{mode:<10}{a:>11.2f}{b:>11.2f}{c:>9.3f}")
    d = abs(res["ext"] - res["template"])
    print(f"\n  разница ratio: {d:.3f}")
    print("  Z1 (различает, наш тезис опровергнут) если разница велика и"
          " ext заметно асимметричнее")
    print("  Z2 (их подпись недостаточна) если разница мала")
