"""
BEHAV-027 / AF1 — ПЕРВАЯ ФОРВАРДНАЯ ПРОВЕРКА НА РЕАЛЬНЫХ ДАННЫХ.

Данные: Good, McDonald, Barrick, Lenski, Desai, Nature 551:45 (2017).
LTEE, 12 популяций E. coli, метагеномные ряды каждые 500 поколений
до 60000. Шесть популяций эволюционировали в ГИПЕРМУТАТОРОВ (дефекты
репарации, частота точечных мутаций x~100): m1,m2,m3,m4,p3,p6.
Шесть остались немутаторами: m5,m6,p1,p2,p4,p5.

Естественный эксперимент ровно того вида, что предписывает BEHAV-025/026:
одинаковые условия, одинаковое измерение, частота сбоев отличается на
два порядка.

Переменные (по Gosme / нашему BEHAV-023):
  Активность A(t) = поток частот = sum_i |f_i(t) - f_i(t-1)|
  Структура  S(t) = сохранность = sum_i min(f_i(t),f_i(t-1)) / sum_i f_i(t-1)

ПРЕДРЕГИСТРАЦИЯ (записана ДО прогона):
  AF1a у немутаторов подпись АСИММЕТРИЧНА (отбор навязывает структуру,
       ratio низкий) — они в слепой зоне удержания
  AF1b у мутаторов ratio ВЫШЕ (поток мутаций начинает определять структуру)
  AF1c разница между группами больше внутригруппового разброса
  AF1d если разницы нет или знак обратный — окно наблюдаемости остаётся
       артефактом симуляции. Записать как провал.
"""
import sys
import numpy as np

MUT = ['m1', 'm2', 'm3', 'm4', 'p3', 'p6']
NON = ['m5', 'm6', 'p1', 'p2', 'p4', 'p5']
D = "/home/claude/ltee/data_files"


def load(pop):
    """Возвращает матрицу частот (мутации x времена)."""
    fn = f"{D}/{pop}_annotated_timecourse.txt"
    freqs = []
    with open(fn) as fh:
        header = fh.readline()
        for line in fh:
            p = line.rstrip("\n").split(", ")
            if len(p) < 15 or p[12].strip() not in ("PASS", "1", "True"):
                continue
            v = np.array([float(x) for x in p[13:]])
            ac, dp = v[0::2], v[1::2]
            f = np.where(dp > 0, ac / np.maximum(dp, 1e-9), 0.0)
            freqs.append(f)
    return np.array(freqs) if freqs else None


def series(F):
    d = np.abs(np.diff(F, axis=0 if False else 1))
    A = d.sum(axis=0)                                   # поток
    prev, cur = F[:, :-1], F[:, 1:]
    keep = np.minimum(prev, cur).sum(axis=0)
    tot = prev.sum(axis=0)
    S = np.where(tot > 0, keep / np.maximum(tot, 1e-9), 1.0)
    return S, A


def gF(y, x, p=3):
    n = len(y) - p
    if n < 3 * p + 5:
        return np.nan
    Y = y[p:]
    Ly = np.column_stack([y[p - k - 1:-k - 1] for k in range(p)])
    Lx = np.column_stack([x[p - k - 1:-k - 1] for k in range(p)])
    def rss(Dm):
        Dm = np.column_stack([np.ones(n), Dm])
        b, *_ = np.linalg.lstsq(Dm, Y, rcond=None)
        r = Y - Dm @ b
        return float(r @ r)
    a, u = rss(Ly), rss(np.column_stack([Ly, Lx]))
    if u <= 0:
        return np.nan
    return max(((a - u) / p) / (u / (n - 2 * p - 1)), 0.0)


if __name__ == "__main__":
    pops = sys.argv[1].split(",")
    for pop in pops:
        F = load(pop)
        if F is None or F.shape[1] < 20:
            print(f"{pop}: нет данных"); continue
        S, A = series(F)
        dS, dA = np.diff(S), np.diff(A)
        f_as, f_sa = gF(dS, dA), gF(dA, dS)
        lo, hi = min(f_as, f_sa), max(f_as, f_sa)
        r = lo / hi if hi > 0 else np.nan
        grp = "МУТ" if pop in MUT else "нем"
        print(f"{pop:>3} {grp}  мутаций={F.shape[0]:>6}  точек={F.shape[1]:>3}  "
              f"A->S={f_as:>8.2f}  S->A={f_sa:>8.2f}  ratio={r:.3f}", flush=True)
