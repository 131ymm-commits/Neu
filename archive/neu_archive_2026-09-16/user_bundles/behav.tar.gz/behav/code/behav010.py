"""
BEHAV-010 — проверка V2 после исправления премиссы.

КОНТРОЛЬ (сделан первым): PR следует за числом варьируемых величин.
  4 параметра -> PR 3.71     6 параметров -> PR 4.91     8 структур -> PR 4.27
Значит "13 считываний = ~4 вопроса" было ПОЧТИ ЦЕЛИКОМ артефактом: векторы
считываний не могут натянуть больше измерений, чем варьировалось на входе.
Реальное сжатие есть только в пространстве СТРУКТУР: 8 -> 4.27 (53%).
Нулевые моды Грама в матрице A — артефакт, целить в них нельзя.

Поэтому V1 переформулирован: новые считывания должны поднять PR
В ПРОСТРАНСТВЕ КОНФИГУРАЦИЙ (потолок 8), а не в пространстве параметров.

Новые считывания выбраны по признаку СТРУКТУРНОГО отсутствия, а не по
нулевым модам:
  DH   дисгабитуация — двухстимульный признак, в наборе не было вообще
  ORD  чувствительность к порядку: [сильный->слабый] против [слабый->сильный]
  SM   первая пространственная мода профиля (не дисперсия, как CV)
  LAT  латентность пика

ПРЕДРЕГИСТРАЦИЯ:
  V1' PR в пространстве конфигураций поднимется выше 4.27 (потолок 8)
  V2  число путей при k=1 УПАДЁТ ниже 821. Если вырастет — гипотеза
      "тоньше аппарат -> больше запретов" неверна.
  V3  удаление CT не изменит ни PR, ни число путей (CG/CT дублируют устойчиво)
"""
import itertools
import os
import sys
import numpy as np
import behav008 as E          # применяет монкипатч модели
import behav009 as N9

S = E.S                        # behav007 с исправленной моделью
B = N9.B
INV = B.INV
NI = len(INV)
cfg_of = N9.cfg_of
NEW = ["DH", "ORD", "SM", "LAT"]
ALL = N9.NAMES + NEW


def run(cfg, sched, isi=5.0, t0=5.0, site=None, tail=30.0):
    """sched: список амплитуд по импульсам. Возвращает пики по импульсам и YU."""
    M = 8 if cfg["N"] else 1
    n = len(sched)
    T = t0 + n * isi + tail
    t = np.arange(0, T, B.DT); L = len(t)
    w = np.ones(M)
    if cfg["EX"] and M > 1:
        if site == "ant":
            w = np.exp(-np.arange(M) / 1.5)
    th = np.full(M, B.TH0)
    if cfg["PO"] and M > 1:
        th = B.TH0 + N9.P["POG"] * (np.arange(M) / (M - 1) - 0.5)
    on = t0 + np.arange(n) * isi
    amp_t = np.zeros(L)
    for o, a in zip(on, sched):
        amp_t[(t >= o) & (t < o + B.DUR)] = a
    coupled = cfg["GR"] and M > 1
    kd = N9.P["KD"] if cfg["T2"] else 0.0
    r = np.ones(M); d = np.zeros(M); y = np.zeros(M); s = np.zeros(M)
    dth = np.zeros(M); Y = np.empty(L); YU = np.zeros((L, M))
    for i in range(L):
        uu = B.BASE + amp_t[i] * w
        Ee = np.log1p(uu)
        if coupled:
            nb = np.zeros(M); nb[1:] += y[:-1]; nb[:-1] += y[1:]
            Ee = Ee + N9.P["COUP"] * nb
        eff = th + dth
        if cfg["NL"]:
            a = B.sig(10.0 * (Ee - eff))
            dr = -N9.P["K"] * a * r + (1 - r - d) / N9.P["TAU_R"] - kd * a * r
            d = np.clip(d + B.DT * (kd * a * r - d / 2000.0), 0, 1)
            r = np.clip(r + B.DT * dr, 0, 1)
            resp = a * r
        else:
            s += B.DT / 8.0 * (Ee - s); resp = Ee - s
            if cfg["T2"]:
                resp = resp * 0.6 + 0.4 * (Ee - s) * 0.5
        y = y + B.DT / N9.P["TAU_Y"] * (resp - y)
        if cfg["PL"]:
            dth += B.DT * (0.02 * np.maximum(y, 0) - dth / 800.0)
        Y[i] = y.mean(); YU[i] = y
    wd = B.DUR * 4
    p = np.array([float(Y[(t >= o) & (t < o + wd)].max()) for o in on])
    return t, Y, p, on, YU


def new_scores(cfg):
    z = dict.fromkeys(NEW, 0.0)
    # DH: 20 габитуирующих, затем сильный, затем проба
    _, _, p, _, _ = run(cfg, [4.0] * 20 + [16.0] + [4.0])
    if p[0] > 1e-9:
        z["DH"] = float((p[-1] - p[19]) / max(p[0], 1e-12))
    # ORD: сильный->слабый против слабый->сильный, отклик на ВТОРОЙ импульс
    _, _, a1, _, _ = run(cfg, [8.0, 2.0], isi=10.0)
    _, _, a2, _, _ = run(cfg, [2.0, 8.0], isi=10.0)
    den = max(abs(a1[0]), abs(a2[1]), 1e-12)
    z["ORD"] = float((a1[1] - a2[0]) / den)
    # SM: первая пространственная мода профиля пиков
    if cfg["N"]:
        _, _, _, on, YU = run(cfg, [4.0] * 20, site="ant")
        t = np.arange(YU.shape[0]) * B.DT
        sl = (t >= on[0]) & (t < on[0] + B.DUR * 4)
        u = YU[sl].max(axis=0)
        M = len(u)
        c = np.cos(np.pi * np.arange(M) / max(M - 1, 1))
        m = float(np.mean(np.abs(u)))
        z["SM"] = float(abs(u @ c) / (M * m)) if m > 1e-12 else 0.0
    # LAT: латентность пика на первом импульсе
    t, Y, p, on, _ = run(cfg, [4.0] * 3)
    sl = (t >= on[0]) & (t < on[0] + B.DUR * 6)
    seg = Y[sl]
    z["LAT"] = float(seg.argmax()) * B.DT if seg.max() > 1e-12 else 0.0
    return z


def binq(v, edges):
    return int(np.digitize([v], edges)[0])


def reach(sigs, n, k=1):
    FULL = (1 << n) - 1
    paths = {0: 1}
    for m in sorted(range(1 << n), key=lambda x: bin(x).count("1")):
        if m not in paths:
            continue
        miss = [i for i in range(n) if not (m >> i & 1)]
        for rr in range(1, k + 1):
            for c in itertools.combinations(miss, rr):
                m2 = m
                for i in c:
                    m2 |= 1 << i
                if sigs[m2] != sigs[m]:
                    paths[m2] = paths.get(m2, 0) + paths[m]
    return paths.get(FULL, 0)


if __name__ == "__main__":
    a, b = int(sys.argv[1]), int(sys.argv[2])
    out = f"/home/claude/n10_{a}_{b}.npz"
    if os.path.exists(out):
        print("skip", a, b); sys.exit()
    cont, disc = [], []
    for m in range(a, b):
        c = cfg_of(m)
        ns = new_scores(c)
        cont.append([ns[k] for k in NEW])
        old = S.probes(c)
        disc.append(tuple(old[k] for k in S.ORDER)
                    + (binq(ns["DH"], [-.2, -.02, .02, .2]),
                       binq(ns["ORD"], [-.3, -.05, .05, .3]),
                       binq(ns["SM"], [1e-3, .05, .2, .5]),
                       binq(ns["LAT"], [.15, .35, .7, 1.5])))
    np.savez(out, cont=np.array(cont),
             disc=np.array([[hash(x) for x in d] for d in disc], dtype=object),
             raw=np.array(disc, dtype=object))
    print("ok", a, b)
