"""
BEHAV-024 / AA1 — проверка нашего объяснения чужого результата.

Тезис (BEHAV-023): наблюдательная подпись симметризации живёт НА СБОЯХ.
Если система не сбоит, ext и template тождественны и подпись слепа.

Операционально: разделяющая способность подписи (Delta = ratio_template -
ratio_ext) должна отслеживать ЧАСТОТУ СБОЕВ (переворотов большинства),
а НЕ уровень удержания |m|.

ПРЕДРЕГИСТРАЦИЯ:
  AB1 Delta растёт с частотой сбоев flip
  AB2 Delta НЕ объясняется уровнем |m| при контроле flip
  AB3 при flip -> 0 имеем Delta -> 0 (полная слепота подписи)
  AB4 частная корреляция Delta~flip | |m| положительна и больше,
      чем Delta~|m| | flip
"""
import numpy as np
import behav023 as B


def measure(N, eps, mu, T=3000, seeds=5):
    out = {}
    flips = []
    for mode in ("ext", "template"):
        rs, fl, ms = [], [], []
        for sd in range(seeds):
            S, A = B.series(N, eps, mu, mode, T, seed=sd)
            rs.append(B.coupling_ratio(S, A)[2])
            ms.append(np.mean(np.abs(S)))
            sg = np.sign(S); sg[sg == 0] = 1
            fl.append(float(np.mean(sg[1:] != sg[:-1])))
        out[mode] = (float(np.median(rs)), float(np.mean(ms)))
        if mode == "template":
            flips = float(np.mean(fl))
    return out["template"][0] - out["ext"][0], flips, out["template"][1]


def partial_corr(a, b, c):
    """corr(a,b | c)"""
    def resid(y, x):
        D = np.column_stack([np.ones(len(x)), x])
        bb, *_ = np.linalg.lstsq(D, y, rcond=None)
        return y - D @ bb
    ra, rb = resid(a, c), resid(b, c)
    return float(np.corrcoef(ra, rb)[0, 1])


if __name__ == "__main__":
    N = 101
    grid = [(e, m) for e in (0.05, 0.15, 0.25, 0.35, 0.45)
            for m in (0.05, 0.10, 0.25)]
    D, F, M = [], [], []
    print(f"{'eps':>6}{'mu':>6}{'flip':>9}{'|m|':>7}{'Delta ratio':>13}")
    for e, mu in grid:
        d, f, m = measure(N, e, mu)
        D.append(d); F.append(f); M.append(m)
        print(f"{e:>6.2f}{mu:>6.2f}{f:>9.4f}{m:>7.2f}{d:>13.3f}", flush=True)
    D, F, M = map(np.array, (D, F, M))
    print(f"\n  corr(Delta, flip)       = {np.corrcoef(D,F)[0,1]:+.3f}")
    print(f"  corr(Delta, |m|)        = {np.corrcoef(D,M)[0,1]:+.3f}")
    print(f"  partial(Delta,flip||m|) = {partial_corr(D,F,M):+.3f}")
    print(f"  partial(Delta,|m||flip) = {partial_corr(D,M,F):+.3f}")
