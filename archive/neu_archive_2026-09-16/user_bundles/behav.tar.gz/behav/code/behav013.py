"""
BEHAV-013 — различающий эксперимент: цена точности против барьера дрейфа.

Оба механизма дают одинаковое U* при фиксированном Ne (BEHAV-012), значит
данные Дрейка их не различают. Различает ЗАВИСИМОСТЬ ОТ Ne:

  цена точности:  U* = F0 * COST                 -> НЕ зависит от Ne
  барьер дрейфа:  отбор слеп при s < 1/Ne,
                  s = -dU/df / U ~ 1/F0  ...  U* ~ F0/Ne  -> ПАДАЕТ как 1/Ne

Совместно: U* ~ max(F0*COST, F0/Ne) -> ПЛАТО при больших Ne, если цена есть.

ПРЕДРЕГИСТРАЦИЯ:
  H1a COST=0: U* падает как ~1/Ne (наклон в log-log около -1)
  H1b COST>0: U* выходит на ПЛАТО = F0*COST при больших Ne
  H1c точка излома при Ne ~ 1/COST
  H1d реальные данные (мутации против Ne по таксонам) покажут, есть ли плато
"""
import sys
import numpy as np

E0, F0, SIGMA = 1e-3, 3.0, 0.06


def equilibrium(L, Ne, cost, gen, seed=0, tail=6):
    rng = np.random.default_rng(seed)
    f = np.full(Ne, 3.0)
    tr = []
    step = max(gen // tail, 1)
    for g in range(gen):
        f = np.clip(f + rng.normal(0, SIGMA, Ne), 0.0, 80.0)
        U = E0 * np.exp(-f / F0) * L
        w = np.exp(-U - cost * f)
        f = f[rng.choice(Ne, Ne, p=w / w.sum())]
        if g % step == 0 or g == gen - 1:
            tr.append(float(np.mean(E0 * np.exp(-f / F0) * L)))
    return tr


if __name__ == "__main__":
    Ne = int(sys.argv[1]); gen = int(sys.argv[2])
    out = f"/home/claude/h1_{Ne}.txt"
    lines = []
    for cost in (0.0, 2e-3):
        trs = [equilibrium(1e4, Ne, cost, gen, seed=s) for s in range(3)]
        last = np.median([t[-1] for t in trs])
        prev = np.median([t[-2] for t in trs])
        conv = abs(last - prev) / max(last, 1e-15)
        lines.append(f"{Ne}\t{cost}\t{last:.4e}\t{conv:.2f}\t"
                     + " ".join(f"{x:.2e}" for x in trs[0]))
    open(out, "w").write("\n".join(lines) + "\n")
    print("ok", Ne)
