"""
BEHAV-001 — поведенческий (Willems) слой.

Система = отображение u(.) -> y(.). Поведение B = множество пар (u,y)
по фиксированному семейству допустимых входов U.
Симметрия = замкнутость B относительно g.
Ограничение = предикат на B целиком.
Потолок = "симметрия g в G(B)  =>  ограничение C невыполнимо".

Проверяем ЯДРО тезиса: наличие симметрии ПРЕДСКАЗЫВАЕТ провал ограничения.
"""
import itertools
import numpy as np

DT, BASE, DUR = 0.01, 1.0, 0.5
sig = lambda x: 1.0 / (1.0 + np.exp(-x))


# --------------------------------------------------------------- входы
def train(T, n, isi, amp, t0=5.0, dur=DUR, base=BASE):
    t = np.arange(0, T, DT)
    u = np.full_like(t, base)
    on = t0 + np.arange(n) * isi
    for o in on:
        u[(t >= o) & (t < o + dur)] = base + amp
    return t, u, on


def pk(t, y, on, win=None):
    win = win or DUR * 4
    return np.array([y[(t >= o) & (t < o + win)].max() for o in on])


# --------------------------------------------------------------- системы
def S_lti(t, u, tau=8.0):
    """Линейный фильтр: аддитивен, стационарен. Потолок: не может H1."""
    y = np.zeros_like(t); s = u[0]          # ФИКС: старт из стационара
    for i in range(len(t)):
        s += DT / tau * (u[i] - s)
        y[i] = u[i] - s                     # линейный выход
    return y


def S_nl(t, u, tau=8.0, beta=6.0, th=1.0):
    """Тот же фильтр + статическая нелинейность на выходе. Снят '+'."""
    y = np.zeros_like(t); s = u[0]          # ФИКС: старт из стационара
    for i in range(len(t)):
        s += DT / tau * (u[i] - s)
        y[i] = sig(beta * (u[i] - s - th))
    return y


def S_pool(t, u, k=0.8, tau_r=40.0, beta=10.0, deep=False,
           kd=0.05, tau_d=2000.0, tau_y=0.1):
    """Расходуемый пул (B1). deep=True -> добавлен инвариант tau_d/tau_r."""
    E = np.log1p(u)
    th = (np.log1p(BASE) + np.log1p(BASE + 4.0)) / 2
    A = sig(beta * (E - th))
    r, d, y = 1.0, 0.0, 0.0
    Y = np.empty_like(t)
    for i in range(len(t)):
        a = A[i]
        dr = -k * a * r + (1 - r - d) / tau_r
        dd = 0.0
        if deep:
            dd = kd * a * r - d / tau_d
            dr -= kd * a * r
        r = min(1.0, max(0.0, r + DT * dr))
        d = min(1.0, max(0.0, d + DT * dd))
        y += DT / tau_y * (a * r - y)
        Y[i] = y
    return Y


# ------------------------------------------------------- детектор симметрий
def sym_additive(f, tol=1e-2):
    """g: (u1,u2) -> u1+u2.  Замкнуто, если y(u1+u2)=y(u1)+y(u2)."""
    t, u1, _ = train(80, 3, 8.0, 3.0)
    _, u2, _ = train(80, 3, 8.0, 2.0, t0=9.0)
    u1b, u2b = u1 - BASE, u2 - BASE
    z = np.zeros_like(t)
    a = f(t, u1b) - f(t, z)
    b = f(t, u2b) - f(t, z)
    c = f(t, u1b + u2b) - f(t, z)
    den = max(np.abs(a + b).max(), 1e-9)
    return float(np.abs(c - (a + b)).max() / den) < tol


def sym_shift(f, tol=1e-2):
    """g: сдвиг во времени. y(sigma u) = sigma y(u)."""
    t, u, _ = train(120, 4, 8.0, 3.0, t0=5.0)
    _, us, _ = train(120, 4, 8.0, 3.0, t0=25.0)
    n = int(20.0 / DT)
    y, ys = f(t, u), f(t, us)
    den = max(np.abs(y).max(), 1e-9)
    return float(np.abs(ys[n:] - y[:-n]).max() / den) < tol


def sym_dilation(f, a=2.0, tol=5e-2):
    """ФИКС: сравниваем НОРМИРОВАННЫЙ профиль пиков; плоский профиль => инвариант
    поведенчески инертен, возвращаем None (не False)."""
    t1, u1, o1 = train(200, 6, 10.0, 3.0, dur=DUR)
    t2, u2, o2 = train(400, 6, 10.0 * a, 3.0, t0=5.0 * a, dur=DUR * a)
    p1 = pk(t1, f(t1, u1), o1)
    p2 = pk(t2, f(t2, u2), o2, win=DUR * 4 * a)
    if p1[0] <= 1e-9 or p2[0] <= 1e-9:
        return None
    n1, n2 = p1 / p1[0], p2 / p2[0]
    ptp = lambda z: float(z.max() - z.min())
    if ptp(n1) < 1e-3 and ptp(n2) < 1e-3:
        return None                      # вырождение: инвариант ничего не меняет
    return bool(np.abs(n1 - n2).max() < tol)


SYMS = {"additive": sym_additive, "shift": sym_shift, "dilation": sym_dilation}


# ------------------------------------------------------ детектор ограничений
def C_H1(f):
    """Габитуация: монотонное убывание пиков к асимптоте."""
    t, u, on = train(140, 20, 5.0, 4.0)
    p = pk(t, f(t, u), on)
    if p[0] <= 1e-9:
        return False
    return bool(np.all(np.diff(p) <= 1e-9) and p[-1] < 0.7 * p[0])


def C_H2(f):
    """Спонтанное восстановление."""
    def probe(w):
        T = 5 + 20 * 5 + w + 30
        t, u, on = train(T, 20, 5.0, 4.0)
        tt = 5 + 20 * 5 + w
        u[(t >= tt) & (t < tt + DUR)] = BASE + 4.0
        p = pk(t, f(t, u), np.append(on, tt))
        return (p[-1] + 1e-12) / (p[0] + 1e-12)
    return bool(probe(600) > probe(5) + 0.05)


def C_H3(f):
    """Потенцирование: 1-й отклик поздней серии ниже 1-го отклика ранней."""
    n, isi, gap = 20, 5.0, 500.0
    T = 5 + 4 * (n * isi + gap) + 30
    t = np.arange(0, T, DT); u = np.full_like(t, BASE); ser = []; cur = 5.0
    for _ in range(4):
        o = cur + np.arange(n) * isi
        for x in o:
            u[(t >= x) & (t < x + DUR)] = BASE + 4.0
        ser.append(o); cur += n * isi + gap
    y = f(t, u)
    first = [pk(t, y, o)[0] for o in ser]
    return bool(first[-1] < first[0] - 0.05 * abs(first[0]))


def C_H6(f):
    """Below-zero: больше стимулов после плато -> дольше восстановление."""
    def probe(n):
        T = 5 + n * 5 + 100 + 30
        t, u, on = train(T, n, 5.0, 4.0)
        tt = 5 + n * 5 + 100
        u[(t >= tt) & (t < tt + DUR)] = BASE + 4.0
        p = pk(t, f(t, u), np.append(on, tt))
        return (p[-1] + 1e-12) / (p[0] + 1e-12)
    return bool(probe(120) < probe(20) - 0.05)


CONS = {"H1": C_H1, "H2": C_H2, "H3": C_H3, "H6": C_H6}
# ФИКС 3: H2..H6 осмысленны только при выполненном H1 (Smart et al. 2026, Table 1)
# ВНИМАНИЕ: H3 исключён из CEILINGS — критерий метрико-зависим, см. журнал.
GATED = ["H2", "H3", "H6"]

# предсказанные потолки: симметрия -> запрещаемые ограничения
CEILINGS = {"additive": ["H1"], "dilation": ["H6"]}


# ------------------------------------------- порядок: DAG историй
INV = ["NL", "T2", "CH", "EX", "PO", "N", "GR", "PL"]
PREREQ = [("NL", "T2"), ("NL", "PL"), ("EX", "PO"), ("N", "GR")]


def count_histories(items, prereq):
    idx = {x: i for i, x in enumerate(items)}
    ok = 0; total = 0
    for perm in itertools.permutations(range(len(items))):
        total += 1
        pos = {p: i for i, p in enumerate(perm)}
        if all(pos[idx[a]] < pos[idx[b]] for a, b in prereq):
            ok += 1
    return ok, total


if __name__ == "__main__":
    systems = {
        "LTI (линейный)":        S_lti,
        "NL (нелин. выход)":     S_nl,
        "Pool (1 шкала)":        lambda t, u: S_pool(t, u),
        "Pool+T2 (2 шкалы)":     lambda t, u: S_pool(t, u, deep=True),
    }
    print(f"{'система':<22}" + "".join(f"{s:>10}" for s in SYMS)
          + " |" + "".join(f"{c:>6}" for c in CONS))
    rows = {}
    for name, f in systems.items():
        S = {k: v(f) for k, v in SYMS.items()}
        h1 = CONS["H1"](f)
        C = {k: (v(f) if (k == "H1" or h1) else None) for k, v in CONS.items()}
        rows[name] = (S, C)
        print(f"{name:<22}" + "".join(f"{str(S[s]):>10}" for s in SYMS)
              + " |" + "".join(f"{ {True:chr(84),False:chr(70),None:chr(45)}[C[c]] :>6}" for c in CONS))

    print("\n--- проверка потолков (симметрия => ограничение невыполнимо) ---")
    viol = 0
    for name, (S, C) in rows.items():
        for s, forbidden in CEILINGS.items():
            if S[s] is True:
                for c in forbidden:
                    status = "НАРУШЕН" if C[c] is True else "ok"
                    if C[c] is True:
                        viol += 1
                    print(f"  {name:<22} {s:>9} present -> {c} must fail : {status}")
    print(f"  нарушений потолка: {viol}")

    ok, tot = count_histories(INV, PREREQ)
    print(f"\n--- множество возможных историй ---")
    print(f"  инвариантов: {len(INV)}, предпосылок: {len(PREREQ)}")
    print(f"  допустимых порядков: {ok} из {tot}  ({100*ok/tot:.1f}%)")
