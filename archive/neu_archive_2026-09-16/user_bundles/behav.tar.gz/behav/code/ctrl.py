import sys, os, numpy as np, behav009 as S
a,b=int(sys.argv[1]),int(sys.argv[2]); out=f"/home/claude/ca_{a}_{b}.npy"
if os.path.exists(out): print("skip"); sys.exit()
rng=np.random.default_rng(0)
pts=[dict(K=float(rng.uniform(0.3,2.0)),TAU_R=float(rng.uniform(10,150)),
          KD=float(rng.uniform(0.01,0.15)),COUP=float(rng.uniform(0.1,1.0)),
          POG=float(rng.uniform(0.05,0.8)),TAU_Y=float(rng.uniform(0.2,2.0)))
     for _ in range(40)]
ALLON={k:True for k in S.INV}
rows=[]
for i in range(a,b):
    S.P.update(pts[i]); rows.append([S.scores(ALLON)[n] for n in S.NAMES])
np.save(out,np.array(rows)); print("ok",a,b)
