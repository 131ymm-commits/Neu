"""
BEHAV-008 — фикс модели и честная проверка развилки "связки".

Два дефекта BEHAV-005..007:
  1. DT/tau_y = 1.0 -> выход полностью замещался каждый шаг, диффузия не жила.
  2. Связь применялась к ВЫХОДУ (сглаживание), а не к состоянию. Смешивание
     выхода сохраняет среднее -> невидимо для агрегированных считываний.

Фикс:
  tau_y = 0.3 (DT/tau_y = 1/3)
  GR входит в ДРАЙВ соседей: E_i += COUP * (y_{i-1} + y_{i+1})
  цепь с закреплёнными концами (не кольцо — кольцо симметрично к вращению)

ПРЕДРЕГИСТРАЦИЯ (записана до прогона, см. PREREG.md):
  S1 GR станет неинертен в > 0 контекстов
  S2 при 8 работающих инвариантах путей при k=1 будет > 0
  S3 разрыв k=1 -> k=2 ИСЧЕЗНЕТ (артефакт GR) ЛИБО УЦЕЛЕЕТ (связки реальны)

Контроль leave-one-out теперь ОБЯЗАТЕЛЕН в каждом прогоне графа достижимости.
"""
import itertools
import math
import sys
import numpy as np
import behav005 as B

TAU_Y = 0.3
COUP = 0.5


def simulate_fixed(cfg, prot):
    M = 8 if cfg["N"] else 1
    C = 2 if cfg["CH"] else 1
    n, isi = prot["n"], prot["isi"]
    T = 5 + n * isi + prot.get("wait", 0) + 10
    t = np.arange(0, T, B.DT)
    L = len(t)

    w = np.ones(M)
    if cfg["EX"] and M > 1:
        if prot.get("site") == "ant":
            w = np.exp(-np.arange(M) / 1.5)
        elif prot.get("site") == "post":
            w = np.exp(-(M - 1 - np.arange(M)) / 1.5)
    th = np.full(M, B.TH0)
    if cfg["PO"] and M > 1:
        th = B.TH0 + 0.35 * (np.arange(M) / (M - 1) - 0.5)
    chan_off = np.array([0.0, 0.45])[:C]

    on = 5 + np.arange(n) * isi
    tp = 5 + n * isi + prot["wait"] if prot.get("wait") else None
    pulse = np.zeros(L, bool)
    for o in on:
        pulse |= (t >= o) & (t < o + B.DUR)
    probe = np.zeros(L, bool)
    if tp is not None:
        probe = (t >= tp) & (t < tp + B.DUR)

    coupled = cfg["GR"] and M > 1
    kd = 0.05 if cfg["T2"] else 0.0
    r = np.ones(M); d = np.zeros(M); y = np.zeros(M); s = np.zeros(M)
    dth = np.zeros(M)
    Y = np.empty(L); YU = np.zeros((L, M))
    amp = prot.get("amp", B.AMP)
    off = chan_off[prot.get("chan", 0) % C]
    for i in range(L):
        uu = B.BASE + (amp * w if (pulse[i] or probe[i]) else 0.0)
        E = np.log1p(uu)
        if coupled:                       # СВЯЗЬ В ДРАЙВ, не в выход
            nb = np.zeros(M)
            nb[1:] += y[:-1]
            nb[:-1] += y[1:]
            E = E + COUP * nb
        eff = th + dth + off
        if cfg["NL"]:
            a = B.sig(10.0 * (E - eff))
            dr = -0.8 * a * r + (1 - r - d) / 40.0 - kd * a * r
            d = np.clip(d + B.DT * (kd * a * r - d / 2000.0), 0, 1)
            r = np.clip(r + B.DT * dr, 0, 1)
            resp = a * r
        else:
            s += B.DT / 8.0 * (E - s)
            resp = E - s
            if cfg["T2"]:
                resp = resp * 0.6 + 0.4 * (E - s) * 0.5
        y = y + B.DT / TAU_Y * (resp - y)      # DT/tau_y = 1/3, память живёт
        if cfg["PL"]:
            dth += B.DT * (0.02 * np.maximum(y, 0) - dth / 800.0)
        Y[i] = y.mean(); YU[i] = y
    return t, Y, on, tp, YU


B.simulate = simulate_fixed          # монкипатч: behav007.probes пойдёт через фикс
import behav007 as S                 # noqa: E402  (импорт после патча — намеренно)

INV = B.INV
NI = len(INV)


def reach(sigs, n, k=1):
    FULL = (1 << n) - 1
    paths = {0: 1}
    for m in sorted(range(1 << n), key=lambda x: bin(x).count("1")):
        if m not in paths:
            continue
        miss = [i for i in range(n) if not (m >> i & 1)]
        for rr in range(1, k + 1):
            for c in itertools.combinations(miss, rr):
                m2 = m
                for i in c:
                    m2 |= 1 << i
                if sigs[m2] != sigs[m]:
                    paths[m2] = paths.get(m2, 0) + paths[m]
    return paths.get(FULL, 0)


if __name__ == "__main__":
    # --- санитарная проверка ДО полного прогона
    std = {k: False for k in INV}; std["NL"] = True
    p, _ = B.peaks(std, n=20, isi=5.0)
    print(f"санчек: одиночный нелинейный юнит, пики[0..3]={np.round(p[:4],4)}, "
          f"p20/p0={p[-1]/p[0]:.3f}  H1={'ok' if p[-1]<0.7*p[0] else 'СЛОМАН'}")
    gr_off = {k: True for k in INV}; gr_off["GR"] = False
    gr_on = {k: True for k in INV}
    same = S.probes(gr_off) == S.probes(gr_on)
    print(f"санчек: GR виден в полном контексте? {'НЕТ' if same else 'ДА'}")

    print("считаю 256 конфигураций...", file=sys.stderr)
    G = {}
    for m in range(1 << NI):
        G[m] = S.probes(S.cfg_of(m))
        if m % 64 == 0:
            print(f"  {m}/256", file=sys.stderr)
    full = {m: tuple(G[m][k] for k in S.ORDER) for m in G}

    act = {kk: 0 for kk in INV}
    for m in range(1 << NI):
        for i, kk in enumerate(INV):
            if not (m >> i & 1) and full[m | (1 << i)] != full[m]:
                act[kk] += 1
    print("\n=== S1: неинертность по контекстам (из 128) ===")
    print("   " + "  ".join(f"{kk}={act[kk]}" for kk in INV))
    print(f"  различимых сигнатур: {len(set(full.values()))} из 256")

    print("\n=== S2/S3: пути ===")
    print(f"{'k':>3}{'путей (8 инв)':>16}{'из':>8}")
    tot = math.factorial(NI)
    for k in (1, 2, 3):
        print(f"{k:>3}{reach(full, NI, k):>16}{tot:>8}")

    print("\n=== ОБЯЗАТЕЛЬНЫЙ КОНТРОЛЬ leave-one-out (k=1, 7 инв, 7!=5040) ===")
    for drop in INV:
        keep = [i for i, kk in enumerate(INV) if kk != drop]

        def pr(m, keep=keep):
            r = 0
            for j, i in enumerate(keep):
                if m >> j & 1:
                    r |= 1 << i
            return r
        sg = {m: full[pr(m)] for m in range(1 << 7)}
        print(f"  без {drop:<3}: {reach(sg, 7, 1):>6}")
