"""
BEHAV-029 / AI — ГЛУБИНА ВОССТАНОВЛЕНИЯ = РАЗРЕШЕНИЕ ЭТАЛОНА.
Проверка сильнейшего результата программы на реальных данных.

BEHAV-022 (симуляция): содержание возвращается ровно там, где эталон
его задаёт; непокрытое достраивается выводом или теряется.

LTEE: 12 популяций, ОДИН И ТОТ ЖЕ внешний эталон (среда DM25). Клады
постоянно вымирают (BEHAV-028: теряется ~0.6 закрепившегося). Вопрос:
что возвращается после утраты — и на каком уровне разрешения?

ПРЕДРЕГИСТРАЦИЯ:
  AI1 параллелизм на уровне ГЕНОВ сильно выше случайного
      (среда задаёт, ЧТО чинить)
  AI2 параллелизм на уровне НУКЛЕОТИДА близок к случайному
      (среда НЕ задаёт, ГДЕ именно)
  AI3 отношение двух параллелизмов = разрешение эталона, и оно
      количественно
  AI4 ЧЕСТНО: AI1/AI2 качественно ИЗВЕСТНЫ (параллелизм LTEE —
      знаменитый результат). Проверяется не факт, а то, ПРЕДСКАЗЫВАЕТ ЛИ
      его наша рамка, построенная на другом материале.
"""
import sys
from collections import Counter
import numpy as np

D = "/home/claude/ltee/data_files"
POPS = ['m1', 'm2', 'm3', 'm4', 'm5', 'm6', 'p1', 'p2', 'p3', 'p4', 'p5', 'p6']
NON = ['m5', 'm6', 'p1', 'p2', 'p4', 'p5']


def load_hits(pop):
    """(позиция, ген) для мутаций, ДОСТИГШИХ закрепления или полиморфизма."""
    pos, gene = [], []
    with open(f"{D}/{pop}_annotated_timecourse.txt") as fh:
        fh.readline()
        for line in fh:
            p = line.split(", ")
            if len(p) < 15:
                continue
            g = p[1].strip()
            if not g or g in ("intergenic", "."):
                continue
            pos.append(p[0].strip()); gene.append(g)
    return pos, gene


def parallelism(sets):
    """Во скольких популяциях встречается элемент; среднее по элементам."""
    c = Counter()
    for s in sets:
        for x in set(s):
            c[x] += 1
    n = len(sets)
    tot = sum(c.values())
    shared = sum(v for v in c.values() if v > 1)
    multi = sum(1 for v in c.values() if v > 1)
    return dict(unique=len(c), total=tot, shared_frac=shared / max(tot, 1),
                multi=multi, mean_pops=tot / max(len(c), 1))


def null_expect(sizes, universe, n_draw=200, seed=0):
    """Случайная модель: те же объёмы, равномерно по вселенной элементов."""
    rng = np.random.default_rng(seed)
    U = np.arange(universe)
    vals = []
    for _ in range(n_draw):
        sets = [rng.choice(U, size=min(s, universe), replace=False) for s in sizes]
        vals.append(parallelism(sets)["mean_pops"])
    return float(np.mean(vals)), float(np.std(vals))


if __name__ == "__main__":
    pops = NON if sys.argv[1] == "non" else POPS
    P, G = [], []
    for pop in pops:
        a, b = load_hits(pop)
        P.append(a); G.append(b)
        print(f"  {pop}: {len(a)} генных мутаций", flush=True)
    rg, rp = parallelism(G), parallelism(P)
    print(f"\n=== параллелизм по {len(pops)} популяциям ===")
    print(f"{'уровень':<14}{'уникальных':>12}{'всего':>9}{'сред. попул.':>14}"
          f"{'доля общих':>12}")
    print(f"{'ГЕН':<14}{rg['unique']:>12}{rg['total']:>9}"
          f"{rg['mean_pops']:>14.3f}{rg['shared_frac']:>12.3f}")
    print(f"{'НУКЛЕОТИД':<14}{rp['unique']:>12}{rp['total']:>9}"
          f"{rp['mean_pops']:>14.3f}{rp['shared_frac']:>12.3f}")
    sizes = [len(x) for x in G]
    mg, sg = null_expect(sizes, rg['unique'])
    mp, sp = null_expect([len(x) for x in P], rp['unique'])
    print(f"\n  случайная модель ГЕН      : {mg:.3f} +- {sg:.3f}   "
          f"-> избыток x{rg['mean_pops']/mg:.2f}")
    print(f"  случайная модель НУКЛЕОТИД: {mp:.3f} +- {sp:.3f}   "
          f"-> избыток x{rp['mean_pops']/mp:.2f}")
    print(f"\n  РАЗРЕШЕНИЕ ЭТАЛОНА = отношение избытков: "
          f"{(rg['mean_pops']/mg)/(rp['mean_pops']/mp):.2f}")
