"""
BEHAV-007 — различить два прочтения нуля путей из BEHAV-006.

  (а) набор ограничений беден  -> при добавлении считываний число путей
      растёт ПЛАВНО
  (б) шаг эволюции = связка инвариантов, а не один -> число путей остаётся
      нулём при любом наборе, но появляется, если разрешить добавлять
      по k>1 инварианту за шаг

Метод: считаем ПОЛНЫЙ набор считываний один раз для всех 256 конфигураций,
затем берём его префиксы и для каждого строим граф достижимости.

ПРЕДРЕГИСТРАЦИЯ:
  R1 CV (пространственная дисперсия) сделает GR видимым: диффузия сохраняет
     среднее, но УМЕНЬШАЕТ дисперсию
  R2 число различимых сигнатур вырастет с 25 к >100
  R3 если верно (а) — пути появятся при добавлении CV
  R4 если верно (б) — пути останутся 0 при k=1 и появятся при k=2
"""
import math
import sys
import numpy as np
import behav005 as B

INV = B.INV
NI = len(INV)
cfg_of = lambda m: {k: bool(m >> i & 1) for i, k in enumerate(INV)}


def binned(x, edges):
    return int(np.digitize([x], edges)[0])


def probes(cfg):
    """Все считывания разом. Дискретизованы — иначе сравнение сигнатур бессмысленно."""
    g = {}
    pk = B.peaks

    p, _ = pk(cfg, n=20, isi=5.0)
    ok = p[0] > 1e-9
    g["H1"] = bool(ok and np.all(np.diff(p) <= 1e-9) and p[-1] < 0.7 * p[0])
    g["rank"] = B.rank_of(p) if ok else 0

    if not g["H1"]:
        for k in ("H2", "H4", "H5", "H6"):
            g[k] = None
        r5 = r400 = None
    else:
        a, ra = pk(cfg, n=20, isi=5.0, wait=5.0)
        b, rb = pk(cfg, n=20, isi=5.0, wait=400.0)
        r5, r400 = ra / max(a[0], 1e-12), rb / max(b[0], 1e-12)
        g["H2"] = bool(r400 > r5 + 0.05)
        f2, _ = pk(cfg, n=20, isi=2.0); f4, _ = pk(cfg, n=20, isi=40.0)
        g["H4"] = bool(f2[-1] / max(f2[0], 1e-12)
                       < f4[-1] / max(f4[0], 1e-12) - .05)
        lo, _ = pk(cfg, n=20, isi=5.0, amp=0.5)
        hi, _ = pk(cfg, n=20, isi=5.0, amp=16.0)
        g["H5"] = bool(lo[-1] / max(lo[0], 1e-12)
                       < hi[-1] / max(hi[0], 1e-12) - .05)
        s20, q20 = pk(cfg, n=20, isi=5.0, wait=100.0)
        s120, q120 = pk(cfg, n=120, isi=5.0, wait=100.0)
        g["H6"] = bool(q120 / max(s120[0], 1e-12)
                       < q20 / max(s20[0], 1e-12) - .05)

    if cfg["CH"]:
        p0, _ = pk(cfg, n=20, isi=5.0, chan=0)
        p1, _ = pk(cfg, n=20, isi=5.0, chan=1)
        g["H7"] = bool(abs(p0[-1] / max(p0[0], 1e-12)
                           - p1[-1] / max(p1[0], 1e-12)) > 0.05)
    else:
        g["H7"] = None

    multi = cfg["N"]
    if multi and cfg["EX"]:
        pa, _ = pk(cfg, n=20, isi=5.0, site="ant")
        pp, _ = pk(cfg, n=20, isi=5.0, site="post")
        den = max(abs(pa[0]), abs(pp[0]), 1e-12)
        g["CS"] = bool(abs(pa[0] - pp[0]) / den > 0.05)
        pu = B.peaks_units(cfg, n=5, isi=5.0, site="ant")
        near, far = float(pu[0]), float(pu[-1])
        g["CG"] = bool(abs(far) > 0.05 * max(abs(near), 1e-12))
    else:
        g["CS"] = g["CG"] = None

    # --- НОВЫЕ считывания ---
    # CV: пространственная дисперсия отклика (диффузия её УМЕНЬШАЕТ)
    if multi:
        u = B.peaks_units(cfg, n=20, isi=5.0)
        m = float(np.mean(np.abs(u)))
        cv = float(np.std(u) / m) if m > 1e-12 else 0.0
        g["CV"] = binned(cv, [1e-3, 1e-2, 0.05, 0.15, 0.4])
    else:
        g["CV"] = None

    # CT: задержка распространения (пик на дальнем узле относительно ближнего)
    if multi and cfg["EX"]:
        t, Y, on, tp, YU = B.simulate(cfg, dict(n=5, isi=5.0, site="ant"))
        w = (t >= on[0]) & (t < on[0] + B.DUR * 8)
        seg = YU[w]
        if seg.max() > 1e-12:
            lat = float(seg[:, -1].argmax() - seg[:, 0].argmax()) * B.DT
        else:
            lat = 0.0
        g["CT"] = binned(lat, [0.05, 0.3, 1.0, 3.0])
    else:
        g["CT"] = None

    # CD: режим удержания — глубина остаточного нарушения после долгой паузы
    g["CD"] = binned(1.0 - r400, [0.02, 0.1, 0.3, 0.6]) if r400 is not None else None

    # CP: пластичность — падает ли отклик на СИЛЬНЫЙ (негабитуированный) стимул
    if g["H1"]:
        hi0, _ = pk(cfg, n=1, isi=5.0, amp=16.0)
        hiL, q = pk(cfg, n=120, isi=5.0, wait=100.0, amp=16.0)
        g["CP"] = binned(1.0 - q / max(hi0[0], 1e-12), [0.02, 0.1, 0.3, 0.6])
    else:
        g["CP"] = None
    return g


ORDER = ["H1", "rank", "H2", "H4", "H5", "H6", "H7", "CS", "CG",
         "CV", "CT", "CD", "CP"]


def reach(sigs, k=1):
    """Число путей из пустого в полное; шаг добавляет от 1 до k инвариантов."""
    FULL = (1 << NI) - 1
    paths = {0: 1}
    edges = 0
    for m in sorted(range(1 << NI), key=lambda x: bin(x).count("1")):
        if m not in paths:
            continue
        missing = [i for i in range(NI) if not (m >> i & 1)]
        for r in range(1, k + 1):
            from itertools import combinations
            for comb in combinations(missing, r):
                m2 = m
                for i in comb:
                    m2 |= 1 << i
                if sigs[m2] != sigs[m]:
                    paths[m2] = paths.get(m2, 0) + paths[m]
                    edges += 1
    return paths.get(FULL, 0), edges


if __name__ == "__main__":
    print("считаю полный набор считываний для 256 конфигураций...", file=sys.stderr)
    G = {}
    for m in range(1 << NI):
        G[m] = probes(cfg_of(m))
        if m % 64 == 0:
            print(f"  {m}/256", file=sys.stderr)

    tot = math.factorial(NI)
    print("=== число путей vs размер набора считываний (k=1) ===")
    print(f"{'считываний':>11}{'добавлено':>10}{'сигнатур':>10}{'путей':>10}")
    for n in range(1, len(ORDER) + 1):
        keys = ORDER[:n]
        sigs = {m: tuple(G[m][k] for k in keys) for m in G}
        p, _ = reach(sigs, k=1)
        print(f"{n:>11}{keys[-1]:>10}{len(set(sigs.values())):>10}{p:>10}")

    print("\n=== тест на связки: сколько инвариантов за шаг нужно ===")
    full = {m: tuple(G[m][k] for k in ORDER) for m in G}
    base = {m: tuple(G[m][k] for k in ORDER[:9]) for m in G}
    print(f"{'k':>3}{'путей (набор 9)':>18}{'путей (набор 13)':>18}")
    for k in (1, 2, 3):
        pb, _ = reach(base, k)
        pf, _ = reach(full, k)
        print(f"{k:>3}{pb:>18}{pf:>18}")

    print(f"\n  для сравнения: 8! = {tot}")
    act = {kk: 0 for kk in INV}
    for m in range(1 << NI):
        for i, kk in enumerate(INV):
            if not (m >> i & 1) and full[m | (1 << i)] != full[m]:
                act[kk] += 1
    print("  неинертность при ПОЛНОМ наборе считываний (из 128):")
    print("   " + "  ".join(f"{kk}={act[kk]}" for kk in INV))
