"""BEHAV-038 / AP1(а) — РАЗМЕР как объяснение падения. Строгий критерий: МЕДИАЦИЯ."""
import json
import numpy as np

BINS = [(0, 1, "<1д"), (1, 3, "1-3д"), (3, 10, "3-10д"), (10, 1e9, ">10д")]


def load_stat():
    st = {}
    cur = None
    for f in ("a", "b", "c"):
        for l in open(f"/home/claude/stat_{f}.txt", encoding="utf-8", errors="replace"):
            l = l.rstrip("\n")
            if l.startswith("C|"):
                cur = l[2:]; st[cur] = [0, 0]
            elif l.strip() and cur:
                p = l.split("\t")
                if len(p) >= 3:
                    st[cur][1] += 1
                    for x in p[:2]:
                        if x.isdigit(): st[cur][0] += int(x)
    return st


if __name__ == "__main__":
    samp = json.load(open("/home/claude/samp.json"))
    st = load_stat()
    for r in samp:
        s = st.get(r["orig_sha"])
        r["lines"], r["files"] = (s if s else (None, None))
    g = [r for r in samp if r["lines"] is not None]
    print(f"выборка с diff: {len(g)} из {len(samp)}")
    L = np.array([r["lines"] for r in g]); F = np.array([r["files"] for r in g])
    print(f"  строк: медиана {np.median(L):.0f}, квартили "
          f"{np.percentile(L,25):.0f}/{np.percentile(L,75):.0f}")

    print(f"\n=== растёт ли РАЗМЕР с глубиной? ===")
    print(f"{'':<16}" + "".join(f"{t:>16}" for _, _, t in BINS))
    med = []
    for a, b, _ in BINS:
        gg = [r for r in g if a <= r["life"] < b]
        med.append(np.median([r["lines"] for r in gg]) if gg else np.nan)
    print(f"{'медиана строк':<16}" + "".join(f"{m:>16.0f}" for m in med))
    for a, b, _ in BINS:
        pass
    print(f"{'медиана файлов':<16}" + "".join(
        f"{np.median([r['files'] for r in g if a <= r['life'] < b]):>16.0f}"
        for a, b, _ in BINS))

    print(f"\n=== СТРОГИЙ КРИТЕРИЙ: исчезает ли падение ВНУТРИ страт по размеру? ===")
    q = np.percentile(L, [33, 66])
    names = [f"мелкие (<{q[0]:.0f} стр)", f"средние", f"крупные (>{q[1]:.0f} стр)"]
    print(f"{'страта':<22}" + "".join(f"{t:>14}" for _, _, t in BINS))
    for k, nm in enumerate(names):
        lo = -1 if k == 0 else q[k-1]
        hi = q[k] if k < 2 else 1e18
        sub = [r for r in g if lo < r["lines"] <= hi]
        cells = []
        for a, b, _ in BINS:
            gg = [r for r in sub if a <= r["life"] < b]
            cells.append(f"{np.mean([x['back'] for x in gg]):.3f}({len(gg)})"
                         if len(gg) >= 15 else "—")
        print(f"{nm:<22}" + "".join(f"{c:>14}" for c in cells))
    print(f"\n  МЕДИАЦИЯ засчитана, только если падение исчезает ВО ВСЕХ стратах")
