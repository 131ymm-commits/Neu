"""BEHAV-032 / AL1+AL3 — репликация и зависимость от глубины поломки."""
import random
import re
import sys
import numpy as np
import behav031 as B


def analyse(logpath, seed=0):
    rows = []
    for l in open(logpath, encoding="utf-8", errors="replace"):
        p = l.rstrip("\n").split("|", 2)
        if len(p) == 3:
            rows.append((p[0], int(p[1]), p[2]))
    rows.sort(key=lambda r: r[1])
    n = len(rows)
    subj = [r[2] for r in rows]; ts = [r[1] for r in rows]
    key = [B.norm(s) for s in subj]
    idx = {}
    for i, k in enumerate(key):
        idx.setdefault(k, []).append(i)
    relands = {}
    for i, s in enumerate(subj):
        m = B.RELAND.match(s.strip())
        if m and m.group(1):
            relands.setdefault(B.norm(m.group(1)), []).append(i)
    rev = []
    for i, s in enumerate(subj):
        m = B.REV.match(s.strip())
        if m:
            rev.append((i, B.norm(m.group(1))))
    out = []
    for i, o in rev:
        pre = [j for j in idx.get(o, []) if j < i]          # оригинал
        post = [j for j in idx.get(o, []) if j > i] + \
               [j for j in relands.get(o, []) if j > i]
        life = (ts[i] - ts[max(pre)]) / 86400.0 if pre else None
        out.append(dict(i=i, back=bool(post), life=life,
                        strict=len(idx.get(o, [])) == 2))
    random.seed(seed)
    hits = 0
    for _ in range(6000):
        i = random.randrange(min(1000, n // 4), n)
        o = key[random.randrange(0, i)]
        hits += any(j > i for j in idx.get(o, []))
    return n, len(rev), out, hits / 6000, sum(len(v) for v in relands.values())


if __name__ == "__main__":
    print(f"{'проект':<10}{'коммитов':>10}{'revert':>8}{'%':>6}"
          f"{'Reland':>8}{'ВОЗВРАТ':>9}{'нуль':>8}{'x':>7}{'строгий':>9}")
    for name, path in [("pytorch", "/home/claude/pt_log.txt"),
                       ("django", "/home/claude/django_log.txt"),
                       ("node", "/home/claude/node_log.txt")]:
        n, nr, out, null, nrl = analyse(path)
        r = np.mean([o["back"] for o in out]) if out else np.nan
        st = np.mean([o["back"] and o["strict"] for o in out]) if out else np.nan
        print(f"{name:<10}{n:>10}{nr:>8}{100*nr/n:>6.1f}{nrl:>8}"
              f"{r:>9.3f}{null:>8.3f}{r/max(null,1e-9):>7.1f}{st:>9.3f}", flush=True)
        if name == "pytorch":
            L = [o for o in out if o["life"] is not None]
            print("\n  AL3: возврат против ВРЕМЕНИ ЖИЗНИ до отката (pytorch)")
            print(f"    {'дней жизни':>14}{'n':>7}{'возврат':>10}")
            edges = [0, 0.25, 1, 3, 10, 30, 1e9]
            lab = ["<6ч", "6ч-1д", "1-3д", "3-10д", "10-30д", ">30д"]
            for a, b, t in zip(edges[:-1], edges[1:], lab):
                g = [o for o in L if a <= o["life"] < b]
                if g:
                    print(f"    {t:>14}{len(g):>7}"
                          f"{np.mean([x['back'] for x in g]):>10.3f}")
            print()
