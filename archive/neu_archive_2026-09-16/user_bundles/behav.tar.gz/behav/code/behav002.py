"""
BEHAV-002 — УДЕРЖАНИЕ нарушения симметрии.

Протокол R: (1) сломать симметрию тренировкой, (2) убрать вход,
(3) мерить, как параметр порядка возвращается к нулю.

Режимы:
  R1 замороженное  — не возвращается вообще
  R2 поддерживаемое — экспоненциальный возврат с временем tau
  R3 кодируемое     — ПОРОГ: ниже порога не возвращается, выше — коллапс
                      (аналог порога ошибок Эйгена)
"""
import numpy as np

DT, BASE, DUR, AMP = 0.05, 1.0, 0.5, 4.0
sig = lambda x: 1.0 / (1.0 + np.exp(-x))
TH = (np.log1p(BASE) + np.log1p(BASE + AMP)) / 2


def build(n, isi, wait, amp=AMP):
    """цуг из n импульсов, пауза wait, затем один пробный импульс."""
    T = 5 + n * isi + wait + 10
    t = np.arange(0, T, DT)
    u = np.full_like(t, BASE)
    on = 5 + np.arange(n) * isi
    for o in on:
        u[(t >= o) & (t < o + DUR)] = BASE + amp
    tp = 5 + n * isi + wait
    u[(t >= tp) & (t < tp + DUR)] = BASE + amp
    return t, u, on, tp


def pool(t, u, k=0.8, tau_r=40.0, beta=10.0, deep=False,
         kd=0.05, tau_d=2000.0, tau_y=0.1):
    A = sig(beta * (np.log1p(u) - TH))
    r, d, y = 1.0, 0.0, 0.0
    Y = np.empty_like(t)
    for i in range(len(t)):
        a = A[i]
        dr = -k * a * r + (1 - r - d) / tau_r
        dd = 0.0
        if deep:
            dd = kd * a * r - d / tau_d
            dr -= kd * a * r
        r = min(1.0, max(0.0, r + DT * dr))
        d = min(1.0, max(0.0, d + DT * dd))
        y += DT / tau_y * (a * r - y)
        Y[i] = y
    return Y


def hyst(t, u, tau=None, N=3000, seed=0):
    rng = np.random.default_rng(seed)
    hup = rng.uniform(0.1, 2.5, N)
    hdn = hup - rng.uniform(0.3, 1.5, N)
    st = np.zeros(N, bool)
    taus = None if tau is None else np.exp(
        rng.uniform(np.log(tau[0]), np.log(tau[1]), N))
    g = np.random.default_rng(seed + 1)
    R = np.empty_like(t)
    for i in range(len(t)):
        b = st.copy()
        st |= (u[i] >= hup)
        st &= ~(u[i] <= hdn)
        if taus is not None:
            st &= ~(st & (g.random(N) < DT / taus))
        R[i] = (st & ~b).sum()
    return R


def peak(t, y, t0, win=DUR * 4):
    return float(y[(t >= t0) & (t < t0 + win)].max())


def retention(f, waits=(1, 3, 10, 30, 100, 300, 1000), n=20, isi=5.0):
    """Параметр порядка phi = 1 - p_probe/p_naive. phi=1 -> держит, 0 -> отпустил."""
    out = {}
    for w in waits:
        t, u, on, tp = build(n, isi, w)
        y = f(t, u)
        p_naive = peak(t, y, on[0])
        p_probe = peak(t, y, tp)
        out[w] = 1.0 - (p_probe + 1e-15) / (p_naive + 1e-15)
    return out


def classify(phi, waits):
    """R1 если phi почти не падает; R2 если падает; оценка tau."""
    w = np.array(sorted(phi)); v = np.array([phi[x] for x in w])
    v0, vend = v[0], v[-1]
    if v0 < 0.05:
        return "R0/нет нарушения", None
    drop = (v0 - vend) / max(v0, 1e-12)
    if drop < 0.15:
        return "R1 замороженное", None
    half = v0 / 2
    idx = np.where(v <= half)[0]
    tau = float(w[idx[0]]) if len(idx) else float(w[-1])
    return "R2 поддерживаемое", tau


# ------------------------------------------------- R3: удержание копированием
def r3_retention(N, eps, mu, steps=20000, seed=0):
    """
    N носителей, каждый хранит бит нарушения. За шаг:
      - каждый портится с вероятностью eps
      - затем каждый с вероятностью mu переписывается по большинству
    Возвращаем время до потери большинства (= симметрия восстановилась).
    """
    rng = np.random.default_rng(seed)
    s = np.ones(N, bool)
    for k in range(steps):
        s &= ~(rng.random(N) < eps)                 # порча
        maj = s.sum() * 2 > N
        if mu > 0:
            fix = rng.random(N) < mu
            s[fix] = maj                            # коррекция по большинству
        if s.sum() * 2 <= N:
            return k
    return steps


if __name__ == "__main__":
    waits = (1, 3, 10, 30, 100, 300, 1000)
    SYS = {
        "Pool(1 шкала)":    lambda t, u: pool(t, u),
        "Pool+T2":          lambda t, u: pool(t, u, deep=True),
        "HYS без релакс.":  lambda t, u: hyst(t, u, tau=None),
        "HYS + релакс.":    lambda t, u: hyst(t, u, tau=(3.0, 300.0)),
    }
    print("=== ПРОТОКОЛ R: параметр порядка после снятия входа ===")
    print(f"{'система':<18}" + "".join(f"{w:>8}" for w in waits) + "   режим")
    for name, f in SYS.items():
        phi = retention(f, waits)
        reg, tau = classify(phi, waits)
        line = "".join(f"{phi[w]:>8.3f}" for w in waits)
        extra = f"  (tau~{tau:g})" if tau else ""
        print(f"{name:<18}{line}   {reg}{extra}")

    print("\n=== R3: удержание копированием (порог, а не экспонента) ===")
    print("время жизни нарушения при eps=0.02, в шагах (потолок 20000)")
    print(f"{'mu':>6}" + "".join(f"{'N='+str(N):>10}" for N in (5, 11, 21, 41)))
    for mu in (0.0, 0.05, 0.10, 0.15, 0.20, 0.30, 0.50):
        row = []
        for N in (5, 11, 21, 41):
            v = np.median([r3_retention(N, 0.02, mu, seed=s) for s in range(7)])
            row.append(v)
        print(f"{mu:>6.2f}" + "".join(f"{int(v):>10}" for v in row))
