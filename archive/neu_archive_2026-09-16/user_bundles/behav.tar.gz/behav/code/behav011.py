"""
BEHAV-011 — первый ВНЕШНИЙ якорь: правило Дрейка.

Реальность: u*G ~ const (0.003 у ДНК-микробов, ~1 у РНК-вирусов),
четыре порядка по размеру генома.

Наша машинерия (BEHAV-002/004) знает порог удержания копированием.
Вопрос: даёт ли она границу u*L = const?

ПРЕДРЕГИСТРАЦИЯ:
  D1 L_max ~ 1/eps (граница Дрейка воспроизводится)
  D2 произведение eps*L_max при фиксированном горизонте ~ const по eps
  D3 корректор (mu>0) сдвигает константу вверх, не меняя закона ~1/eps
  D4 БЕЗ отбора ничто не заставляет систему сидить НА границе —
     модель даст границу, но не её насыщение
"""
import numpy as np


def hold_time(L, N, eps, mu, steps, seed=0):
    """L битов, каждый на N носителях. Возврат: шаг, когда ЛЮБОЙ бит потерян."""
    rng = np.random.default_rng(seed)
    s = np.ones((L, N), bool)
    for k in range(steps):
        nz = rng.random((L, N)) < eps
        if nz.any():
            s[nz] = rng.random(int(nz.sum())) < 0.5      # симметричный шум
        if mu > 0:
            maj = (s.sum(axis=1) * 2 > N)                # мажоритарный шаблон
            fix = rng.random((L, N)) < mu
            s = np.where(fix, maj[:, None], s)
        if not np.all(s.sum(axis=1) * 2 > N):
            return k
    return steps


def Lmax(N, eps, mu, T, seeds=5, hi=4096):
    """Наибольшее L, удерживаемое T шагов (медиана по seeds)."""
    lo, best = 1, 0
    while lo <= hi:
        mid = (lo + hi) // 2
        t = np.median([hold_time(mid, N, eps, mu, T, seed=s) for s in range(seeds)])
        if t >= T:
            best = mid; lo = mid + 1
        else:
            hi = mid - 1
    return best


if __name__ == "__main__":
    T, N = 300, 21
    print("=== D1/D2: L_max против eps (T=300 шагов, N=21 носителей) ===")
    print(f"{'mu':>6}{'eps':>10}{'L_max':>8}{'eps*L_max':>12}")
    for mu in (0.0, 0.10, 0.25):
        prods = []
        for eps in (0.2, 0.1, 0.05, 0.02, 0.01):
            L = Lmax(N, eps, mu, T)
            prods.append(eps * L)
            print(f"{mu:>6.2f}{eps:>10.3f}{L:>8}{eps*L:>12.3f}")
        p = np.array(prods)
        print(f"       -> eps*L_max: среднее {p.mean():.3f}, "
              f"разброс {p.std()/max(p.mean(),1e-9)*100:.0f}%  "
              f"(при законе 1/eps должен быть ~0%)\n")
