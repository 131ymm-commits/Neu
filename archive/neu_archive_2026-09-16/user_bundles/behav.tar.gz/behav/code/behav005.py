"""
BEHAV-005 — вывод предпосылок через ПОВЕДЕНЧЕСКУЮ ИНЕРТНОСТЬ.

Определение: инвариант B инертен без инварианта A, если включение/выключение B
НЕ МЕНЯЕТ набор выполненных ограничений при выключенном A.
Тогда A < B (A обязан появиться раньше).

Инертность считается относительно НАБОРА ОГРАНИЧЕНИЙ, а не сырых чисел:
любое изменение параметра двигает какое-нибудь число, но не любое меняет
то, ЧТО система может.

ВАЖНО: инертность контекстно-зависима (какие ещё инварианты включены).
Считаем в двух контекстах: минимальном (все прочие off) и полном (все on).
Если DAG различается — это само по себе результат.

ПРЕДРЕГИСТРАЦИЯ:
  Q1  выведенных предпосылок будет больше 4 (постулированных)
  Q2  число историй упадёт ниже 3360
  Q3  часть предпосылок окажется СТРУКТУРНЫМИ (B неопределим без A) —
      их надо считать отдельно, они дешёвые
  Q4  DAG будет различаться между минимальным и полным контекстом
"""
import itertools
import numpy as np

DT, BASE, AMP, DUR = 0.1, 1.0, 4.0, 0.5
sig = lambda x: 1.0 / (1.0 + np.exp(-x))
TH0 = (np.log1p(BASE) + np.log1p(BASE + AMP)) / 2
INV = ["NL", "T2", "CH", "EX", "PO", "N", "GR", "PL"]


# ------------------------------------------------------------------- модель
def simulate(cfg, prot):
    """
    prot: dict(n, isi, amp, wait, chan, site)
      chan: 0/1 — каким каналом стимулируем
      site: 'all'|'ant'|'post' — куда (имеет смысл при EX)
    Возвращает временной ряд агрегированного отклика.
    """
    M = 8 if cfg["N"] else 1
    C = 2 if cfg["CH"] else 1
    n, isi = prot["n"], prot["isi"]
    T = 5 + n * isi + prot.get("wait", 0) + 10
    t = np.arange(0, T, DT)
    L = len(t)

    # пространственный профиль входа
    w = np.ones(M)
    if cfg["EX"] and M > 1:
        if prot.get("site") == "ant":
            w = np.exp(-np.arange(M) / 1.5)
        elif prot.get("site") == "post":
            w = np.exp(-(M - 1 - np.arange(M)) / 1.5)
    # пороги: PO даёт направленный градиент
    th = np.full(M, TH0)
    if cfg["PO"] and M > 1:
        th = TH0 + 0.35 * (np.arange(M) / (M - 1) - 0.5)
    # веса каналов
    cw = np.zeros(C); cw[prot.get("chan", 0) % C] = 1.0
    chan_off = np.array([0.0, 0.45])[:C]      # каналы различимы по порогу

    on = 5 + np.arange(n) * isi
    tp = 5 + n * isi + prot["wait"] if prot.get("wait") else None
    pulse = np.zeros(L, bool)
    for o in on:
        pulse |= (t >= o) & (t < o + DUR)
    probe = np.zeros(L, bool)
    if tp is not None:
        probe = (t >= tp) & (t < tp + DUR)
        if prot.get("probe_chan") is not None:
            pass

    D = 0.25 if (cfg["GR"] and M > 1) else 0.0
    kd = 0.05 if cfg["T2"] else 0.0
    r = np.ones(M); d = np.zeros(M); y = np.zeros(M); s = np.zeros(M)
    YU = np.zeros((L, M))
    dth = np.zeros(M)
    Y = np.empty(L)
    amp = prot.get("amp", AMP)
    for i in range(L):
        uu = BASE + (amp * w if (pulse[i] or probe[i]) else 0.0)
        E = np.log1p(uu)
        eff = th + dth + chan_off[prot.get("chan", 0) % C]
        if cfg["NL"]:
            a = sig(10.0 * (E - eff))
            dr = -0.8 * a * r + (1 - r - d) / 40.0 - kd * a * r
            d = np.clip(d + DT * (kd * a * r - d / 2000.0), 0, 1)
            r = np.clip(r + DT * dr, 0, 1)
            resp = a * r
        else:                                   # линейный: high-pass фильтр
            s += DT / 8.0 * (E - s)
            resp = np.maximum(E - s, 0.0) if False else (E - s)
            if cfg["T2"]:                       # вторая линейная шкала
                resp = resp * 0.6 + 0.4 * (E - s) * 0.5
        y += DT / 0.1 * (resp - y)
        if D > 0 and M > 1:
            y = y + D * DT * (np.roll(y, 1) + np.roll(y, -1) - 2 * y)
        if cfg["PL"]:
            dth += DT * (0.02 * np.maximum(y, 0) - dth / 800.0)
        Y[i] = y.mean(); YU[i] = y
    return t, Y, on, tp, YU


def pk(t, Y, o, w=DUR * 4):
    return float(Y[(t >= o) & (t < o + w)].max())


def peaks_units(cfg, **prot):
    t, Y, on, tp, YU = simulate(cfg, prot)
    w = DUR * 4
    sl = (t >= on[0]) & (t < on[0] + w)
    return YU[sl].max(axis=0)


def peaks(cfg, **prot):
    t, Y, on, tp, YU = simulate(cfg, prot)
    p = np.array([pk(t, Y, o) for o in on])
    pr = pk(t, Y, tp) if tp else None
    return p, pr


# --------------------------------------------------------------- ограничения
def rank_of(p, tol=0.03):
    p = np.asarray(p, float); p = p - p[-3:].mean()
    if np.abs(p).max() < 1e-9:
        return 0
    n = len(p); L = n // 2
    H = np.array([[p[i + j] for j in range(L)] for i in range(n - L)])
    s = np.linalg.svd(H, compute_uv=False)
    return int((s / s[0] > tol).sum())


def signature(cfg):
    """Вектор выполненных ограничений. Это и есть 'что система может'."""
    sg = {}
    p, _ = peaks(cfg, n=20, isi=5.0)
    ok = p[0] > 1e-9
    sg["H1"] = bool(ok and np.all(np.diff(p) <= 1e-9) and p[-1] < 0.7 * p[0])
    sg["rank"] = rank_of(p) if ok else 0
    if not sg["H1"]:
        for k in ("H2", "H4", "H5", "H6"):
            sg[k] = None
    else:
        a, ra = peaks(cfg, n=20, isi=5.0, wait=5.0)
        b, rb = peaks(cfg, n=20, isi=5.0, wait=400.0)
        sg["H2"] = bool(rb / max(b[0], 1e-12) > ra / max(a[0], 1e-12) + 0.05)
        f2, _ = peaks(cfg, n=20, isi=2.0); f4, _ = peaks(cfg, n=20, isi=40.0)
        sg["H4"] = bool(f2[-1] / max(f2[0], 1e-12) < f4[-1] / max(f4[0], 1e-12) - .05)
        lo, _ = peaks(cfg, n=20, isi=5.0, amp=0.5)
        hi, _ = peaks(cfg, n=20, isi=5.0, amp=16.0)
        sg["H5"] = bool(lo[-1] / max(lo[0], 1e-12) < hi[-1] / max(hi[0], 1e-12) - .05)
        s20, r20 = peaks(cfg, n=20, isi=5.0, wait=100.0)
        s120, r120 = peaks(cfg, n=120, isi=5.0, wait=100.0)
        sg["H6"] = bool(r120 / max(s120[0], 1e-12) < r20 / max(s20[0], 1e-12) - .05)
    # H7: специфичность к каналу
    if cfg["CH"]:
        p0, _ = peaks(cfg, n=20, isi=5.0, chan=0)
        p1, _ = peaks(cfg, n=20, isi=5.0, chan=1)
        sg["H7"] = bool(abs(p0[-1] / max(p0[0], 1e-12)
                            - p1[-1] / max(p1[0], 1e-12)) > 0.05)
    else:
        sg["H7"] = None
    # CS: пространственная избирательность (перед vs зад)
    if cfg["N"] and cfg["EX"]:
        pa, _ = peaks(cfg, n=20, isi=5.0, site="ant")
        pp, _ = peaks(cfg, n=20, isi=5.0, site="post")
        den = max(abs(pa[0]), abs(pp[0]), 1e-12)
        sg["CS"] = bool(abs(pa[0] - pp[0]) / den > 0.05)
    else:
        sg["CS"] = None
    # CG: распространение — стимул спереди, отклик сзади
    if cfg["N"] and cfg["EX"]:
        pu = peaks_units(cfg, n=5, isi=5.0, site="ant")
        far = float(pu[-1]); near = float(pu[0])
        sg["CG"] = bool(abs(far) > 0.05 * max(abs(near), 1e-12))
    else:
        sg["CG"] = None
    return tuple(sorted(sg.items()))


# ------------------------------------------------------- процедура инертности
_CACHE = {}


def sig_cached(cfg):
    key = tuple(sorted(cfg.items()))
    if key not in _CACHE:
        _CACHE[key] = signature(cfg)
    return _CACHE[key]


def inert(A, B, background):
    """ДИФФЕРЕНЦИАЛЬНО: A < B  <=>  B инертен без A  И  B активен с A."""
    if A == B:
        return None
    base = {k: background for k in INV}
    wo = dict(base); wo[A] = False
    wi = dict(base); wi[A] = True
    o1 = dict(wo); o1[B] = False
    o2 = dict(wo); o2[B] = True
    w1 = dict(wi); w1[B] = False
    w2 = dict(wi); w2[B] = True
    inert_without = sig_cached(o1) == sig_cached(o2)
    active_with = sig_cached(w1) != sig_cached(w2)
    return bool(inert_without and active_with)


def count_histories(prereq, items=INV):
    idx = {x: i for i, x in enumerate(items)}
    ok = 0
    for perm in itertools.permutations(range(len(items))):
        pos = {p: i for i, p in enumerate(perm)}
        if all(pos[idx[a]] < pos[idx[b]] for a, b in prereq):
            ok += 1
    return ok, __import__("math").factorial(len(items))


if __name__ == "__main__":
    POSTULATED = [("NL", "T2"), ("NL", "PL"), ("EX", "PO"), ("N", "GR")]
    print("=== постулированный DAG (BEHAV-001) ===")
    o, tot = count_histories(POSTULATED)
    print(f"  предпосылок 4 -> историй {o} из {tot} ({100*o/tot:.2f}%)\n")

    for bg_name, bg in (("минимальный (прочие off)", False),
                        ("полный (прочие on)", True)):
        print(f"=== фон: {bg_name} ===")
        derived = []
        for A in INV:
            row = []
            for Bx in INV:
                if A == Bx:
                    row.append(" ."); continue
                q = inert(A, Bx, bg)
                row.append(" +" if q else " -")
                if q:
                    derived.append((A, Bx))
            print(f"  {A:<3}" + "".join(row) + "   (+ = B инертен без A)")
        print("      " + "".join(f"{b:>2}"[-2:] for b in INV))
        # убрать циклы: если и A<B и B<A — противоречие, выкидываем обе
        bad = {(a, b) for a, b in derived if (b, a) in derived}
        clean = [e for e in derived if e not in bad]
        o, tot = count_histories(clean)
        print(f"  выведено {len(derived)}, взаимных (выкинуто) {len(bad)}, "
              f"годных {len(clean)}")
        print(f"  историй {o} из {tot} ({100*o/tot:.2f}%)")
        print(f"  предпосылки: {clean}\n")
