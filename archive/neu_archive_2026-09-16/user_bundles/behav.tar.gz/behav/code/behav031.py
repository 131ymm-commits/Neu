"""BEHAV-031 / AK3 — возвращается ли откатанное содержание? PyTorch, 109321 коммит."""
import re
import random
from collections import Counter
import numpy as np

LOG = "/home/claude/pt_log.txt"
REV = re.compile(r'^Revert\s+"(.*)"\s*$')
RELAND = re.compile(r'^(?:Re-?land|Reapply|Relanding)\b[:\s"]*(.*?)"?\s*$', re.I)


def norm(s):
    s = re.sub(r'\s*\(#\d+\)\s*$', '', s.strip())       # убрать номер PR
    s = re.sub(r'^\[[^\]]*\]\s*', '', s)                 # убрать [tag] в начале
    return re.sub(r'\s+', ' ', s).strip().lower()


def load():
    rows = []
    for l in open(LOG, encoding="utf-8", errors="replace"):
        p = l.rstrip("\n").split("|", 2)
        if len(p) == 3:
            rows.append((p[0], int(p[1]), p[2]))
    rows.sort(key=lambda r: r[1])                        # по времени ВПЕРЁД
    return rows


if __name__ == "__main__":
    rows = load()
    n = len(rows)
    subj = [r[2] for r in rows]
    ts = [r[1] for r in rows]
    key = [norm(s) for s in subj]

    # индекс: нормализованный заголовок -> список позиций
    idx = {}
    for i, k in enumerate(key):
        idx.setdefault(k, []).append(i)

    reverts = []
    for i, s in enumerate(subj):
        m = REV.match(s.strip())
        if m:
            reverts.append((i, norm(m.group(1))))
    relands = {}
    for i, s in enumerate(subj):
        m = RELAND.match(s.strip())
        if m and m.group(1):
            relands.setdefault(norm(m.group(1)), []).append(i)

    back, delays = 0, []
    for i, orig in reverts:
        later = [j for j in idx.get(orig, []) if j > i]
        later += [j for j in relands.get(orig, []) if j > i]
        if later:
            back += 1
            delays.append((ts[min(later)] - ts[i]) / 86400.0)
    rate = back / len(reverts)

    # K1: базовая ставка повтора заголовка у НЕ-откатанных коммитов
    rev_pos = {i for i, _ in reverts}
    rev_targets = {o for _, o in reverts}
    cand = [i for i in range(n) if i not in rev_pos and key[i] not in rev_targets]
    random.seed(0)
    samp = random.sample(cand, 5000)
    k1 = np.mean([any(j > i for j in idx[key[i]]) for i in samp])

    # K4: вырожденный — перемешать заголовки
    perm = key[:]; random.shuffle(perm)
    pidx = {}
    for i, k in enumerate(perm):
        pidx.setdefault(k, []).append(i)
    k4 = np.mean([1 if any(j > i for j in pidx.get(o, [])) else 0
                  for i, o in reverts])

    print(f"коммитов: {n}   revert-ов: {len(reverts)} "
          f"({100*len(reverts)/n:.1f}%, литература даёт 1-5%)")
    print(f"  явных Reland-коммитов: {sum(len(v) for v in relands.values())}")
    print(f"\n  ВОЗВРАТ откатанного содержания : {rate:.3f}  ({back}/{len(reverts)})")
    print(f"  K1 базовая ставка повтора      : {k1:.3f}")
    print(f"  K4 вырожденный (перемешано)    : {k4:.3f}")
    print(f"  отношение возврат/K1           : {rate/max(k1,1e-9):.1f}x")
    if delays:
        d = np.array(delays)
        print(f"\n  K3 задержка возврата, дней: медиана {np.median(d):.2f}, "
              f"квартили {np.percentile(d,25):.2f}/{np.percentile(d,75):.2f}, "
              f"доля <1 дня {np.mean(d<1):.2f}")
    print(f"\n  ПРОГНОЗ: возврат > 0.20 и >=5x от K1")
    print(f"  СМЕРТЬ:  возврат <= K1")
