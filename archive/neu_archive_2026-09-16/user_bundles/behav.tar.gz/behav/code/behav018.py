"""
BEHAV-018 / M1'' — непрерывное усреднение: 1/2 или 1?

Модель обучающегося: состояние носителя вещественное. Каждый шаг все
носители обновляются: новый носитель берёт k случайных наблюдений
(чужое состояние + шум sigma) и принимает их СРЕДНЕЕ. Ошибка выборочного
среднего ~ sigma/sqrt(k) — вот где живёт ЦПТ.

Сообщество стартует в x=1 (удерживаемый выбор), теряет его при <x> <= 0.

ДВА КОНКУРИРУЮЩИХ ПРОГНОЗА, записаны ДО прогона:
  Q1 (гипотеза M1''): скорость потери r ~ k^(-1/2)  =>  T_hold ~ k^(+1/2)
  Q2 (мой контррасчёт диффузией): среднее сообщества делает несмещённое
     блуждание с шагом ~ sigma/sqrt(k*N) за полное обновление
     =>  T_hold ~ Delta^2 * k * N / sigma^2  =>  T ~ k^1 и T ~ N^1.
Если победит Q2 — M1'' мертва, и sqrt-закон Либермана остаётся у нас
без объяснения (что честно фиксируется).
"""
import sys
import numpy as np


def hold_cont(N, k, sigma, steps, seed=0):
    rng = np.random.default_rng(seed)
    x = np.ones(N)
    for t in range(steps):
        idx = rng.integers(0, N, (N, k))
        obs = x[idx] + rng.normal(0, sigma, (N, k))
        x = obs.mean(axis=1)
        if x.mean() <= 0.0:
            return t
    return steps


def med_T(N, k, sigma=1.0, steps=300000, seeds=9):
    return float(np.median([hold_cont(N, k, sigma, steps, seed=s)
                            for s in range(seeds)]))


if __name__ == "__main__":
    what = sys.argv[1]
    if what == "k":
        N = 50
        ks = [2, 4, 8, 16, 32, 64]
        out = []
        for k in ks:
            T = med_T(N, k)
            out.append((k, T)); print(f"  k={k:>3}  T={T:.0f}", flush=True)
        x = np.log([o[0] for o in out]); y = np.log([o[1] for o in out])
        b = np.polyfit(x, y, 1)[0]
        print(f"T ~ k^{b:+.2f}   (Q1: +0.5   Q2: +1.0)")
    else:
        k = 8
        Ns = [25, 50, 100, 200, 400]
        out = []
        for N in Ns:
            T = med_T(N, k)
            out.append((N, T)); print(f"  N={N:>4}  T={T:.0f}", flush=True)
        x = np.log([o[0] for o in out]); y = np.log([o[1] for o in out])
        b = np.polyfit(x, y, 1)[0]
        print(f"T ~ N^{b:+.2f}   (Q2: +1.0)")
