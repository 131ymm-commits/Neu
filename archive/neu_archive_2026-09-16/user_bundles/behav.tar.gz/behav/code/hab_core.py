"""
BEHAV-000 / Tier-0
Примитив B0 (адаптивная единица с интегральной ОС) и гистеронная модель
"памяти в веществе". Батарея из 6 одностимульных признаков габитуации.

Предрегистрация в комментарии PREREG ниже. Не редактировать после прогона.
"""
import numpy as np

# ---------------------------------------------------------------- PREREG
PREREG = {
    # признак : (B0, hysteron_no_relax)
    "H1_decrement":  ("PASS", "PASS_step"),
    "H2_recovery":   ("PASS", "FAIL"),
    "H3_potentiat":  ("FAIL", "FAIL"),
    "H4_frequency":  ("PASS", "FAIL"),
    "H5_intensity":  ("?",    "PASS"),
    "H6_belowzero":  ("FAIL", "FAIL"),
}

# ---------------------------------------------------------------- stimuli
def pulse_train(T, dt, n, isi, dur, amp, base, t0=5.0):
    """s(t): базовый уровень + n прямоугольных импульсов."""
    t = np.arange(0, T, dt)
    s = np.full_like(t, base)
    onsets = t0 + np.arange(n) * isi
    for on in onsets:
        s[(t >= on) & (t < on + dur)] = base + amp
    return t, s, onsets


# ---------------------------------------------------------------- model B0
def sigma(x):
    return 1.0 / (1.0 + np.exp(-x))


def run_B0(t, s, K=1.0, tau_y=0.1, taus=(10.0,), y0=0.5, gains=None):
    """
    tau_y * dy/dt = sigma(E - sum(m_i)) - y
    tau_i * dm_i/dt = y - y0
    taus: кортеж времён адаптации. len>1 => оператор T применён.
    """
    dt = t[1] - t[0]
    E = np.log1p(s / K)
    ms = np.zeros(len(taus))
    if gains is None:
        gains = np.ones(len(taus))
    y = y0
    Y = np.empty_like(t)
    M = np.empty((len(t), len(taus)))
    for i in range(len(t)):
        drive = E[i] - np.dot(gains, ms)
        y += dt / tau_y * (sigma(drive) - y)
        ms += dt / np.asarray(taus) * (y - y0)
        Y[i] = y
        M[i] = ms
    return Y, M


def peaks(t, Y, onsets, dur, y0=0.5, win=None):
    """Амплитуда отклика на каждый импульс: max(y)-y0 в окне."""
    dt = t[1] - t[0]
    if win is None:
        win = dur * 4
    out = []
    for on in onsets:
        sl = (t >= on) & (t < on + win)
        out.append(Y[sl].max() - y0)
    return np.array(out)


# ---------------------------------------------------------- model hysteron
class Hysterons:
    """
    Preisach-подобный ансамбль. Каждый элемент: состояние 0/1,
    порог включения hup, порог выключения hdn < hup.
    tau=None -> без релаксации (чистая rate-independent память).
    """

    def __init__(self, N=4000, seed=0, tau_range=None):
        rng = np.random.default_rng(seed)
        self.hup = rng.uniform(0.1, 2.5, N)
        self.hdn = self.hup - rng.uniform(0.3, 1.5, N)
        self.state = np.zeros(N, dtype=bool)
        if tau_range is None:
            self.tau = None
        else:
            lo, hi = tau_range
            self.tau = np.exp(rng.uniform(np.log(lo), np.log(hi), N))

    def step(self, h, dt, rng):
        before = self.state.copy()
        self.state |= (h >= self.hup)
        self.state &= ~(h <= self.hdn)
        if self.tau is not None:  # спонтанный сброс вверх->вниз
            p = dt / self.tau
            flip = self.state & (rng.random(len(self.state)) < p)
            self.state &= ~flip
        return int((self.state & ~before).sum())  # число включений = отклик


def run_hyst(t, s, tau_range=None, seed=0, N=4000):
    dt = t[1] - t[0]
    H = Hysterons(N=N, seed=seed, tau_range=tau_range)
    rng = np.random.default_rng(seed + 1)
    R = np.empty(len(t))
    for i in range(len(t)):
        R[i] = H.step(s[i], dt, rng)
    return R


def peaks_hyst(t, R, onsets, dur):
    """Отклик = суммарное число включений за импульс."""
    return np.array([R[(t >= on) & (t < on + dur)].sum() for on in onsets])


# ---------------------------------------------------------------- battery
def battery(kind, taus=(10.0,), tau_range=None, dt=0.01, label=""):
    """kind in {'B0','H'}"""
    res = {}
    base, amp, dur = 1.0, 4.0, 0.5

    def resp(n, isi, amp=amp, extra_T=0.0):
        T = 5.0 + n * isi + 20.0 + extra_T
        t, s, on = pulse_train(T, dt, n, isi, dur, amp, base)
        if kind == "B0":
            Y, _ = run_B0(t, s, taus=taus)
            return t, s, on, peaks(t, Y, on, dur), Y
        else:
            R = run_hyst(t, s, tau_range=tau_range)
            return t, s, on, peaks_hyst(t, R, on, dur), R

    # --- H1: декремент
    t, s, on, P, _ = resp(20, 5.0)
    P = np.maximum(P, 1e-12)
    res["H1_ratio_last_first"] = P[-1] / P[0]
    # ступенчатость: доля падения, случившаяся на 1-м шаге
    drop_total = P[0] - P[-1]
    res["H1_step_fraction"] = (P[0] - P[1]) / drop_total if drop_total > 1e-12 else np.nan
    res["H1_profile"] = P

    # --- H2: спонтанное восстановление
    rec = {}
    for wait in [5.0, 20.0, 60.0, 200.0]:
        n = 20
        isi = 5.0
        T = 5.0 + n * isi + wait + 20.0
        t, s, on = pulse_train(T, dt, n, isi, dur, amp, base)
        # добавляем тест-импульс после паузы
        t_test = 5.0 + n * isi + wait
        s[(t >= t_test) & (t < t_test + dur)] = base + amp
        allon = np.append(on, t_test)
        if kind == "B0":
            Y, _ = run_B0(t, s, taus=taus)
            P2 = peaks(t, Y, allon, dur)
        else:
            R = run_hyst(t, s, tau_range=tau_range)
            P2 = peaks_hyst(t, R, allon, dur)
        rec[wait] = (P2[-1] + 1e-12) / (P2[0] + 1e-12)
    res["H2_recovery_vs_wait"] = rec

    # --- H3: потенцирование габитуации (4 серии с полным восстановлением)
    n, isi, gap = 20, 5.0, 600.0
    T = 5.0 + 4 * (n * isi + gap) + 20.0
    t = np.arange(0, T, dt)
    s = np.full_like(t, base)
    series_on = []
    cur = 5.0
    for _ in range(4):
        ons = cur + np.arange(n) * isi
        for o in ons:
            s[(t >= o) & (t < o + dur)] = base + amp
        series_on.append(ons)
        cur += n * isi + gap
    if kind == "B0":
        Y, _ = run_B0(t, s, taus=taus)
        f = lambda o: peaks(t, Y, o, dur)
    else:
        R = run_hyst(t, s, tau_range=tau_range)
        f = lambda o: peaks_hyst(t, R, o, dur)
    ratios = [float((f(o)[-1] + 1e-12) / (f(o)[0] + 1e-12)) for o in series_on]
    res["H3_series_ratios"] = ratios

    # --- H4: частотная чувствительность
    freq = {}
    for isi in [2.0, 5.0, 10.0, 20.0, 40.0]:
        _, _, _, P4, _ = resp(20, isi)
        freq[isi] = float((P4[-1] + 1e-12) / (P4[0] + 1e-12))
    res["H4_ratio_vs_isi"] = freq

    # --- H5: чувствительность к интенсивности
    inten = {}
    for a in [0.5, 1.0, 2.0, 4.0, 8.0, 16.0]:
        _, _, _, P5, _ = resp(20, 5.0, amp=a)
        inten[a] = float((P5[-1] + 1e-12) / (P5[0] + 1e-12))
    res["H5_ratio_vs_amp"] = inten

    # --- H6: below-zero (доп. стимуляция после плато -> дольше восстановление)
    bz = {}
    for n in [20, 60]:
        isi, wait = 5.0, 60.0
        T = 5.0 + n * isi + wait + 20.0
        t, s, on = pulse_train(T, dt, n, isi, dur, amp, base)
        t_test = 5.0 + n * isi + wait
        s[(t >= t_test) & (t < t_test + dur)] = base + amp
        allon = np.append(on, t_test)
        if kind == "B0":
            Y, _ = run_B0(t, s, taus=taus)
            P6 = peaks(t, Y, allon, dur)
        else:
            R = run_hyst(t, s, tau_range=tau_range)
            P6 = peaks_hyst(t, R, allon, dur)
        bz[n] = float((P6[-1] + 1e-12) / (P6[0] + 1e-12))
    res["H6_recovery_after_n"] = bz

    res["label"] = label
    return res


def verdicts(r):
    """Автоматические PASS/FAIL по фиксированным заранее критериям."""
    v = {}
    v["H1_decrement"] = "PASS" if r["H1_ratio_last_first"] < 0.7 else "FAIL"
    if not np.isnan(r["H1_step_fraction"]) and r["H1_step_fraction"] > 0.9:
        v["H1_decrement"] += "_step"
    rec = r["H2_recovery_vs_wait"]
    ks = sorted(rec)
    v["H2_recovery"] = "PASS" if rec[ks[-1]] > rec[ks[0]] + 0.05 else "FAIL"
    rr = r["H3_series_ratios"]
    v["H3_potentiat"] = "PASS" if rr[-1] < rr[0] - 0.05 else "FAIL"
    fr = r["H4_ratio_vs_isi"]
    ks = sorted(fr)
    v["H4_frequency"] = "PASS" if fr[ks[0]] < fr[ks[-1]] - 0.05 else "FAIL"
    it = r["H5_ratio_vs_amp"]
    ks = sorted(it)
    v["H5_intensity"] = "PASS" if it[ks[0]] < it[ks[-1]] - 0.05 else "FAIL"
    bz = r["H6_recovery_after_n"]
    v["H6_belowzero"] = "PASS" if bz[60] < bz[20] - 0.05 else "FAIL"
    return v


# ---------------------------------------------- model B1: расходуемый пул
def run_B1(t, s, K=1.0, theta=1.2, beta=4.0, tau_y=0.1,
           k=(3.0,), tau_r=(30.0,), deep=False, k_deep=0.15, tau_deep=1500.0):
    """
    Событийный примитив: активация тратит доступный ресурс.
      a  = sigma(beta*(E - theta))          мгновенная активация
      y  = a * r                            отклик (r = доступная доля)
      r' = -k*a*r + (1-r-d)/tau_r  [+ переток в глубокое состояние d]
      d' = k_deep*a*r - d/tau_deep          (только если deep=True)
    deep=True == применён оператор T (вторая, медленная шкала).
    """
    dt = t[1] - t[0]
    E = np.log1p(s / K)
    A = sigma(beta * (E - theta))
    r, d, y = 1.0, 0.0, 0.0
    Y = np.empty_like(t); R = np.empty_like(t); D = np.empty_like(t)
    kk, tr = k[0], tau_r[0]
    for i in range(len(t)):
        a = A[i]
        drr = -kk * a * r + (1.0 - r - d) / tr
        if deep:
            ddd = k_deep * a * r - d / tau_deep
            drr -= k_deep * a * r
        else:
            ddd = 0.0
        r = max(0.0, min(1.0, r + dt * drr))
        d = max(0.0, min(1.0, d + dt * ddd))
        y += dt / tau_y * (a * r - y)
        Y[i] = y; R[i] = r; D[i] = d
    return Y, R, D
