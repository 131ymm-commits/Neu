"""
BEHAV-020 / T2 — ВОЗВРАТ ИЗ ПУЛА (класс B, отзыв #26).

Гипотеза M1 «экспонента = закон агрегации коррекции» была похоронена по
наблюдаемой mu_c(N) при фиксированном горизонте. Диагноз BEHAV-017: та
наблюдаемая меряет функцию скорости флуктуационного ухода, а не агрегацию.
Гипотеза НЕ ТЕСТИРОВАЛАСЬ.

Правильная наблюдаемая найдена в BEHAV-019: СОДЕРЖАНИЕ, а не способность.
Меряем УСТОЙЧИВОСТЬ СОДЕРЖАНИЯ к поломке заданной глубины:
  C(slam) = P(вернулось исходное содержание | поломка длиной slam)
Определяем slam_50 = глубина поломки, при которой C падает до 75%
(на полпути от 100% к асимптотическим 50%).

ПРЕДРЕГИСТРАЦИЯ (до прогона):
  U1 slam_50 ~ N^b, и b РАЗЛИЧАЕТСЯ между механизмами (в отличие от
     mu_c, где ext/global/sample дали неразличимые 0.70-0.81)
  U2 ext: slam_50 не зависит от N (эталон помнит независимо от числа
     носителей)  =>  b ~ 0
  U3 global (большинство): b > 0 — больше носителей, больше инерции
     содержания
  U4 sample k=3: b между ними, но ближе к global
  U5 если U1 провалится и здесь — гипотеза M1 умирает окончательно
     (класс A), а не возвращается в пул
"""
import sys
import numpy as np


def phase(N, eps, mu, mech, steps, rng, s, k=3):
    for _ in range(steps):
        nz = rng.random(N) < eps
        if nz.any():
            s[nz] = rng.random(int(nz.sum())) < 0.5
        if mu > 0:
            fix = rng.random(N) < mu
            nf = int(fix.sum())
            if nf:
                if mech == "ext":
                    s[fix] = True
                elif mech == "global":
                    s[fix] = s.sum() * 2 > N
                elif mech == "sample":
                    src = s.copy()
                    s[fix] = src[rng.integers(0, N, (nf, k))].sum(1) * 2 > k
    return s


def content_back(N, mech, slam, eps=0.05, mu=0.25, T=1500, seeds=81):
    ok = 0
    for sd in range(seeds):
        rng = np.random.default_rng(sd)
        s = np.ones(N, bool)
        s = phase(N, eps, mu, mech, T, rng, s)          # держим
        s = phase(N, eps, 0.0, mech, slam, rng, s)      # ломаем
        s = phase(N, eps, mu, mech, T, rng, s)          # чиним
        ok += (s.sum() * 2 > N)
    return ok / seeds


def slam_50(N, mech, target=0.75):
    lo, hi = 1, 4096
    while lo < hi:
        mid = (lo + hi) // 2
        c = content_back(N, mech, mid)
        if c > target:
            lo = mid + 1
        else:
            hi = mid
    return lo


if __name__ == "__main__":
    mech = sys.argv[1]
    Ns = [21, 41, 81, 161, 321]
    out = []
    for N in Ns:
        v = slam_50(N, mech)
        out.append((N, v))
        print(f"  N={N:>4}  slam_50={v:>5}", flush=True)
    x = np.log([o[0] for o in out]); y = np.log([max(o[1], 1) for o in out])
    b = np.polyfit(x, y, 1)[0]
    print(f"{mech}: slam_50 ~ N^{b:+.2f}")
