"""
BEHAV-003 — связывание двух осей.

Вопрос: виден ли порог удержания В ПОВЕДЕНИИ, а не только в счётчике битов?

Конструкция: инвариант T2 (вторая временная шкала, отвечающая за H6)
не задан константой, а НЕСЁТСЯ слоем из N носителей. Носители портятся
со скоростью eps и чинятся со скоростью mu двумя разными способами:

  mode="repair"   независимая починка каждого испорченного
                  -> неподвижная точка phi* = mu/(mu+eps), БЕЗ порога, без N
                  -> это R2: удержание потоком

  mode="template" переписывание по большинству (шаблонное копирование)
                  -> порог по mu, обостряется с N
                  -> это R3: удержание копированием

ПРЕДРЕГИСТРАЦИЯ (до прогона):
  P1  repair:   phi_end ~= mu/(mu+eps), не зависит от N, поведение теряется ПЛАВНО
  P2  template: порог по mu, обостряется с N, поведение теряется РЕЗКО
  P3  потеря СЕЛЕКТИВНА: H6 исчезает, H1 выживает (базовый пул не задет)
  P4  спектральный ранг последовательности пиков падает 2 -> 1 на пороге
  P5  поведенческий порог >= битового (поведению нужна рабочая доля, не только
      большинство)
"""
import numpy as np

DT, BASE, DUR, AMP = 0.05, 1.0, 0.5, 4.0
sig = lambda x: 1.0 / (1.0 + np.exp(-x))
TH = (np.log1p(BASE) + np.log1p(BASE + AMP)) / 2


# ------------------------------------------------------------ слой носителей
def carriers(N, eps, mu, mode, steps, seed=0):
    """Возвращает долю целых носителей phi по окончании steps шагов."""
    rng = np.random.default_rng(seed)
    s = np.ones(N, bool)
    for _ in range(steps):
        s &= ~(rng.random(N) < eps)                       # порча
        if mu > 0:
            if mode == "repair":                          # независимая починка
                s |= (~s) & (rng.random(N) < mu)
            else:                                         # шаблонное копирование
                maj = s.sum() * 2 > N
                fix = rng.random(N) < mu
                s[fix] = maj
    return s.mean()


# ------------------------------------------------------------------- система
def pool(t, u, k=0.8, tau_r=40.0, beta=10.0, k_deep=0.05,
         tau_d=2000.0, tau_y=0.1):
    A = sig(beta * (np.log1p(u) - TH))
    r, d, y = 1.0, 0.0, 0.0
    Y = np.empty_like(t)
    for i in range(len(t)):
        a = A[i]
        dr = -k * a * r + (1 - r - d) / tau_r - k_deep * a * r
        dd = k_deep * a * r - d / tau_d
        r = min(1.0, max(0.0, r + DT * dr))
        d = min(1.0, max(0.0, d + DT * dd))
        y += DT / tau_y * (a * r - y)
        Y[i] = y
    return Y


def build(n, isi, wait=None):
    T = 5 + n * isi + (wait or 0) + 10
    t = np.arange(0, T, DT)
    u = np.full_like(t, BASE)
    on = 5 + np.arange(n) * isi
    for o in on:
        u[(t >= o) & (t < o + DUR)] = BASE + AMP
    tp = None
    if wait is not None:
        tp = 5 + n * isi + wait
        u[(t >= tp) & (t < tp + DUR)] = BASE + AMP
    return t, u, on, tp


peak = lambda t, y, o, w=DUR * 4: float(y[(t >= o) & (t < o + w)].max())


# ------------------------------------------------------------- считывания
def spectral_rank(p, tol=0.02):
    p = np.asarray(p, float) - np.asarray(p, float)[-3:].mean()
    n = len(p); L = n // 2
    H = np.array([[p[i + j] for j in range(L)] for i in range(n - L)])
    s = np.linalg.svd(H, compute_uv=False)
    if s[0] < 1e-12:
        return 0, []
    s = s / s[0]
    r = int((s > tol).sum())
    if r == 0:
        return 0, []
    A = np.array([p[i:i + r] for i in range(n - r)]); b = p[r:]
    c, *_ = np.linalg.lstsq(A, b, rcond=None)
    lam = np.roots(np.concatenate(([1.0], -c[::-1])))
    return r, sorted(np.abs(lam))[::-1]


def diagnose(kd):
    """H1, H6 и спектральный ранг при данном k_deep."""
    t, u, on, _ = build(20, 5.0)
    p = np.array([peak(t, u * 0 + pool(t, u, k_deep=kd), o) for o in on[:1]])
    y = pool(t, u, k_deep=kd)
    p = np.array([peak(t, y, o) for o in on])
    H1 = bool(p[0] > 1e-9 and np.all(np.diff(p) <= 1e-9) and p[-1] < 0.7 * p[0])
    r, lam = spectral_rank(p)

    def rec(n):
        t2, u2, on2, tp2 = build(n, 5.0, wait=100.0)
        y2 = pool(t2, u2, k_deep=kd)
        p2 = np.array([peak(t2, y2, o) for o in on2])
        return peak(t2, y2, tp2) / max(p2[0], 1e-12)
    r20, r120 = rec(20), rec(120)
    H6 = bool(r120 < r20 - 0.05)
    return H1, H6, r, lam, (r20 - r120)


if __name__ == "__main__":
    EPS, STEPS, KD0 = 0.02, 400, 0.05
    MUS = [0.0, 0.02, 0.04, 0.06, 0.08, 0.10, 0.15, 0.25, 0.50]

    print("=== контроль: k_deep задан вручную (без слоя носителей) ===")
    print(f"{'k_deep/k0':>10}{'H1':>5}{'H6':>5}{'ранг':>6}   |λ|")
    for frac in (1.0, 0.5, 0.25, 0.1, 0.05, 0.0):
        H1, H6, r, lam, gap = diagnose(KD0 * frac)
        print(f"{frac:>10.2f}{str(H1)[0]:>5}{str(H6)[0]:>5}{r:>6}   "
              f"{np.round(lam, 3) if len(lam) else '—'}   зазор H6={gap:+.3f}")

    for mode in ("repair", "template"):
        print(f"\n=== слой носителей: mode={mode}, eps={EPS}, {STEPS} шагов ===")
        print(f"{'mu':>6}" + "".join(f"{'N='+str(N):>22}" for N in (11, 41)))
        print(f"{'':>6}" + "".join(f"{'phi  H1 H6 ранг':>22}" for N in (11, 41)))
        for mu in MUS:
            cells = []
            for N in (11, 41):
                phi = float(np.median([carriers(N, EPS, mu, mode, STEPS, seed=s)
                                       for s in range(9)]))
                H1, H6, r, lam, gap = diagnose(KD0 * phi)
                cells.append(f"{phi:>6.3f} {str(H1)[0]:>3}{str(H6)[0]:>3}{r:>4}    ")
            print(f"{mu:>6.2f}" + "".join(f"{c:>22}" for c in cells))
