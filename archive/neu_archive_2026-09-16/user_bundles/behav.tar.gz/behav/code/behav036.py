"""BEHAV-036 / AP2 — переносится ли ПЕРСОНАЛИЗАЦИЯ удержания на другие проекты?"""
import numpy as np
import behav031 as B

BINS = [(0, 1, "<1д"), (1, 3, "1-3д"), (3, 10, "3-10д"), (10, 1e9, ">10д")]


def build(path):
    rows = []
    for l in open(path, encoding="utf-8", errors="replace"):
        p = l.rstrip("\n").split("|", 3)
        if len(p) == 4:
            rows.append((p[0], int(p[1]), p[2], p[3]))
    rows.sort(key=lambda r: r[1])
    ts = [r[1] for r in rows]; au = [r[2] for r in rows]; subj = [r[3] for r in rows]
    key = [B.norm(s) for s in subj]
    idx, last, rel = {}, {}, {}
    for i, k in enumerate(key):
        idx.setdefault(k, []).append(i)
    for i, a in enumerate(au):
        last[a] = i
    for i, s in enumerate(subj):
        m = B.RELAND.match(s.strip())
        if m and m.group(1):
            rel.setdefault(B.norm(m.group(1)), []).append(i)
    out = []
    for i, s in enumerate(subj):
        m = B.REV.match(s.strip())
        if not m:
            continue
        o = B.norm(m.group(1))
        pre = [j for j in idx.get(o, []) if j < i]
        if not pre:
            continue
        p0 = max(pre)
        post = [j for j in idx.get(o, []) if j > i] + \
               [j for j in rel.get(o, []) if j > i]
        out.append(dict(back=bool(post), life=(ts[i] - ts[p0]) / 86400.0,
                        alive=last[au[p0]] > i, self_rev=au[i] == au[p0],
                        back_self=bool(post) and au[min(post)] == au[p0]))
    return out


if __name__ == "__main__":
    print(f"{'проект':<10}{'откатов':>9}{'откат самим':>13}{'возврат самим':>15}"
          f"{'возвр|активен':>15}{'возвр|ушёл':>12}{'разрыв':>9}")
    for nm, p in (("pytorch", "/home/claude/pt_log2.txt"),
                  ("django", "/home/claude/django_log2.txt"),
                  ("node", "/home/claude/node_log2.txt")):
        o = build(p)
        if len(o) < 10:
            print(f"{nm:<10} мало данных ({len(o)})"); continue
        al = [x for x in o if x["alive"]]; go = [x for x in o if not x["alive"]]
        ra = np.mean([x["back"] for x in al]) if al else float("nan")
        rg = np.mean([x["back"] for x in go]) if go else float("nan")
        bs = [x["back_self"] for x in o if x["back"]]
        print(f"{nm:<10}{len(o):>9}{np.mean([x['self_rev'] for x in o]):>13.3f}"
              f"{(np.mean(bs) if bs else float('nan')):>15.3f}"
              f"{ra:>15.3f}{rg:>12.3f}{(ra/rg if rg > 0 else float('inf')):>9.1f}x",
              flush=True)
        print(f"{'':<10}  (n активных {len(al)}, ушедших {len(go)})")
