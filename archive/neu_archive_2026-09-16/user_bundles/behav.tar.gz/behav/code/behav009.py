"""
BEHAV-009 — полная матрица углов между ограничениями.

Две разные матрицы, отвечающие на разные вопросы:

  A) по ПРОСТРАНСТВУ ПАРАМЕТРОВ (одна богатая конфигурация, сетка параметров)
     -> структура компромиссов. cos<0 = фрустрация: резко одновременно нельзя.
     -> контексты = максимальные наборы попарно ортогональных ограничений,
        внутри которых логика обычная булева (заплатки Кохена-Спекера).

  B) по ПРОСТРАНСТВУ КОНФИГУРАЦИЙ (256 структур, параметры фиксированы)
     -> избыточность. cos~1 = считывания дублируют друг друга.
     -> эффективная размерность объясняет, почему сигнатур всего 55 из 256.

ПРЕДРЕГИСТРАЦИЯ:
  U1 найдутся почти коллинеарные пары (|cos|>0.9). Кандидаты: H2 и CD
     (оба из r400), H6 и CP (оба из длинного цуга), CS и CT (оба про
     пространство).
  U2 эффективная размерность 13 считываний окажется заметно ниже 13
     (ожидаю 5-7 по participation ratio).
  U3 в пространстве параметров найдётся хотя бы одна сильно фрустрированная
     пара (cos < -0.5).
  U4 контекстов (максимальных ортогональных клик) будет несколько, и они
     будут перекрываться — то есть глобального булева порядка нет.
"""
import itertools
import sys
import numpy as np
import behav005 as B

P = dict(K=0.8, TAU_R=40.0, KD=0.05, COUP=0.5, POG=0.35, TAU_Y=0.3)
INV = B.INV
NI = len(INV)
cfg_of = lambda m: {k: bool(m >> i & 1) for i, k in enumerate(INV)}


def simulate(cfg, prot):
    M = 8 if cfg["N"] else 1
    C = 2 if cfg["CH"] else 1
    n, isi = prot["n"], prot["isi"]
    T = 5 + n * isi + prot.get("wait", 0) + 10
    t = np.arange(0, T, B.DT); L = len(t)
    w = np.ones(M)
    if cfg["EX"] and M > 1:
        if prot.get("site") == "ant":
            w = np.exp(-np.arange(M) / 1.5)
        elif prot.get("site") == "post":
            w = np.exp(-(M - 1 - np.arange(M)) / 1.5)
    th = np.full(M, B.TH0)
    if cfg["PO"] and M > 1:
        th = B.TH0 + P["POG"] * (np.arange(M) / (M - 1) - 0.5)
    off = np.array([0.0, 0.45])[:C][prot.get("chan", 0) % C]
    on = 5 + np.arange(n) * isi
    tp = 5 + n * isi + prot["wait"] if prot.get("wait") else None
    pulse = np.zeros(L, bool)
    for o in on:
        pulse |= (t >= o) & (t < o + B.DUR)
    probe = (t >= tp) & (t < tp + B.DUR) if tp is not None else np.zeros(L, bool)
    coupled = cfg["GR"] and M > 1
    kd = P["KD"] if cfg["T2"] else 0.0
    r = np.ones(M); d = np.zeros(M); y = np.zeros(M); s = np.zeros(M)
    dth = np.zeros(M); Y = np.empty(L); YU = np.zeros((L, M))
    amp = prot.get("amp", B.AMP)
    for i in range(L):
        uu = B.BASE + (amp * w if (pulse[i] or probe[i]) else 0.0)
        E = np.log1p(uu)
        if coupled:
            nb = np.zeros(M); nb[1:] += y[:-1]; nb[:-1] += y[1:]
            E = E + P["COUP"] * nb
        eff = th + dth + off
        if cfg["NL"]:
            a = B.sig(10.0 * (E - eff))
            dr = -P["K"] * a * r + (1 - r - d) / P["TAU_R"] - kd * a * r
            d = np.clip(d + B.DT * (kd * a * r - d / 2000.0), 0, 1)
            r = np.clip(r + B.DT * dr, 0, 1)
            resp = a * r
        else:
            s += B.DT / 8.0 * (E - s); resp = E - s
            if cfg["T2"]:
                resp = resp * 0.6 + 0.4 * (E - s) * 0.5
        y = y + B.DT / P["TAU_Y"] * (resp - y)
        if cfg["PL"]:
            dth += B.DT * (0.02 * np.maximum(y, 0) - dth / 800.0)
        Y[i] = y.mean(); YU[i] = y
    return t, Y, on, tp, YU


def pk(cfg, **prot):
    t, Y, on, tp, YU = simulate(cfg, prot)
    w = B.DUR * 4
    p = np.array([float(Y[(t >= o) & (t < o + w)].max()) for o in on])
    pr = float(Y[(t >= tp) & (t < tp + w)].max()) if tp else None
    sl = (t >= on[0]) & (t < on[0] + w)
    return p, pr, YU[sl].max(axis=0), (t, YU, on)


NAMES = ["H1", "R2nd", "H2", "H4", "H5", "H6", "H7", "CS", "CG", "CV", "CT",
         "CD", "CP"]


def scores(cfg):
    """НЕПРЕРЫВНЫЕ величины под каждым ограничением. None -> 0."""
    z = dict.fromkeys(NAMES, 0.0)
    p, _, _, _ = pk(cfg, n=20, isi=5.0)
    if p[0] <= 1e-9:
        return z
    z["H1"] = float(1 - p[-1] / p[0])
    q = np.asarray(p) - np.asarray(p)[-3:].mean()
    if np.abs(q).max() > 1e-9:
        L = len(q) // 2
        H = np.array([[q[i + j] for j in range(L)] for i in range(len(q) - L)])
        sv = np.linalg.svd(H, compute_uv=False)
        z["R2nd"] = float(sv[1] / sv[0])
    a, ra, _, _ = pk(cfg, n=20, isi=5.0, wait=5.0)
    b, rb, _, _ = pk(cfg, n=20, isi=5.0, wait=400.0)
    r5, r400 = ra / max(a[0], 1e-12), rb / max(b[0], 1e-12)
    z["H2"] = float(r400 - r5); z["CD"] = float(1 - r400)
    f2, _, _, _ = pk(cfg, n=20, isi=2.0); f4, _, _, _ = pk(cfg, n=20, isi=40.0)
    z["H4"] = float(f4[-1] / max(f4[0], 1e-12) - f2[-1] / max(f2[0], 1e-12))
    lo, _, _, _ = pk(cfg, n=20, isi=5.0, amp=0.5)
    hi, _, _, _ = pk(cfg, n=20, isi=5.0, amp=16.0)
    z["H5"] = float(hi[-1] / max(hi[0], 1e-12) - lo[-1] / max(lo[0], 1e-12))
    s20, q20, _, _ = pk(cfg, n=20, isi=5.0, wait=100.0)
    s60, q60, _, _ = pk(cfg, n=60, isi=5.0, wait=100.0)
    z["H6"] = float(q20 / max(s20[0], 1e-12) - q60 / max(s60[0], 1e-12))
    hi0, _, _, _ = pk(cfg, n=1, isi=5.0, amp=16.0)
    _, qh, _, _ = pk(cfg, n=60, isi=5.0, wait=100.0, amp=16.0)
    z["CP"] = float(1 - (qh or 0) / max(hi0[0], 1e-12))
    if cfg["CH"]:
        p0, _, _, _ = pk(cfg, n=20, isi=5.0, chan=0)
        p1, _, _, _ = pk(cfg, n=20, isi=5.0, chan=1)
        z["H7"] = float(abs(p0[-1] / max(p0[0], 1e-12)
                            - p1[-1] / max(p1[0], 1e-12)))
    if cfg["N"]:
        _, _, u, _ = pk(cfg, n=20, isi=5.0)
        m = float(np.mean(np.abs(u)))
        z["CV"] = float(np.std(u) / m) if m > 1e-12 else 0.0
    if cfg["N"] and cfg["EX"]:
        pa, _, _, _ = pk(cfg, n=20, isi=5.0, site="ant")
        pp, _, _, _ = pk(cfg, n=20, isi=5.0, site="post")
        den = max(abs(pa[0]), abs(pp[0]), 1e-12)
        z["CS"] = float(abs(pa[0] - pp[0]) / den)
        _, _, u2, (t, YU, on) = pk(cfg, n=5, isi=5.0, site="ant")
        z["CG"] = float(abs(u2[-1]) / max(abs(u2[0]), 1e-12))
        w = (t >= on[0]) & (t < on[0] + B.DUR * 8)
        seg = YU[w]
        if seg.max() > 1e-12:
            z["CT"] = float(seg[:, -1].argmax() - seg[:, 0].argmax()) * B.DT
    return z


def gram(rows):
    X = np.array(rows, float)                     # (points, constraints)
    X = X - X.mean(axis=0, keepdims=True)
    nrm = np.linalg.norm(X, axis=0)
    live = nrm > 1e-9
    Xn = X[:, live] / nrm[live]
    return Xn.T @ Xn, live


def report(Cm, live, title):
    nm = [n for n, l in zip(NAMES, live) if l]
    k = len(nm)
    print(f"\n=== {title} ===")
    print("     " + "".join(f"{n[:4]:>6}" for n in nm))
    for i, n in enumerate(nm):
        print(f"{n:>4} " + "".join(f"{Cm[i,j]:>6.2f}" for j in range(k)))
    ev = np.linalg.eigvalsh(Cm)[::-1]
    pr = float(ev.sum() ** 2 / (ev ** 2).sum())
    print(f"  спектр Грама: {np.round(ev, 2)}")
    print(f"  эффективная размерность (participation ratio): {pr:.2f} из {k}")
    dup = [(nm[i], nm[j], Cm[i, j]) for i in range(k) for j in range(i + 1, k)
           if abs(Cm[i, j]) > 0.85]
    fr = [(nm[i], nm[j], Cm[i, j]) for i in range(k) for j in range(i + 1, k)
          if Cm[i, j] < -0.5]
    print(f"  почти коллинеарные (|cos|>0.85): "
          f"{[(a,b,round(c,2)) for a,b,c in dup] or '—'}")
    print(f"  фрустрированные (cos<-0.5): "
          f"{[(a,b,round(c,2)) for a,b,c in fr] or '—'}")
    # контексты: максимальные клики попарной ортогональности |cos|<0.3
    best = []
    for r in range(k, 1, -1):
        for comb in itertools.combinations(range(k), r):
            if all(abs(Cm[i, j]) < 0.3 for i, j in itertools.combinations(comb, 2)):
                best.append([nm[i] for i in comb])
        if best:
            break
    print(f"  контексты (макс. ортогональные клики, |cos|<0.3): "
          f"{len(best)} шт. размера {len(best[0]) if best else 0}")
    for c in best[:4]:
        print(f"     {c}")
    return pr


if __name__ == "__main__":
    ALLON = {k: True for k in INV}

    print("A) сетка параметров...", file=sys.stderr)
    rows = []
    grid = list(itertools.product([0.4, 1.2], [15.0, 60.0],
                                  [0.02, 0.10], [0.2, 0.8]))
    for i, (k_, tr, kd, cp) in enumerate(grid):
        P.update(K=k_, TAU_R=tr, KD=kd, COUP=cp)
        rows.append([scores(ALLON)[n] for n in NAMES])
        if i % 20 == 0:
            print(f"  {i}/{len(grid)}", file=sys.stderr)
    P.update(K=0.8, TAU_R=40.0, KD=0.05, COUP=0.5)
    CA, liveA = gram(rows)
    report(CA, liveA, "A: пространство параметров (81 точка, все инварианты on)")

    print("\nB) 256 конфигураций...", file=sys.stderr)
    rows2 = []
    for m in range(1 << NI):
        rows2.append([scores(cfg_of(m))[n] for n in NAMES])
        if m % 64 == 0:
            print(f"  {m}/256", file=sys.stderr)
    CB, liveB = gram(rows2)
    prB = report(CB, liveB, "B: пространство конфигураций (256 структур)")
    print(f"\n  сигнатур было 55 из 256; эффективная размерность считываний "
          f"{prB:.2f} -> примерно 2^{prB:.1f} ~ {2**prB:.0f} различимых классов")
