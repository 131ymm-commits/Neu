"""
BEHAV-006 — граф достижимости вместо линейных расширений.

BEHAV-005 показал: DAG предпосылок ЗАВИСИТ ОТ КОНТЕКСТА. Значит "число
линейных расширений одного DAG" — не определено. Правильный объект:

  состояние = подмножество присутствующих инвариантов (2^8 = 256 узлов)
  переход S -> S+{B} РАЗРЕШЁН только если B неинертен в контексте S,
          т.е. signature(S+{B}) != signature(S)

Инвариант, ничего не меняющий, не может быть отобран -> шаг невозможен.
Число возможных историй = число путей из пустого множества в полное.
"""
import itertools, math, sys
import behav005 as B

INV = B.INV
N = len(INV)


def cfg_of(mask):
    return {k: bool(mask >> i & 1) for i, k in enumerate(INV)}


print("считаю сигнатуры для всех 256 конфигураций...", file=sys.stderr)
SIG = {}
for m in range(1 << N):
    SIG[m] = B.signature(cfg_of(m))
    if m % 32 == 0:
        print(f"  {m}/256", file=sys.stderr)

# разрешённые переходы
adj = {m: [] for m in range(1 << N)}
allowed = 0
for m in range(1 << N):
    for i in range(N):
        if not (m >> i & 1):
            m2 = m | (1 << i)
            if SIG[m2] != SIG[m]:
                adj[m].append(m2); allowed += 1

FULL = (1 << N) - 1
# число путей 0 -> FULL по разрешённым рёбрам (динамика по popcount)
paths = {0: 1}
for m in sorted(range(1 << N), key=lambda x: bin(x).count("1")):
    if m not in paths:
        continue
    for m2 in adj[m]:
        paths[m2] = paths.get(m2, 0) + paths[m]

tot = math.factorial(N)
p = paths.get(FULL, 0)
print(f"\n=== граф достижимости ===")
print(f"  узлов {1<<N}, разрешённых рёбер {allowed} из {N*(1<<(N-1))}")
print(f"  путей из пустого в полное: {p} из {tot}  ({100*p/tot:.3f}%)")

# сколько различимых сигнатур вообще
u = len(set(SIG.values()))
print(f"  различимых сигнатур: {u} из 256 конфигураций")

# какие инварианты вообще хоть где-то неинертны
act = {k: 0 for k in INV}
for m in range(1 << N):
    for i, k in enumerate(INV):
        if not (m >> i & 1) and SIG[m | (1 << i)] != SIG[m]:
            act[k] += 1
print(f"\n  в скольких контекстах инвариант неинертен (из 128):")
for k in INV:
    print(f"    {k:<3} {act[k]:>4}")
