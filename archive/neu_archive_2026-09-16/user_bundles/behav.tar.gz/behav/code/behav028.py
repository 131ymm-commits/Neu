"""
BEHAV-028 / AG1 — правильная величина: ПЕРЕВОРОТЫ СОДЕРЖАНИЯ, а не поток событий.

BEHAV-027 склеил две вещи. Здесь разделяю на тех же данных LTEE.
HMM-разметка Good et al.: well_mixed_hmm_states = {A:0 (не появилась),
E:1 (вымерла), F:2 (зафиксирована), P:3 (полиморфна)}.

  ПОТОК СОБЫТИЙ   = число мутаций (то, что мерил BEHAV-027)
  ПЕРЕВОРОТ       = смена состояния мутации F->E или P->E (то, что
                    зафиксировалось, потом ушло) = утрата удерживаемого
                    содержания

ПРЕДРЕГИСТРАЦИЯ:
  AG1a доля переворотов на мутацию у мутаторов и немутаторов БЛИЗКА
       (в отличие от потока событий, различного в 20 раз)
  AG1b если близка — провал AF1b объяснён склейкой, окно уцелело
  AG1c если и по переворотам разница на порядок — объяснение неверно,
       и провал AF1b остаётся необъяснённым
"""
import sys
import numpy as np

MUT = ['m1', 'm2', 'm3', 'm4', 'p3', 'p6']
NON = ['m5', 'm6', 'p1', 'p2', 'p4', 'p5']
D = "/home/claude/ltee/data_files"
A_, E_, F_, P_ = 0, 1, 2, 3


def load_states(pop):
    fn = f"{D}/{pop}_well_mixed_state_timecourse.txt"
    rows = []
    with open(fn) as fh:
        fh.readline()          # времена
        fh.readline()          # число полиморфных
        for line in fh:
            v = line.rstrip("\n").rstrip(",").split(",")
            try:
                rows.append([int(float(x)) for x in v if x.strip() != ""])
            except ValueError:
                continue
    if not rows:
        return None
    L = min(len(r) for r in rows)
    return np.array([r[:L] for r in rows])


def stats(pop):
    S = load_states(pop)
    if S is None or S.shape[0] < 10:
        return None
    n, T = S.shape
    # переворот: мутация была F или P, стала E (содержание утрачено)
    prev, cur = S[:, :-1], S[:, 1:]
    lost = ((prev == F_) | (prev == P_)) & (cur == E_)
    fixed_ever = (S == F_).any(axis=1).sum()
    established = ((S == F_) | (S == P_)).any(axis=1).sum()
    return dict(n=n, T=T, lost=int(lost.sum()),
                established=int(established), fixed=int(fixed_ever),
                flip_per_est=lost.sum() / max(established, 1),
                flip_per_gen=lost.sum() / max(established, 1) / max(T - 1, 1))


if __name__ == "__main__":
    print(f"{'поп':>4}{'гр':>5}{'мутаций':>9}{'закрепл.':>10}{'утрачено':>10}"
          f"{'утрат/закрепл':>15}")
    out = {}
    for pop in sys.argv[1].split(","):
        r = stats(pop)
        if r is None:
            print(f"{pop:>4}  нет данных"); continue
        g = "МУТ" if pop in MUT else "нем"
        out[pop] = r["flip_per_est"]
        print(f"{pop:>4}{g:>5}{r['n']:>9}{r['established']:>10}"
              f"{r['lost']:>10}{r['flip_per_est']:>15.3f}", flush=True)
