"""
BEHAV-000 / Tier-0 — базовая модель поведения и операторы усложнения.
Один файл, только numpy. python behav000.py  -> таблица вердиктов.

ЛЕСТНИЦА:
  B0  время-интегратор  : tau_m*dm/dt = y-y0     (CheR/CheB, интегральная ОС)
  B1  событие-потребитель: r'=-k*a*r+(1-r-d)/tau_r (инактивация рецепторов)
  B1+T                  : + глубокое состояние d, tau_deep >> tau_r  [оператор T]
  HYS  гистероны        : Preisach-ансамбль, rate-independent
  HYS+rel               : + спонтанный сброс с tau  [конечная релаксация]

ПРЕДРЕГИСТРАЦИЯ (записана ДО прогона):
  B0 : H1 PASS, H2 PASS, H3 FAIL, H4 PASS, H5 ?, H6 FAIL
  HYS: H1 PASS(step), H2 FAIL, H3 FAIL, H4 FAIL, H5 PASS, H6 FAIL
  МОСТИК: спонтанное восстановление (H2) и частотная чувствительность (H4) —
          ровно те признаки, которые требуют конечного времени релаксации.
          Добавление релаксации гистеронам должно вернуть H2 и H4 и не тронуть
          остальные.
"""
import numpy as np

BASE, AMP, DUR, DT = 1.0, 4.0, 0.5, 0.01
EB, EP = np.log1p(BASE), np.log1p(BASE + AMP)
THETA, BETA = (EB + EP) / 2, 10.0

sigma = lambda x: 1.0 / (1.0 + np.exp(-x))


def pulse_train(T, n, isi, amp=AMP, dur=DUR, base=BASE, t0=5.0, dt=DT):
    t = np.arange(0, T, dt); s = np.full_like(t, base)
    on = t0 + np.arange(n) * isi
    for o in on:
        s[(t >= o) & (t < o + dur)] = base + amp
    return t, s, on


def peaks(t, Y, on, win=DUR * 4, sub=0.0):
    return np.array([Y[(t >= o) & (t < o + win)].max() - sub for o in on])


# ---------------------------------------------------------------- модели
def run_B0(t, s, tau_y=0.1, taus=(10.0,), y0=0.5):
    dt = t[1] - t[0]; E = np.log1p(s); m = np.zeros(len(taus)); y = y0
    Y = np.empty_like(t)
    for i in range(len(t)):
        y += dt / tau_y * (sigma(E[i] - m.sum()) - y)
        m += dt / np.asarray(taus) * (y - y0)
        Y[i] = y
    return Y


def run_B1(t, s, tau_y=0.1, k=0.8, tau_r=40.0, deep=False,
           k_deep=0.05, tau_deep=2000.0):
    dt = t[1] - t[0]
    A = sigma(BETA * (np.log1p(s) - THETA))
    r, d, y = 1.0, 0.0, 0.0; Y = np.empty_like(t)
    for i in range(len(t)):
        a = A[i]
        dr = -k * a * r + (1.0 - r - d) / tau_r
        dd = 0.0
        if deep:
            dd = k_deep * a * r - d / tau_deep
            dr -= k_deep * a * r
        r = min(1.0, max(0.0, r + dt * dr)); d = min(1.0, max(0.0, d + dt * dd))
        y += dt / tau_y * (a * r - y); Y[i] = y
    return Y


def run_HYS(t, s, tau_range=None, N=4000, seed=0):
    dt = t[1] - t[0]; rng = np.random.default_rng(seed)
    hup = rng.uniform(0.1, 2.5, N); hdn = hup - rng.uniform(0.3, 1.5, N)
    st = np.zeros(N, bool)
    tau = None if tau_range is None else np.exp(
        rng.uniform(*np.log(tau_range), N))
    g = np.random.default_rng(seed + 1); R = np.empty_like(t)
    for i in range(len(t)):
        b = st.copy()
        st |= (s[i] >= hup); st &= ~(s[i] <= hdn)
        if tau is not None:
            st &= ~(st & (g.random(N) < dt / tau))
        R[i] = (st & ~b).sum()
    return R


MODELS = {
    "B0 (время-интегратор)":   lambda t, s: run_B0(t, s) - 0.5,
    "B1 (событие-потребитель)": lambda t, s: run_B1(t, s),
    "B1+T (2 шкалы)":          lambda t, s: run_B1(t, s, deep=True),
    "HYS (без релаксации)":    lambda t, s: run_HYS(t, s),
    "HYS+релаксация":          lambda t, s: run_HYS(t, s, tau_range=(3.0, 300.0)),
}


# ---------------------------------------------------------------- батарея
def battery(f):
    def resp(n, isi, amp=AMP, wait=None):
        T = 5.0 + n * isi + (wait or 0) + 30.0
        t, s, on = pulse_train(T, n, isi, amp)
        if wait is not None:
            tt = 5.0 + n * isi + wait
            s[(t >= tt) & (t < tt + DUR)] = BASE + amp; on = np.append(on, tt)
        return peaks(t, f(t, s), on)

    o = {}
    P = resp(20, 5.0); o["H1"] = P[-1] / P[0]
    o["H1step"] = (P[0] - P[1]) / (P[0] - P[-1]); o["prof"] = np.round(P / P[0], 3)
    o["H2"] = {w: float(resp(20, 5.0, wait=w)[-1] / resp(20, 5.0, wait=w)[0])
               for w in (5, 20, 60, 200, 600)}
    n, isi, gap = 20, 5.0, 500.0
    T = 5.0 + 4 * (n * isi + gap) + 30.0
    t = np.arange(0, T, DT); s = np.full_like(t, BASE); ser = []; cur = 5.0
    for _ in range(4):
        ons = cur + np.arange(n) * isi
        for x in ons:
            s[(t >= x) & (t < x + DUR)] = BASE + AMP
        ser.append(ons); cur += n * isi + gap
    Y = f(t, s); ref = peaks(t, Y, ser[0])[0]
    o["H3"] = [round(float(peaks(t, Y, x)[-1] / ref), 4) for x in ser]
    o["H4"] = {i: float(resp(20, i)[-1] / resp(20, i)[0])
               for i in (2., 5., 10., 20., 40.)}
    o["H5"] = {a: float(resp(20, 5., amp=a)[-1] / resp(20, 5., amp=a)[0])
               for a in (0.5, 1., 2., 4., 8., 16.)}
    o["H6"] = {m: float(resp(m, 5., wait=100.)[-1] / resp(m, 5., wait=100.)[0])
               for m in (20, 60, 120)}
    return o


def verdict(o):
    e = 0.05
    return {
        "H1 декремент":   ("PASS" if o["H1"] < 0.7 else "FAIL")
                          + ("" if o["H1step"] < 0.6 else " (ступень)"),
        "H2 восстановл.": "PASS" if o["H2"][600] > o["H2"][5] + e else "FAIL",
        "H3 потенцир.":   "PASS" if o["H3"][-1] < o["H3"][0] - e else "FAIL",
        "H4 частота":     "PASS" if o["H4"][2.] < o["H4"][40.] - e else "FAIL",
        "H5 интенсивн.":  "PASS" if o["H5"][.5] < o["H5"][16.] - e else "FAIL",
        "H6 below-zero":  "PASS" if o["H6"][120] < o["H6"][20] - e else "FAIL",
    }


if __name__ == "__main__":
    keys = ["H1 декремент", "H2 восстановл.", "H3 потенцир.",
            "H4 частота", "H5 интенсивн.", "H6 below-zero"]
    rows = {}
    for name, f in MODELS.items():
        rows[name] = verdict(battery(f))
    w = max(map(len, MODELS)) + 1
    print(" " * w + "".join(f"{k:>16}" for k in keys))
    for name, v in rows.items():
        print(f"{name:<{w}}" + "".join(f"{v[k]:>16}" for k in keys))
