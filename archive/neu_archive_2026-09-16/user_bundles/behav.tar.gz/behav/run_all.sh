#!/usr/bin/env bash
# Полный прогон. Все результаты -> results/
set -e
cd "$(dirname "$0")/code"
mkdir -p ../results
for f in behav000 behav001 behav002 behav003 behav004; do
  echo "=== $f ==="
  python "$f.py" | tee "../results/$f.txt"
done
