#!/usr/bin/env python3
"""
gate.py — ворота как ВНЕШНИЙ ЭТАЛОН, а не как текст в контексте.

Запускать ПЕРЕД каждым экспериментом:   python gate.py BEHAV-030
Отказывает, если ворота не пройдены. Проверяет файлы, а не память.
"""
import os
import re
import sys

R = os.path.dirname(os.path.abspath(__file__))


def has(fn, pat):
    p = os.path.join(R, fn)
    return os.path.exists(p) and re.search(pat, open(p, encoding="utf-8").read())


def main(eid):
    checks = [
        ("2. ПРИОРИТЕТ", f"строка про {eid} или его тему в PRIORITY.md",
         has("PRIORITY.md", re.escape(eid)) or None),
        ("4. ПРЕДРЕГИСТРАЦИЯ", f"блок {eid} в PREREG.md",
         has("PREREG.md", re.escape(eid))),
        ("4б. УСЛОВИЕ СМЕРТИ", "в блоке есть исход, при котором гипотеза мертва",
         has("PREREG.md", r"(мертв|ПРОВАЛЕН если|опроверг|если.*—.*провал)")),
    ]
    print(f"\n=== ВОРОТА для {eid} ===")
    bad = 0
    for name, what, ok in checks:
        mark = "OK " if ok else ("?  " if ok is None else "СТОП")
        if ok is False:
            bad += 1
        print(f"  [{mark}] {name}: {what}")
    print("\n  Ворота 1 (гипотеза до поиска) и 3 (наблюдаемая + контроль)")
    print("  машина проверить не может — ответить письменно здесь:")
    print("    1) гипотеза одной фразой, сформулирована ДО поиска?")
    print("    2) что именно меряю и почему это ТА величина?")
    print("    3) какой контроль отличит артефакт от эффекта?")
    if bad:
        print(f"\n  ОТКАЗ: не пройдено {bad}. Заполнить файлы и повторить.")
        return 1
    print("\n  Проход. Ворота 5 (запись в тот же ход) — после прогона.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "BEHAV-XXX"))
