# EXP-WOL-001. Seed=42. Пререг: prereg_exp_wol_001.md
import json, zlib
import numpy as np
from scipy.stats import spearmanr
from scipy.linalg import null_space

rng = np.random.default_rng(42)
L, T, BURN = 200, 200, 100

def step(x, rule):
    idx = (np.roll(x, 1) << 2) | (x << 1) | np.roll(x, -1)
    return (rule >> idx) & 1

def evolve(rule, x0, T):
    x = x0.copy(); rows = []
    for t in range(T):
        rows.append(x); x = step(x, rule)
    return np.array(rows, dtype=np.uint8)

def blocks(x, k):
    idx = np.zeros(len(x), dtype=np.int64)
    for j in range(k):
        idx = (idx << 1) | np.roll(x, -j)
    return np.bincount(idx, minlength=2**k).astype(float)

def n_charges(rule, k, M=60):
    rows = []
    for _ in range(M):
        x = rng.integers(0, 2, L).astype(np.uint8)
        for _ in range(5): x = step(x, rule)
        rows.append(blocks(step(x, rule), k) - blocks(x, k))
    D = np.array(rows)
    ns = null_space(D, rcond=1e-9)
    return max(0, ns.shape[1] - 1)   # минус тривиальный (сумма блоков = L)

def density_autonomy(rule, M=400, nb=20):
    pairs = []
    for _ in range(M):
        x = rng.integers(0, 2, L).astype(np.uint8)
        for _ in range(10): x = step(x, rule)
        for _ in range(6):
            y = step(x, rule)
            pairs.append((x.mean(), y.mean())); x = y
    a = np.array(pairs)
    bi = np.clip((a[:, 0]*nb).astype(int), 0, nb-1)
    bo = np.clip((a[:, 1]*nb).astype(int), 0, nb-1)
    def H(v):
        p = np.bincount(v, minlength=nb)/len(v); p = p[p > 0]
        return -(p*np.log(p)).sum()
    Ho = H(bo)
    if Ho < 1e-9: return 1.0
    Hc = 0.0
    for b in range(nb):
        m = bi == b
        if m.sum() == 0: continue
        Hc += (m.sum()/len(bi))*H(bo[m])
    return float(1 - Hc/Ho)

def compressibility(rule):
    x0 = rng.integers(0, 2, L).astype(np.uint8)
    P = evolve(rule, x0, T + BURN)[BURN:]
    raw = np.packbits(P).tobytes()
    return 1 - len(zlib.compress(raw, 9))/len(raw)

RES = {}
for rule in range(256):
    RES[rule] = dict(c1=n_charges(rule, 1), c2=n_charges(rule, 2),
                     aut=density_autonomy(rule), comp=compressibility(rule))
    if rule % 64 == 0: print('  ...правило %d' % rule)

with_c1 = sorted([r for r in RES if RES[r]['c1'] > 0])
need = {184, 170, 240, 204}
PW1 = need.issubset(set(with_c1)) and abs(len(with_c1) - 8) <= 6
print('\nP-W1: правила с сохранением плотности (%d штук): %s' % (len(with_c1), with_c1))
print('      обязательные {184,170,240,204} внутри: %s | размер 8 ± 6 -> %s'
      % (need.issubset(set(with_c1)), 'PASS' if PW1 else 'FAIL'))

aut = np.array([RES[r]['aut'] for r in range(256)])
comp = np.array([RES[r]['comp'] for r in range(256)])
rho, p = spearmanr(aut, comp)
PW2 = rho >= 0.5
print('\nP-W2: Спирмен(автономность плотности, сжимаемость) = %+.3f (p=%.1e) -> %s'
      % (rho, p, 'PASS' if PW2 else 'FAIL'))

hasc = np.array([1 if (RES[r]['c1'] + RES[r]['c2']) > 0 else 0 for r in range(256)])
m1, m0 = float(np.median(comp[hasc == 1])), float(np.median(comp[hasc == 0]))
PW3 = (m1/m0) >= 1.2 if m0 > 0 else True
print('P-W3: медиана сжимаемости — с зарядами %.3f (n=%d), без %.3f (n=%d), отношение %.2f -> %s'
      % (m1, int(hasc.sum()), m0, int((1-hasc).sum()), m1/m0, 'PASS' if PW3 else 'FAIL'))

hi = np.percentile(comp, 75)
blind = [r for r in range(256) if comp[r] >= hi and hasc[r] == 0 and aut[r] < np.median(aut)]
PW4 = len(blind) >= 5
print('\nP-W4: сжимаемых, но невидимых нашим мерам правил: %d %s -> %s'
      % (len(blind), blind[:12], 'PASS' if PW4 else 'FAIL'))
print('      (правило 110 — сжимаемость %.3f, заряды %d, автономность %.3f)'
      % (comp[110], hasc[110], aut[110]))
print('      (правило 30  — сжимаемость %.3f, заряды %d, автономность %.3f)'
      % (comp[30], hasc[30], aut[30]))
json.dump(dict(with_c1=with_c1, PW1=bool(PW1), rho=float(rho), PW2=bool(PW2),
               med_with=m1, med_without=m0, PW3=bool(PW3),
               blind=blind, PW4=bool(PW4),
               res={str(r): RES[r] for r in RES}),
          open('results_wol_001.json','w'), indent=1, default=float)
