# EXP-LEV-004: Indian Railways (datameet). Seed=42. Пререг: prereg_exp_lev_003_004.md
import json
import numpy as np, networkx as nx
from scipy import sparse
from scipy.sparse.linalg import eigs
from collections import defaultdict

rng = np.random.default_rng(42)

st = json.load(open('stations.json'))['features']
state, zone = {}, {}
for f in st:
    p = f['properties']
    c = p.get('code')
    if not c: continue
    state[c] = p.get('state') or 'NA'
    zone[c] = p.get('zone') or 'NA'

sc = json.load(open('schedules.json'))
bytrain = defaultdict(list)
def tkey(r):
    t = r.get('departure')
    if not t or t == 'None': t = r.get('arrival')
    if not t or t == 'None': t = '00:00:00'
    h, m, s = (list(map(int, t.split(':'))) + [0, 0])[:3]
    return (r.get('day') or 1, h * 3600 + m * 60 + s)
for r in sc:
    stc = r.get('station_code')
    if stc in state:
        bytrain[r['train_number']].append((tkey(r), stc))
G = nx.Graph()
for tr, stops in bytrain.items():
    stops.sort()
    seq = [s for _, s in stops]
    for a, b in zip(seq, seq[1:]):
        if a != b: G.add_edge(a, b)
G = G.subgraph(max(nx.connected_components(G), key=len)).copy()
nodes = sorted(G.nodes()); idx = {v: i for i, v in enumerate(nodes)}; n = len(nodes)
lab_state = np.array([state[v] for v in nodes])
lab_zone = np.array([zone[v] for v in nodes])
na_s = (lab_state == 'NA').mean(); na_z = (lab_zone == 'NA').mean()
print('LCC: %d станций, %d рёбер | поездов: %d | штатов: %d (NA %.1f%%) | зон: %d (NA %.1f%%)'
      % (n, G.number_of_edges(), len(bytrain), len(set(lab_state)), 100 * na_s,
         len(set(lab_zone)), 100 * na_z))

A = sparse.lil_matrix((n, n))
for u, v in G.edges():
    A[idx[u], idx[v]] = 1.0; A[idx[v], idx[u]] = 1.0
A = A.tocsr()
deg = np.asarray(A.sum(axis=1)).ravel()
P = sparse.diags(1.0 / deg) @ A
PL = 0.5 * (sparse.identity(n) + P)

def eps_mean(labels):
    classes = sorted(set(labels)); ci = {c: j for j, c in enumerate(classes)}
    M = sparse.lil_matrix((n, len(classes)))
    for i, l in enumerate(labels): M[i, ci[l]] = 1.0
    Agg = np.asarray((P @ M.tocsr()).todense())
    tw, tot = 0.0, 0.0
    for c in classes:
        ids_ = np.where(labels == c)[0]
        if len(ids_) < 2: continue
        npairs = min(2000, len(ids_) * (len(ids_) - 1) // 2)
        a = rng.choice(ids_, npairs); b = rng.choice(ids_, npairs); ok = a != b
        if not ok.any(): continue
        d = 0.5 * np.abs(Agg[a[ok]] - Agg[b[ok]]).sum(axis=1).mean()
        tot += d * len(ids_); tw += len(ids_)
    return tot / tw

def check(labels, reps=50):
    e = eps_mean(labels)
    nulls = np.array([eps_mean(rng.permutation(labels)) for _ in range(reps)])
    return e, nulls, (e - nulls.mean()) / nulls.std()

es, ns_, Ds = check(lab_state)
ez, nz_, Dz = check(lab_zone)
P_T1 = es < ns_.min() and ez < nz_.min()
print('eps(штаты)=%.4f min(null)=%.4f D=%.1f | eps(зоны)=%.4f min(null)=%.4f D=%.1f | P-T1 %s'
      % (es, ns_.min(), Ds, ez, nz_.min(), Dz, 'PASS' if P_T1 else 'FAIL'))

pi = np.ones(n) / n
for _ in range(4000):
    pi = np.asarray(pi @ PL).ravel(); pi /= pi.sum()

def tau_of(f, tmax=300):
    f = f - (pi * f).sum(); c0 = (pi * f * f).sum()
    if c0 <= 0: return 0.0
    g = f.copy()
    for t in range(1, tmax + 1):
        g = np.asarray(PL @ g).ravel()
        if (pi * f * g).sum() / c0 < np.exp(-1): return float(t)
    return float(tmax)

tzo = [tau_of((lab_zone == c).astype(float)) for c in set(lab_zone) if c != 'NA' and (lab_zone == c).sum() >= 5]
tst = [tau_of((lab_state == c).astype(float)) for c in set(lab_state) if c != 'NA' and (lab_state == c).sum() >= 10]
trd = [tau_of(rng.standard_normal(n)) for _ in range(100)]
mz, ms, mr = np.median(tzo), np.median(tst), np.median(trd)
P_T2 = mz > ms > mr
print('tau медианы: зоны=%.1f (n=%d) штаты=%.1f (n=%d) случайные=%.1f | P-T2 %s'
      % (mz, len(tzo), ms, len(tst), mr, 'PASS' if P_T2 else 'FAIL'))

vals, vecs = eigs(PL.T.tocsc(), k=8, which='LM', maxiter=8000, tol=1e-8)
order = np.argsort(-np.abs(vals)); vals, vecs = vals[order], vecs[:, order]
def r2(v, labels):
    mu = v.mean(); sst = ((v - mu) ** 2).sum()
    ssw = sum(((v[labels == c] - v[labels == c].mean()) ** 2).sum() for c in set(labels))
    return 1 - ssw / sst
hits, r2s = 0, []
for j in range(1, 6):
    v = np.real(vecs[:, j]); r = r2(v, lab_zone)
    nulls = [r2(v, rng.permutation(lab_zone)) for _ in range(200)]
    ok = r > np.percentile(nulls, 95); hits += ok; r2s.append((round(float(r), 3), bool(ok)))
P_T3 = hits >= 3
print('|lambda| top-8:', np.round(np.abs(vals), 4))
print('R2 мод 2-6 по зонам:', r2s, '| P-T3', 'PASS' if P_T3 else 'FAIL')
print('tau зон:', sorted(np.round(tzo, 1), reverse=True))
print('tau штатов top-8:', sorted(np.round(tst, 1), reverse=True)[:8])

json.dump(dict(n=n, m=G.number_of_edges(), trains=len(bytrain),
               na_state=float(na_s), na_zone=float(na_z),
               eps=dict(state=float(es), state_null_min=float(ns_.min()), Ds=float(Ds),
                        zone=float(ez), zone_null_min=float(nz_.min()), Dz=float(Dz), P_T1=bool(P_T1)),
               tau=dict(zone=float(mz), state=float(ms), rand=float(mr), P_T2=bool(P_T2)),
               spec=dict(lams=[float(x) for x in np.abs(vals)], r2=r2s, P_T3=bool(P_T3))),
          open('results_lev_004.json', 'w'), indent=1)
