# EXP-LLM-002. Seed=42. Пререг: prereg_exp_llm_002.md
import json
import numpy as np, torch, torch.nn as nn
rng = np.random.default_rng(42); torch.manual_seed(42)
V, CTX, D, NL, BETA = 64, 24, 48, 2, 2.0

def blk(size):
    P = np.zeros((V, V))
    for s in range(0, V, size): P[s:s+size, s:s+size] = 1.0/size
    return P
R = rng.dirichlet(np.ones(V), size=V)
T = 0.95*(0.60*blk(2) + 0.30*blk(4) + 0.10*blk(64)) + 0.05*R
def sample(P, n, L):
    pi = np.ones(V)/V
    for _ in range(3000): pi = pi @ P; pi /= pi.sum()
    cs = P.cumsum(1); x = np.zeros((n, L), int); x[:, 0] = rng.choice(V, n, p=pi)
    for t in range(1, L):
        u = rng.random(n); x[:, t] = (cs[x[:, t-1]] < u[:, None]).sum(1)
    return x
tr, te = sample(T, 2000, CTX+1), sample(T, 300, CTX+1)

class Tiny(nn.Module):
    def __init__(s):
        super().__init__()
        s.te = nn.Embedding(V, D); s.pe = nn.Embedding(CTX, D)
        s.at = nn.ModuleList([nn.MultiheadAttention(D, 2, batch_first=True) for _ in range(NL)])
        s.ff = nn.ModuleList([nn.Sequential(nn.Linear(D, 2*D), nn.GELU(), nn.Linear(2*D, D)) for _ in range(NL)])
        s.l1 = nn.ModuleList([nn.LayerNorm(D) for _ in range(NL)])
        s.l2 = nn.ModuleList([nn.LayerNorm(D) for _ in range(NL)])
        s.out = nn.Linear(D, V)
    def forward(s, x):
        L = x.shape[1]
        h = s.te(x) + s.pe(torch.arange(L))[None]
        m = torch.triu(torch.ones(L, L, dtype=torch.bool), 1)
        for i in range(NL):
            hn = s.l1[i](h); a, _ = s.at[i](hn, hn, hn, attn_mask=m, need_weights=False)
            h = h + a; h = h + s.ff[i](s.l2[i](h))
        return s.out(h)

mdl = Tiny(); opt = torch.optim.AdamW(mdl.parameters(), lr=2e-3); lf = nn.CrossEntropyLoss()
for st in range(900):
    idx = rng.integers(0, len(tr), 48); xb = torch.tensor(tr[idx])
    loss = lf(mdl(xb[:, :-1]).reshape(-1, V), xb[:, 1:].reshape(-1))
    opt.zero_grad(); loss.backward(); opt.step()
print('обучение закончено, CE = %.3f' % loss.item())

# добавляемые ярусы: блоки размера 8, 16, 32, 64 (сверх настоящих 2 и 4)
LEVELS = [8, 16, 32, 64]
def bias(k):
    M = np.zeros((V, V))
    for i in range(k):
        M += BETA*blk(LEVELS[i])*LEVELS[i]      # индикатор «тот же блок»
    return torch.tensor(M, dtype=torch.float32)

@torch.no_grad()
def analyse(k):
    B = bias(k)
    def logits(x):
        lg = mdl(x)
        return lg + B[x]                       # добавка зависит от текущего токена
    # 1) ядро и щели
    x = torch.tensor(te)
    pr = torch.softmax(logits(x[:, :-1]), -1).numpy()
    cur = te[:, :-1]; P = np.zeros((V, V)); c = np.zeros(V)
    for s in range(V):
        m = cur == s
        if m.sum(): P[s] = pr[m].sum(0); c[s] = m.sum()
    P = P/np.maximum(c[:, None], 1)
    lam = np.sort(np.abs(np.linalg.eigvals(P)))[::-1]
    ratios = lam[:-1]/np.maximum(lam[1:], 1e-12)
    ngaps = int((ratios[:20] >= 1.3).sum())
    # 2) CE на настоящих данных
    ce = float(nn.CrossEntropyLoss()(logits(x[:, :-1]).reshape(-1, V), x[:, 1:].reshape(-1)))
    # 3) генерация
    g = torch.zeros(200, CTX, dtype=torch.long)
    g[:, 0] = torch.randint(0, V, (200,))
    for t in range(1, CTX):
        p = torch.softmax(logits(g[:, :t])[:, -1], -1)
        g[:, t] = torch.multinomial(p, 1).squeeze(1)
    G = g.numpy()
    cnt = np.zeros((V, V))
    for r in G:
        for a, b in zip(r[:-1], r[1:]): cnt[a, b] += 1
    row = cnt.sum(1, keepdims=True); Pg = cnt/np.maximum(row, 1)
    pv = np.bincount(G.ravel(), minlength=V)/G.size
    Hgen = float(-(pv[pv > 0]*np.log(pv[pv > 0])).sum())
    lg = np.sort(np.abs(np.linalg.eigvals(Pg)))[::-1]
    tau = float(-1/np.log(min(max(lg[1], 1e-9), 0.999999)))
    rep = float(np.mean(G[:, 1:] == G[:, :-1]))
    return dict(ngaps=ngaps, ce=ce, H=Hgen, tau=tau, rep=rep)

print('\nk   щелей  CE(реальные данные)  энтропия генерации  τ когерентности  доля повторов')
res = {}
for k in range(0, 5):
    r = analyse(k); res[k] = r
    print('%-3d %-6d %-20.3f %-19.3f %-16.2f %.3f'
          % (k, r['ngaps'], r['ce'], r['H'], r['tau'], r['rep']))
PM1 = res[4]['ngaps'] > res[0]['ngaps']
PM2 = res[4]['tau'] >= 3*res[0]['tau']
PM3 = (res[4]['ce'] - res[0]['ce']) >= 0.3 and all(res[i+1]['ce'] >= res[i]['ce'] for i in range(4))
PM4 = res[4]['H'] <= 0.5*res[0]['H'] and res[4]['rep'] > res[0]['rep']
print('\nP-M1 (щели растут): %s | P-M2 (τ втрое): %s (%.2f → %.2f)'
      % ('PASS' if PM1 else 'FAIL', 'PASS' if PM2 else 'FAIL', res[0]['tau'], res[4]['tau']))
print('P-M3 (CE растёт ≥0.3): %s (%.3f → %.3f)' % ('PASS' if PM3 else 'FAIL', res[0]['ce'], res[4]['ce']))
print('P-M4 (энтропия ≤50%%, повторы растут): %s (H %.3f → %.3f, повторы %.3f → %.3f)'
      % ('PASS' if PM4 else 'FAIL', res[0]['H'], res[4]['H'], res[0]['rep'], res[4]['rep']))
print('P-M5: при V = %d ярусов не может быть больше log₂V = %d — «добавить десять» невозможно' % (V, int(np.log2(V))))
json.dump(dict(res={str(k): res[k] for k in res}, PM1=bool(PM1), PM2=bool(PM2),
               PM3=bool(PM3), PM4=bool(PM4), maxlevels=int(np.log2(V))),
          open('results_llm_002.json','w'), indent=1, default=float)
