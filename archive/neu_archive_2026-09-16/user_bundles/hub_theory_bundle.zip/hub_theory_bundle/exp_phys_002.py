# EXP-PHYS-002: кварковый сектор ядра. Seed=42. Пререг: prereg_exp_phys_002.md
import json
import numpy as np
exec(open('exp_phys_001.py').read().split('# калибровка')[0])  # dfp, mothers, part, charges, PID, HBAR

def is_quark(pid): return abs(pid) <= 8
def is_diq(pid): return PID.is_diquark(pid)
def is_parton(p):
    a = int(p.pdgid)
    return is_quark(a) or abs(a) == 21 or is_diq(a)

channels = []
for m in mothers:
    pm = part(m)
    for mode in dfp.list_decay_modes(m):
        ds = [part(d) for d in mode]
        if pm is None or any(d is None for d in ds) or not ds: continue
        if m == 'chi_c0' and sorted(mode) == sorted(['K-', 'p+', 'Lambda0']):
            continue  # эрратум строки 8469
        channels.append((pm, ds))
print('каналов (партоны включены, опечатка исключена):', len(channels))

def Bstar(p):
    pid = int(p.pdgid)
    if PID.is_baryon(pid): return 1.0 if pid > 0 else -1.0
    if is_quark(pid): return (1.0 if pid > 0 else -1.0) / 3
    if is_diq(pid): return (2.0 if pid > 0 else -2.0) / 3
    return 0.0

def Fcolor(p):
    pid = int(p.pdgid)
    if is_quark(pid): return -1.0 if pid > 0 else 1.0
    if is_diq(pid): return 1.0 if pid > 0 else -1.0
    return 0.0

species = sorted({int(p.pdgid) for pm, ds in channels for p in [pm] + ds})
sidx = {s: i for i, s in enumerate(species)}
M = np.zeros((len(species), len(channels)))
for j, (pm, ds) in enumerate(channels):
    M[sidx[int(pm.pdgid)], j] -= 1
    for d in ds:
        M[sidx[int(d.pdgid)], j] += 1
U, S, Vt = np.linalg.svd(M)
k = int((S < 1e-8 * S[0]).sum()) + max(0, len(species) - len(S))
N = U[:, U.shape[1] - k:]
print('видов: %d | dim ядра: %d' % (len(species), k))

def vec(fn):
    return np.array([fn(Particle.from_pdgid(s)) for s in species], float)

def chan_res(fn):
    r = 0.0
    for pm, ds in channels:
        r = max(r, abs(sum(fn(x) for x in ds) - fn(pm)))
    return r

def proj_res(v):
    n = np.linalg.norm(v)
    if n == 0: return 0.0
    v = v / n
    return float(np.linalg.norm(v - N @ (N.T @ v)))

vQ = vec(lambda p: p.charge or 0.0)
vB = vec(Bstar)
vF = vec(Fcolor)
vL = {key: vec(lambda p, kk=key: charges(p)[kk]) for key in ['Le', 'Lm', 'Lt']}
print('невязки по каналам: B*=%.2e F=%.2e' % (chan_res(Bstar), chan_res(Fcolor)))
print('проекционные невязки в ядре: Q=%.1e B*=%.1e Le=%.1e Lm=%.1e Lt=%.1e F=%.1e'
      % (proj_res(vQ), proj_res(vB), proj_res(vL['Le']), proj_res(vL['Lm']),
         proj_res(vL['Lt']), proj_res(vF)))
PQ1 = (k == 6) and chan_res(Bstar) < 1e-8 and proj_res(vB) < 1e-8
# перекрытие остатка ядра с F
K5 = np.stack([v / np.linalg.norm(v) for v in [vQ, vB, vL['Le'], vL['Lm'], vL['Lt']]], 1)
Qk, _ = np.linalg.qr(K5)
Nres = N - Qk @ (Qk.T @ N)
u2, s2, _ = np.linalg.svd(Nres, full_matrices=False)
fifth = u2[:, 0]
ov = abs(float(fifth @ (vF / np.linalg.norm(vF))))
PQ2 = chan_res(Fcolor) < 1e-8 and proj_res(vF) < 1e-8 and ov > 0.99
print('перекрытие шестого направления с F(цвет): %.4f | P-Q1 %s | P-Q2 %s'
      % (ov, 'PASS' if PQ1 else 'FAIL', 'PASS' if PQ2 else 'FAIL'))

# P-Q3: фит по неспартонным видам, чтение партонных компонент
nonp = np.array([not is_parton(Particle.from_pdgid(s)) for s in species])
def fit_read(v_target, name):
    A = N[nonp]; b = v_target[nonp]
    alpha, *_ = np.linalg.lstsq(A, b, rcond=None)
    v = N @ alpha
    fit_err = float(np.max(np.abs(v[nonp] - b)))
    rows = []
    for s in species:
        p = Particle.from_pdgid(s)
        if is_parton(p) and abs(int(p.pdgid)) != 21:
            rows.append((p.name, round(float(v[sidx[s]]), 6)))
    print('фит %s: ошибка на адронах/лептонах = %.1e' % (name, fit_err))
    for nm, val in rows: print('   %-10s -> %+.6f' % (nm, val))
    return dict(rows), fit_err

qfit, qerr = fit_read(vQ, 'Q')
bfit, berr = fit_read(vB, 'B*')
PDGQ = {'u': 2/3, 'd': -1/3, 's': -1/3, 'c': 2/3, 'b': -1/3,
        'u~': -2/3, 'd~': 1/3, 's~': 1/3, 'c~': -2/3, 'b~': 1/3}
ok = bad = 0
for nm, val in qfit.items():
    base = nm.replace('(', '').split(')')[0] if '(' in nm else nm
    if nm in PDGQ:
        if abs(val - PDGQ[nm]) < 1e-6: ok += 1
        else: bad += 1; print('   РАСХОЖДЕНИЕ:', nm, val, 'ожидалось', PDGQ[nm])
print('свободные кварки: совпало с PDG %d, разошлось %d' % (ok, bad))
PQ3 = bad == 0 and ok >= 4 and qerr < 1e-6 and berr < 1e-6
print('P-Q3:', 'PASS' if PQ3 else 'FAIL')
json.dump(dict(dim=k, res=dict(B=chan_res(Bstar), F=chan_res(Fcolor),
               projF=proj_res(vF), overlap=ov),
               PQ1=bool(PQ1), PQ2=bool(PQ2), PQ3=bool(PQ3),
               qfit=qfit, bfit=bfit),
          open('results_phys_002.json', 'w'), indent=1, ensure_ascii=False)
