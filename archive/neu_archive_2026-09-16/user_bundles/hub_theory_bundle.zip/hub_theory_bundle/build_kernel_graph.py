# EXP-LEV-005 build: резолюция include-рёбер. Seed не нужен (детерминизм).
import os, re, json
import numpy as np

EXCL = ('Documentation/', 'scripts/', 'samples/', 'tools/', 'usr/', 'LICENSES/')
root = 'kernel/linux-master'
files = []
for dp, dn, fn in os.walk(root):
    for f in fn:
        if f.endswith(('.c', '.h')):
            rel = os.path.relpath(os.path.join(dp, f), root).replace('\\', '/')
            if not rel.startswith(EXCL):
                files.append(rel)
fileset = set(files)
print('файлов после исключений:', len(files))

# индекс для <X>: хвосты после 'include/' и 'include/uapi/'
tailmap = {}
for f in files:
    if f.startswith('include/') or '/include/' in f:
        tail = f.split('include/')[-1]
        tailmap.setdefault(tail, []).append(f)
        if tail.startswith('uapi/'):
            tailmap.setdefault(tail[5:], []).append(f)
# глобальный суффиксный индекс по basename для "X" без совпадений
base_map = {}
for f in files:
    base_map.setdefault(f.rsplit('/', 1)[-1], []).append(f)

def pick(cands):
    inc = [c for c in cands if c.startswith('include/') and '/uapi/' not in c]
    if inc: return min(inc, key=len)
    uap = [c for c in cands if c.startswith('include/uapi/')]
    if uap: return min(uap, key=len)
    return min(cands, key=len)

edges = set()
n_amb = n_unres = n_tot = 0
pat = re.compile(r'#\s*include\s*([<"])([^">]+)[">]')
for line in open('includes_raw.txt', encoding='utf-8', errors='replace'):
    try:
        path, rest = line.split(':', 1)
    except ValueError:
        continue
    src = path[2:] if path.startswith('./') else path
    if src.startswith(EXCL) or src not in fileset:
        continue
    m = pat.search(rest)
    if not m: continue
    kind, inc = m.group(1), m.group(2).strip()
    n_tot += 1
    dst = None
    if kind == '<':
        c = tailmap.get(inc)
        if c:
            dst = pick(c)
            if len(set(c)) > 1: n_amb += 1
    else:
        cand = os.path.normpath(os.path.join(os.path.dirname(src), inc)).replace('\\', '/')
        if cand in fileset:
            dst = cand
        else:
            c = tailmap.get(inc)
            if c:
                dst = pick(c); n_amb += (len(set(c)) > 1)
            elif '/' not in inc:
                b = base_map.get(inc)
                if b and len(b) == 1:
                    dst = b[0]
    if dst is None:
        n_unres += 1
    elif dst != src:
        edges.add((src, dst))
print('директив: %d | рёбер (уник., напр.): %d | неоднозначных: %.1f%% | неразрешённых: %.1f%%'
      % (n_tot, len(edges), 100 * n_amb / n_tot, 100 * n_unres / n_tot))
nodes = sorted({a for a, b in edges} | {b for a, b in edges})
idx = {v: i for i, v in enumerate(nodes)}
E = np.array([(idx[a], idx[b]) for a, b in edges], dtype=np.int32)
np.savez_compressed('kernel_graph.npz', edges=E)
json.dump(nodes, open('kernel_nodes.json', 'w'))
print('узлов в графе:', len(nodes))
