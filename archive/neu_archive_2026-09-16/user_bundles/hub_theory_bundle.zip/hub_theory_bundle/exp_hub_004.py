# EXP-HUB-004: валютная сеть Фландро-Йобста 1890/1900/1910. Seed=42.
import csv, json
import numpy as np
import networkx as nx
from exp_hub_001 import crystal, neff_frac, btw_table, coverage_sets

rows = []
with open('fj_data.txt') as f:
    rd = csv.DictReader(f, delimiter='\t')
    for r in rd:
        rows.append({k: (v.strip('"') if isinstance(v, str) else v) for k, v in r.items()})
print('диад:', len(rows))
countries = sorted({r['country_A'] for r in rows})
print('стран:', len(countries))

# Проверка конвенции направления: у GBR должна быть огромная входящая степень
# (фунт котируется всюду), у периферии — почти нулевая.
for yr in ['1890']:
    q = 'quote' + yr
    in_deg = {c: 0 for c in countries}; out_deg = {c: 0 for c in countries}
    for r in rows:
        if r[q] == '1':
            out_deg[r['country_A']] += 1; in_deg[r['country_B']] += 1
    top_in = sorted(in_deg.items(), key=lambda kv: -kv[1])[:5]
    top_out = sorted(out_deg.items(), key=lambda kv: -kv[1])[:5]
    print(yr, 'top in-degree (кого котируют):', top_in)
    print(yr, 'top out-degree (кто котирует):', top_out)

def greedy_rho(G, k=3):
    dist, ps = coverage_sets(G)
    chosen = []
    def rho_of(S):
        Sset = set(S)
        denom = 0; cov = set()
        pairs_ok = set()
        for x, dx in dist.items():
            if x in Sset: continue
            for y in dx:
                if y == x or y in Sset: continue
                denom += 1; pairs_ok.add((x, y))
        for h in S:
            cov |= {p for p in ps[h] if p in pairs_ok}
        return len(cov) / denom if denom else 0.0
    rhos = []
    for _ in range(k):
        best, best_r = None, -1.0
        for h in G.nodes():
            if h in chosen: continue
            r = rho_of(chosen + [h])
            if r > best_r: best_r, best = r, h
        chosen.append(best); rhos.append(round(best_r, 4))
    return chosen, rhos

RES = {}
for yr in ['1890', '1900', '1910']:
    q = 'quote' + yr
    D = nx.DiGraph(); D.add_nodes_from(countries)
    for r in rows:
        if r[q] == '1':
            D.add_edge(r['country_A'], r['country_B'])
    U = nx.Graph()
    U.add_nodes_from(countries)
    for a, b in D.edges():
        U.add_edge(a, b)
    UC = U.subgraph(max(nx.connected_components(U), key=len)).copy()
    m1 = crystal(UC); m2, ne, ncc = neff_frac(UC)
    items_u, top1_u = btw_table(UC)
    items_d, top1_d = btw_table(D)
    evc = nx.eigenvector_centrality_numpy(UC)
    ev_rank = sorted(evc.items(), key=lambda kv: -kv[1])
    deg_rank = sorted(UC.degree(), key=lambda kv: -kv[1])
    hubs, rhos = greedy_rho(UC, 3)
    def rank_of(lst, c): 
        ks = [k for k, _ in lst]
        return ks.index(c) + 1 if c in ks else None
    usa = dict(deg=rank_of(deg_rank, 'USA'), btw=rank_of(items_u, 'USA'), ev=rank_of(ev_rank, 'USA'))
    # ER-нуль
    n, m = UC.number_of_nodes(), UC.number_of_edges()
    nulls = []
    for i in range(50):
        H = nx.gnm_random_graph(n, m, seed=300 + i)
        _, t1 = btw_table(H)
        nulls.append(t1)
    nulls = np.array(nulls)
    RES[yr] = dict(n_cc=ncc, edges=m, M1=round(m1, 4), M2=round(m2, 4),
                   top1_btw=round(top1_u, 4), btw_top5=[(k, round(v, 3)) for k, v in items_u[:5]],
                   btw_top5_directed=[(k, round(v, 3)) for k, v in items_d[:5]],
                   greedy_hubs=hubs, rho123=rhos,
                   ev_top5=[k for k, _ in ev_rank[:5]], deg_top5=[k for k, _ in deg_rank[:5]],
                   USA_ranks=usa,
                   null_top1=f"{nulls.mean():.4f}±{nulls.std():.4f}",
                   z_top1=round(float((top1_u - nulls.mean()) / nulls.std()), 1))
    print(yr, '| n_cc=%d m=%d M1=%.3f M2=%.3f top1=%.3f z=%.1f' % (ncc, m, m1, m2, top1_u, RES[yr]['z_top1']))
    print('   greedy3:', hubs, 'rho1/2/3:', rhos)
    print('   btw top5:', RES[yr]['btw_top5'])
    print('   USA ranks (deg/btw/ev):', usa)

with open('results_hub_004.json', 'w') as f:
    json.dump(RES, f, indent=1, ensure_ascii=False)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
yrs = ['1890', '1900', '1910']
fig, ax = plt.subplots(1, 2, figsize=(8, 3.4))
for i, lab in enumerate(['rho1', 'rho2', 'rho3']):
    ax[0].plot(yrs, [RES[y]['rho123'][i] for y in yrs], marker='o', label=['ρ₁ (GBR)', 'ρ₂', 'ρ₃'][i])
ax[0].set_ylim(0, 1.05); ax[0].legend(fontsize=8); ax[0].set_title('Покрытие хабами', fontsize=10)
for k, lab in [('deg', 'степень'), ('btw', 'betweenness'), ('ev', 'собств. вектор')]:
    ax[1].plot(yrs, [RES[y]['USA_ranks'][k] for y in yrs], marker='s', label=lab)
ax[1].invert_yaxis(); ax[1].legend(fontsize=8); ax[1].set_title('Ранг USD (меньше = выше)', fontsize=10)
plt.tight_layout(); plt.savefig('fig_hub_004.png', dpi=150)
print('fig saved')
