# EXP-PHYS-005: Хиггс как хаб домена масс. Пререг: prereg_exp_phys_005.md
import json
import numpy as np

GF   = 1.1663787e-5      # ГэВ^-2
MZ   = 91.1876
ASMZ = 0.1179
MH   = 125.25
ALPHA= 1/137.035999      # для gamma-gamma берём альфу на нуле (LO-конвенция)
MT   = 172.69            # полюсная масса топа
MW   = 80.377
# массы в собственных схемах
MB_MB, MC_MC = 4.18, 1.27
MTAU, MMU = 1.77686, 0.1056584
REF = dict(bb=57.2, tautau=6.27, cc=2.89, mumu=0.0218, gg=8.54, gamgam=0.228)

v = 1/np.sqrt(np.sqrt(2)*GF)
print('v = %.4f ГэВ  (P-B1: %s)' % (v, 'PASS' if abs(v-246.22) <= 0.05 else 'FAIL'))
PB1 = abs(v-246.22) <= 0.05
yt = np.sqrt(2)*MT/v
PB2 = abs(yt-1) <= 0.01
print('y_top = %.4f  (P-B2: отличие от 1 = %.2f%% -> %s)' % (yt, 100*abs(yt-1), 'PASS' if PB2 else 'FAIL'))
lam = MH**2/(2*v**2)
print('самодействие λ = m_H²/2v² = %.4f | m_H/v = %.4f' % (lam, MH/v))

# ---- бег alpha_s (1 петля, с порогами) и масс кварков ----
def b0(nf): return (33 - 2*nf)/(12*np.pi)
def run_as(a0, mu0, mu, nf):
    return a0/(1 + 2*b0(nf)*a0*np.log(mu/mu0))
as_mb = run_as(ASMZ, MZ, MB_MB, 5)
as_mh = run_as(ASMZ, MZ, MH, 5)
as_mc = run_as(as_mb, MB_MB, MC_MC, 4)
print('α_s: M_Z %.4f | m_b %.4f | m_H %.4f | m_c %.4f' % (ASMZ, as_mb, as_mh, as_mc))
def run_mass(m0, a_from, a_to, nf):
    return m0*(a_to/a_from)**(12/(33-2*nf))
mb_H = run_mass(MB_MB, as_mb, as_mh, 5)
mc_b = run_mass(MC_MC, as_mc, as_mb, 4)      # c: от m_c до m_b при nf=4
mc_H = run_mass(mc_b, as_mb, as_mh, 5)       # далее при nf=5
print('бегущие массы при μ = m_H: m_b = %.3f ГэВ (полюсная 4.78), m_c = %.3f ГэВ' % (mb_H, mc_H))

# ---- парциальные ширины ----
def gamma_ff(mf, nc, qcd=False):
    if 2*mf >= MH: return 0.0
    beta = np.sqrt(1 - 4*mf**2/MH**2)
    G = nc*GF*MH*mf**2/(4*np.sqrt(2)*np.pi)*beta**3
    if qcd: G *= (1 + 5.67*as_mh/np.pi)
    return G
G_bb   = gamma_ff(mb_H, 3, qcd=True)
G_cc   = gamma_ff(mc_H, 3, qcd=True)
G_tau  = gamma_ff(MTAU, 1)
G_mu   = gamma_ff(MMU, 1)
print('\nширины (МэВ): bb %.4f | cc %.4f | ττ %.4f | μμ %.6f'
      % (1e3*G_bb, 1e3*G_cc, 1e3*G_tau, 1e3*G_mu))

# ---- P-B3: закон «один скаляр на клиента» ----
pairs = [('ττ/bb', G_tau/G_bb, REF['tautau']/REF['bb']),
         ('cc/bb', G_cc/G_bb, REF['cc']/REF['bb']),
         ('μμ/ττ', G_mu/G_tau, REF['mumu']/REF['tautau'])]
errs = []
print('\n=== P-B3: отношения из одних масс ===')
for nm, calc, ref in pairs:
    e = abs(calc-ref)/ref; errs.append(e)
    print('  %-6s расчёт %.5f | эталон %.5f | ошибка %5.1f%%' % (nm, calc, ref, 100*e))
PB3 = all(e <= 0.20 for e in errs)
print('P-B3:', 'PASS' if PB3 else 'FAIL')

# ---- P-B4: полюсные массы ломают закон ----
MB_POLE, MC_POLE = 4.78, 1.67
G_bb_pole = gamma_ff(MB_POLE, 3, qcd=True)
r_pole = G_tau/G_bb_pole
ref_r = REF['tautau']/REF['bb']
PB4 = r_pole < 0.5*ref_r
print('\n=== P-B4: заряд без масштаба ===')
print('  ττ/bb с бегущей массой %.4f | с полюсной %.4f | эталон %.4f' % (G_tau/G_bb, r_pole, ref_r))
print('  полюсная даёт %.2f от эталона -> %s' % (r_pole/ref_r, 'PASS' if PB4 else 'FAIL'))

# ---- P-B5: петлевые каналы ----
def A12(tau):   # tau = m_H^2/(4 m^2)
    if tau <= 1:
        f = np.arcsin(np.sqrt(tau))**2
    else:
        eta = np.sqrt(1-1/tau)
        f = -0.25*(np.log((1+eta)/(1-eta)) - 1j*np.pi)**2
    return 2*(tau + (tau-1)*f)/tau**2
def A1(tau):
    if tau <= 1: f = np.arcsin(np.sqrt(tau))**2
    else:
        eta = np.sqrt(1-1/tau); f = -0.25*(np.log((1+eta)/(1-eta)) - 1j*np.pi)**2
    return -(2*tau**2 + 3*tau + 3*(2*tau-1)*f)/tau**2
tau_t = MH**2/(4*MT**2); tau_W = MH**2/(4*MW**2); tau_b = MH**2/(4*mb_H**2)
Agg = 0.75*(A12(tau_t) + A12(tau_b))          # 3/4 * sum A_{1/2} (кварковая петля)
G_gg = GF*as_mh**2*MH**3/(36*np.sqrt(2)*np.pi**3)*abs(Agg)**2
Agam = A1(tau_W) + 3*(2/3)**2*A12(tau_t) + 3*(-1/3)**2*A12(tau_b)
G_gam = GF*ALPHA**2*MH**3/(128*np.sqrt(2)*np.pi**3)*abs(Agam)**2
ratio_calc = G_gam/G_gg
ratio_ref = REF['gamgam']/REF['gg']
PB5 = 0.5 <= ratio_calc/ratio_ref <= 2.0
print('\n=== P-B5: петлевой сектор ===')
print('  Γ(gg) = %.4f МэВ | Γ(γγ) = %.5f МэВ' % (1e3*G_gg, 1e3*G_gam))
print('  γγ/gg расчёт %.5f | эталон %.5f | отношение %.2f -> %s'
      % (ratio_calc, ratio_ref, ratio_calc/ratio_ref, 'PASS' if PB5 else 'FAIL'))

# ---- P-B6: калибровочный интервал ----
e_tau_bb = 100*errs[0]
PB6 = abs(e_tau_bb - 10) <= 15
print('\nP-B6: ошибка ττ/bb = %.1f%% | зарегистрировано 10%% ± 15%% -> %s'
      % (e_tau_bb, 'ПОПАЛ' if PB6 else 'МИМО'))

# ---- сводка + структура хаба ----
print('\n=== ЮКАВЫ (заряды домена масс) ===')
for nm, m in [('t', MT), ('b(m_H)', mb_H), ('τ', MTAU), ('c(m_H)', mc_H), ('μ', MMU), ('e', 0.000511)]:
    print('  y_%-7s = %.3e' % (nm, np.sqrt(2)*m/v))
print('  разброс y_t/y_e = %.2e — шесть порядков (проблема ароматов, хаб её НЕ объясняет)'
      % (MT/0.000511))
print('\nkill (P-B3):', 'FIRED' if not PB3 else 'no')
json.dump(dict(v=v, yt=yt, lam=lam, alphas=dict(mb=as_mb, mh=as_mh),
               running=dict(mb_H=mb_H, mc_H=mc_H),
               widths_MeV=dict(bb=1e3*G_bb, cc=1e3*G_cc, tautau=1e3*G_tau,
                               mumu=1e3*G_mu, gg=1e3*G_gg, gamgam=1e3*G_gam),
               pairs=[[n, float(c), float(r), float(abs(c-r)/r)] for n, c, r in pairs],
               PB1=bool(PB1), PB2=bool(PB2), PB3=bool(PB3), PB4=bool(PB4),
               PB5=bool(PB5), PB6=bool(PB6),
               pole_ratio=float(r_pole/ref_r), loop_ratio=float(ratio_calc/ratio_ref)),
          open('results_phys_005.json','w'), indent=1, ensure_ascii=False)
