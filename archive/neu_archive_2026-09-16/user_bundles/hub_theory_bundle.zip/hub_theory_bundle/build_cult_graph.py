# EXP-CULT-001 build. Детерминизм.
import gzip, csv, json
from collections import Counter

# Glottolog: Name -> Family (языки уровня language; неоднозначные имена — вон)
fam_id = {}; names = {}
rows = list(csv.DictReader(open('glottolog_languages.csv', encoding='utf-8')))
id2name = {r['ID']: r['Name'] for r in rows}
name2fams = {}
for r in rows:
    if r['Level'] != 'language': continue
    nm = r['Name']
    fid = r['Family_ID'] or r['ID']
    name2fams.setdefault(nm, set()).add(fid)
amb = sum(1 for v in name2fams.values() if len(v) > 1)
fam_of = {nm: id2name.get(next(iter(v)), next(iter(v)))
          for nm, v in name2fams.items() if len(v) == 1}
print('имён языков: %d, неоднозначных: %d, разрешено: %d'
      % (len(name2fams), amb, len(fam_of)))

rt = Counter()
bor = Counter(); inh = Counter(); don_vol = Counter()
calques = 0
with gzip.open('etymology.csv.gz', 'rt', encoding='utf-8', errors='replace') as f:
    rd = csv.DictReader(f)
    for r in rd:
        t = r['reltype']; rt[t] += 1
        a, b = r['related_lang'], r['lang']   # донор -> реципиент
        if not a or not b or a == b: continue
        if 'borrow' in t:
            bor[(a, b)] += 1; don_vol[a] += 1
        elif t == 'inherited_from':
            inh[(a, b)] += 1
        elif 'calque' in t:
            calques += 1
print('топ reltype:', rt.most_common(8))
print('заимствований (событий): %d, пар: %d | наследований: %d, пар: %d | кальки исключены: %d'
      % (sum(bor.values()), len(bor), sum(inh.values()), len(inh), calques))
print('топ-10 доноров по объёму:', don_vol.most_common(10))
json.dump(dict(bor={f'{a}||{b}': v for (a, b), v in bor.items()},
               inh={f'{a}||{b}': v for (a, b), v in inh.items()},
               don=dict(don_vol), fam=fam_of, calques=calques),
          open('cult_agg.json', 'w'), ensure_ascii=False)
print('сохранено cult_agg.json')
