# EXP-TRANS-001: башня в выученном предикторе. Seed=42. Пререг: prereg_exp_trans_001.md
import json, math
import numpy as np
import torch, torch.nn as nn

rng = np.random.default_rng(42)
torch.manual_seed(42)
V, CTX, D, NH, NL, STEPS, BATCH = 27, 64, 48, 2, 2, 3000, 64

# --- цепи ---
def block_uniform(size):
    P = np.zeros((V, V))
    for s in range(0, V, size): P[s:s+size, s:s+size] = 1.0/size
    return P
R = rng.dirichlet(np.ones(V), size=V)
T = 0.95*(0.55*block_uniform(3) + 0.30*block_uniform(9) + 0.15*block_uniform(27)) + 0.05*R
F = 0.05*np.ones((V, V))/V + 0.95*rng.dirichlet(np.ones(V), size=V)

def stationary(P):
    pi = np.ones(V)/V
    for _ in range(4000): pi = pi @ P; pi /= pi.sum()
    return pi
def ent_rate(P):
    pi = stationary(P)
    return float(-(pi[:, None]*P*np.log(np.maximum(P, 1e-300))).sum())
H_T, H_F = ent_rate(T), ent_rate(F)
print('энтропийные скорости: иерархия %.4f нат, контроль %.4f нат' % (H_T, H_F))

def sample(P, n, L):
    pi = stationary(P); cs = P.cumsum(1)
    x = np.zeros((n, L), int)
    x[:, 0] = rng.choice(V, size=n, p=pi)
    for t in range(1, L):
        u = rng.random(n)
        x[:, t] = (cs[x[:, t-1]] < u[:, None]).sum(1)
    return x
trainA, testA = sample(T, 4000, CTX+1), sample(T, 500, CTX+1)
trainB, testB = sample(F, 4000, CTX+1), sample(F, 500, CTX+1)

# --- модель ---
class Tiny(nn.Module):
    def __init__(self):
        super().__init__()
        self.te = nn.Embedding(V, D); self.pe = nn.Embedding(CTX, D)
        self.attn = nn.ModuleList([nn.MultiheadAttention(D, NH, batch_first=True) for _ in range(NL)])
        self.ff = nn.ModuleList([nn.Sequential(nn.Linear(D, 96), nn.GELU(), nn.Linear(96, D)) for _ in range(NL)])
        self.ln1 = nn.ModuleList([nn.LayerNorm(D) for _ in range(NL)])
        self.ln2 = nn.ModuleList([nn.LayerNorm(D) for _ in range(NL)])
        self.out = nn.Linear(D, V)
    def forward(self, x, need_attn=False):
        B, L = x.shape
        h = self.te(x) + self.pe(torch.arange(L))[None]
        mask = torch.triu(torch.ones(L, L, dtype=torch.bool), 1)
        aw = None
        for i in range(NL):
            hn = self.ln1[i](h)
            a, w = self.attn[i](hn, hn, hn, attn_mask=mask,
                                need_weights=need_attn, average_attn_weights=True)
            h = h + a
            h = h + self.ff[i](self.ln2[i](h))
            aw = w
        return self.out(h), aw

def train(model, data, name):
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    lossf = nn.CrossEntropyLoss()
    for step in range(STEPS):
        idx = rng.integers(0, len(data), BATCH)
        x = torch.tensor(data[idx])
        logits, _ = model(x[:, :-1])
        loss = lossf(logits.reshape(-1, V), x[:, 1:].reshape(-1))
        opt.zero_grad(); loss.backward(); opt.step()
        if (step+1) % 1000 == 0: print('  %s шаг %d CE=%.4f' % (name, step+1, loss.item()))
    return model

mA = Tiny(); init = {k: v.clone() for k, v in mA.state_dict().items()}
mB = Tiny(); mB.load_state_dict(init)
print('обучение A (иерархия)...'); train(mA, trainA, 'A')
print('обучение B (контроль)...'); train(mB, trainB, 'B')

@torch.no_grad()
def test_ce(model, data):
    x = torch.tensor(data)
    logits, _ = model(x[:, :-1])
    return float(nn.CrossEntropyLoss()(logits.reshape(-1, V), x[:, 1:].reshape(-1)))
ceA, ceB = test_ce(mA, testA), test_ce(mB, testB)
gate = ceA <= 1.05*H_T and ceB <= 1.05*H_F
print('CE тест: A %.4f (H=%.4f, x%.3f) | B %.4f (H=%.4f, x%.3f) | шлюз %s'
      % (ceA, H_T, ceA/H_T, ceB, H_F, ceB/H_F, 'PASS' if gate else 'FAIL'))

@torch.no_grad()
def learned_kernel(model, data):
    x = torch.tensor(data)
    logits, _ = model(x[:, :-1])
    probs = torch.softmax(logits, -1).numpy()
    P = np.zeros((V, V)); cnt = np.zeros(V)
    cur = data[:, :-1]
    for s in range(V):
        m = cur == s
        P[s] = probs[m].sum(0); cnt[s] = m.sum()
    return P / np.maximum(cnt[:, None], 1)
PA, PB = learned_kernel(mA, testA), learned_kernel(mB, testB)

def gaps(P):
    lam = np.sort(np.abs(np.linalg.eigvals(P)))[::-1]
    r = {k: lam[k-1]/lam[k] for k in range(2, 13)}
    top2 = sorted(sorted(r, key=lambda k: -r[k])[:2])
    return lam, r, top2
lamT, _, _ = gaps(T)
lamA, rA, topA = gaps(PA)
lamB, rB, topB = gaps(PB)
PT1 = (topA == [3, 9] and rA[3] >= 1.2 and rA[9] >= 1.2) and (topB != [3, 9])
print('щели A на позициях %s (%.2f, %.2f) | B на %s | P-T1 %s'
      % (topA, rA[topA[0]], rA[topA[1]], topB, 'PASS' if PT1 else 'FAIL'))

tau = lambda lam: -1/np.log(np.clip(lam[1:10], 1e-9, 0.999999))
from scipy.stats import spearmanr
rho, _ = spearmanr(tau(lamA), tau(lamT))
PT2 = rho >= 0.8
print('Спирмен(tau_A, tau_true) = %.3f | P-T2 %s' % (rho, 'PASS' if PT2 else 'FAIL'))

def eps_mean(P, labels):
    classes = sorted(set(labels)); li = np.array(labels)
    Agg = np.stack([P[:, li == c].sum(1) for c in classes], 1)
    tot = tw = 0.0
    for c in classes:
        ids = np.where(li == c)[0]
        d = [0.5*np.abs(Agg[a]-Agg[b]).sum() for a in ids for b in ids if a < b]
        if d: tot += np.mean(d)*len(ids); tw += len(ids)
    return tot/tw
true3 = [i//9 for i in range(V)]; true9 = [i//3 for i in range(V)]
def eps_test(P):
    out = {}
    for nm, lab in [('3', true3), ('9', true9)]:
        e = eps_mean(P, lab)
        nulls = [eps_mean(P, list(rng.permutation(lab))) for _ in range(100)]
        out[nm] = (e, min(nulls), e < min(nulls))
    return out
eA, eB = eps_test(PA), eps_test(PB)
PT3 = eA['3'][2] and eA['9'][2] and not (eB['3'][2] and eB['9'][2])
print('eps A: 3-разб %.4f<%.4f=%s, 9-разб %.4f<%.4f=%s | B: %s,%s | P-T3 %s'
      % (eA['3'][0], eA['3'][1], eA['3'][2], eA['9'][0], eA['9'][1], eA['9'][2],
         eB['3'][2], eB['9'][2], 'PASS' if PT3 else 'FAIL'))

def emb_test(model):
    E = model.te.weight.detach().numpy()
    Dm = np.linalg.norm(E[:, None]-E[None], axis=-1)
    wt, w9, ac = [], [], []
    for i in range(V):
        for j in range(i+1, V):
            if i//3 == j//3: wt.append(Dm[i, j])
            elif i//9 == j//9: w9.append(Dm[i, j])
            else: ac.append(Dm[i, j])
    mt, m9, ma = map(np.median, (wt, w9, ac))
    stat = ma - mt
    nulls = []
    for _ in range(200):
        perm = rng.permutation(V)
        wt2, ac2 = [], []
        for i in range(V):
            for j in range(i+1, V):
                pi_, pj = perm[i], perm[j]
                if pi_//3 == pj//3: wt2.append(Dm[i, j])
                elif pi_//9 != pj//9: ac2.append(Dm[i, j])
        nulls.append(np.median(ac2)-np.median(wt2))
    z = (stat-np.mean(nulls))/np.std(nulls)
    return mt, m9, ma, z, (mt < m9 < ma and z >= 3)
tA = emb_test(mA); tB = emb_test(mB)
PT4 = tA[4] and not tB[4]
print('эмбеддинги A: %.3f < %.3f < %.3f, z=%.1f (%s) | B: z=%.1f (%s) | P-T4 %s'
      % (tA[0], tA[1], tA[2], tA[3], tA[4], tB[3], tB[4], 'PASS' if PT4 else 'FAIL'))

@torch.no_grad()
def attn_levels(model, data):
    x = torch.tensor(data[:200])
    _, w = model(x[:, :-1], need_attn=True)  # последний слой, усреднён по головам
    w = w.numpy(); toks = data[:200, :-1]
    acc = {'triple': [], 'nine': [], 'other': []}
    for b in range(w.shape[0]):
        for t in range(8, CTX):
            for j_ in range(t):
                a, bb = toks[b, t], toks[b, j_]
                key = 'triple' if a//3 == bb//3 else ('nine' if a//9 == bb//9 else 'other')
                acc[key].append(w[b, t, j_])
    return {k: float(np.mean(v)) for k, v in acc.items()}
attA, attB = attn_levels(mA, testA), attn_levels(mB, testB)
print('внимание A по уровням:', attA, '| B:', attB)

kill = gate and (not PT1) and (not PT3)
print('ИТОГ: шлюз %s | P-T1 %s | P-T2 %s | P-T3 %s | P-T4 %s | kill %s'
      % (gate, PT1, PT2, PT3, PT4, 'FIRED' if kill else 'no'))
json.dump(dict(H=[H_T, H_F], ce=[ceA, ceB], gate=bool(gate),
               lamT=lamT[:12].tolist(), lamA=lamA[:12].tolist(), lamB=lamB[:12].tolist(),
               topA=topA, topB=topB, PT1=bool(PT1), rho=float(rho), PT2=bool(PT2),
               eps=dict(A={k: v[:2] for k, v in eA.items()}, B={k: v[:2] for k, v in eB.items()}),
               PT3=bool(PT3), emb=dict(A=tA[:4], B=tB[:4]), PT4=bool(PT4),
               attn=dict(A=attA, B=attB), kill=bool(kill)),
          open('results_trans_001.json', 'w'), indent=1, default=float)

import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.figure(figsize=(6, 3.6))
plt.plot(range(1, 13), lamT[:12], 'o-', label='истинная T')
plt.plot(range(1, 13), lamA[:12], 's-', label='выученное ядро A')
plt.plot(range(1, 13), lamB[:12], '^--', label='контроль B')
plt.yscale('log'); plt.xlabel('ранг'); plt.ylabel('|λ|')
plt.axvline(3.5, color='gray', ls=':', lw=0.7); plt.axvline(9.5, color='gray', ls=':', lw=0.7)
plt.legend(fontsize=8); plt.title('Башня в спектре выученного ядра', fontsize=10)
plt.tight_layout(); plt.savefig('fig_trans_001.png', dpi=150)
print('fig ok')
