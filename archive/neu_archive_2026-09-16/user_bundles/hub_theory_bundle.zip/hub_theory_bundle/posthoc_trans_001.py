import numpy as np, torch
import torch.nn as nn
rng = np.random.default_rng(42)
torch.manual_seed(42)
src = open('exp_trans_001.py').read().split('mA = Tiny()')[0]
exec(src)
mA = Tiny(); init = {k: v.clone() for k, v in mA.state_dict().items()}
mB = Tiny(); mB.load_state_dict(init)
train(mA, trainA, 'A'); train(mB, trainB, 'B')
def geom_test(E, tag):
    Dm = np.linalg.norm(E[:, None]-E[None], axis=-1)
    wt, w9, ac = [], [], []
    for i in range(V):
        for j in range(i+1, V):
            if i//3 == j//3: wt.append(Dm[i, j])
            elif i//9 == j//9: w9.append(Dm[i, j])
            else: ac.append(Dm[i, j])
    mt, m9, ma = map(np.median, (wt, w9, ac))
    stat = ma - mt; nulls = []
    for _ in range(200):
        perm = rng.permutation(V); wt2, ac2 = [], []
        for i in range(V):
            for j in range(i+1, V):
                pi_, pj = perm[i], perm[j]
                if pi_//3 == pj//3: wt2.append(Dm[i, j])
                elif pi_//9 != pj//9: ac2.append(Dm[i, j])
        nulls.append(np.median(ac2)-np.median(wt2))
    z = (stat-np.mean(nulls))/np.std(nulls)
    print('%s: %.3f < %.3f < %.3f | z=%.1f | strict+z>=3: %s' % (tag, mt, m9, ma, z, bool(mt<m9<ma and z>=3)))
geom_test(mA.out.weight.detach().numpy(), 'POSTHOC unembedding A')
geom_test(mB.out.weight.detach().numpy(), 'POSTHOC unembedding B')
