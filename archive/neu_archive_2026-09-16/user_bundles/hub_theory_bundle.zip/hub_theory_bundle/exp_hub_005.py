# EXP-HUB-005: автоматическая детекция калибровочного слоя. Seed=42.
# ПРЕРЕГИСТРАЦИЯ (до запуска): жадное удаление argmax дельта-M1, 15 шагов.
# Успех: >=9/15 удалённых входят в валютный список (нуль ~29%). Провал: <=4.
# Параллельно: rank(K) = dim левого ядра внутренней стехиометрической матрицы.
import gzip, json
import xml.etree.ElementTree as ET
import numpy as np, networkx as nx
from exp_hub_001 import crystal, MET, CURRENCY, cur_in_graph

G0 = nx.Graph(MET)
print('узлов:', G0.number_of_nodes(), '| валютных в графе:', len(cur_in_graph),
      '| нулевая доля: %.2f' % (len(cur_in_graph) / G0.number_of_nodes()))

G = G0.copy(); removed = []
for step in range(15):
    best, bestm = None, -2.0
    for v in list(G.nodes()):
        H = G.copy(); H.remove_node(v)
        if H.number_of_nodes() < 3: continue
        m = crystal(H)
        if m is not None and m > bestm:
            bestm, best = m, v
    G.remove_node(best)
    removed.append((best, round(bestm, 4), best in CURRENCY))
hits = sum(1 for _, _, c in removed if c)
print('удалено (узел, M1 после, валюта?):')
for r in removed: print('  ', r)
print('ПОПАДАНИЙ: %d/15 (порог успеха >=9, провала <=4)' % hits)

# rank(K): левое ядро стехиометрии (внутренние реакции, без EX_/BIOMASS)
data = gzip.open('textbook.xml.gz', 'rb').read()
root = ET.fromstring(data)
ns = {'s': root.tag.split('}')[0].strip('{')}
model = root.find('s:model', ns)
mets = [sp.get('id') for sp in model.find('s:listOfSpecies', ns)
        if sp.get('boundaryCondition') != 'true']
midx = {m: i for i, m in enumerate(mets)}
cols = []
for rx in model.find('s:listOfReactions', ns):
    rid = (rx.get('id') or '').upper()
    if 'EX_' in rid or 'BIOMASS' in rid: continue
    col = np.zeros(len(mets))
    lr = rx.find('s:listOfReactants', ns); lp = rx.find('s:listOfProducts', ns)
    for sr in (lr if lr is not None else []):
        if sr.get('species') in midx:
            col[midx[sr.get('species')]] -= float(sr.get('stoichiometry') or 1)
    for sr in (lp if lp is not None else []):
        if sr.get('species') in midx:
            col[midx[sr.get('species')]] += float(sr.get('stoichiometry') or 1)
    cols.append(col)
S = np.array(cols).T
r = np.linalg.matrix_rank(S)
print('S: %d метаболитов x %d реакций, rank=%d, dim left-null = rank(K) = %d'
      % (S.shape[0], S.shape[1], r, S.shape[0] - r))

# b1 валютных сетей
edges = {'1890': 155, '1900': 171, '1910': 202}
for y, m in edges.items():
    print('b1(%s) = %d' % (y, m - 44))
print('b1(USD top-pairs 2022) = 0 (дерево); с EUR-кроссами = 3')

json.dump(dict(removed=removed, hits=hits, rankK=int(S.shape[0] - r)),
          open('results_hub_005.json', 'w'), ensure_ascii=False, indent=1)
