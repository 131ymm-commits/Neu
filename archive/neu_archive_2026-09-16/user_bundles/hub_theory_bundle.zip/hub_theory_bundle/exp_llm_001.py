# EXP-LLM-001. Seed=42. Пререг: prereg_exp_llm_001.md
import json
import numpy as np, torch, torch.nn as nn

rng = np.random.default_rng(42); torch.manual_seed(42)
CTX = 24

def block_uniform(V, size):
    P = np.zeros((V, V))
    for s in range(0, V, size): P[s:s+size, s:s+size] = 1.0/size
    return P

def chain(V, weights):
    R = rng.dirichlet(np.ones(V), size=V)
    T = np.zeros((V, V))
    for size, w in weights: T += w*block_uniform(V, size)
    return 0.95*T + 0.05*R

def sample(P, n, L, V):
    pi = np.ones(V)/V
    for _ in range(2000): pi = pi @ P; pi /= pi.sum()
    cs = P.cumsum(1); x = np.zeros((n, L), int)
    x[:, 0] = rng.choice(V, size=n, p=pi)
    for t in range(1, L):
        u = rng.random(n); x[:, t] = (cs[x[:, t-1]] < u[:, None]).sum(1)
    return x

class Tiny(nn.Module):
    def __init__(self, V, D, NL, NH=2):
        super().__init__()
        self.V, self.NL = V, NL
        self.te = nn.Embedding(V, D); self.pe = nn.Embedding(CTX, D)
        self.at = nn.ModuleList([nn.MultiheadAttention(D, NH, batch_first=True) for _ in range(NL)])
        self.ff = nn.ModuleList([nn.Sequential(nn.Linear(D, 2*D), nn.GELU(), nn.Linear(2*D, D)) for _ in range(NL)])
        self.l1 = nn.ModuleList([nn.LayerNorm(D) for _ in range(NL)])
        self.l2 = nn.ModuleList([nn.LayerNorm(D) for _ in range(NL)])
        self.out = nn.Linear(D, V)
    def forward(self, x):
        B, L = x.shape
        h = self.te(x) + self.pe(torch.arange(L))[None]
        mask = torch.triu(torch.ones(L, L, dtype=torch.bool), 1)
        for i in range(self.NL):
            hn = self.l1[i](h)
            a, _ = self.at[i](hn, hn, hn, attn_mask=mask, need_weights=False)
            h = h + a; h = h + self.ff[i](self.l2[i](h))
        return self.out(h)

@torch.no_grad()
def kernel(model, data, V):
    x = torch.tensor(data)
    pr = torch.softmax(model(x[:, :-1]), -1).numpy()
    cur = data[:, :-1]; P = np.zeros((V, V)); c = np.zeros(V)
    for s in range(V):
        m = cur == s
        if m.sum(): P[s] = pr[m].sum(0); c[s] = m.sum()
    return P/np.maximum(c[:, None], 1)

def gaps(P, positions):
    lam = np.sort(np.abs(np.linalg.eigvals(P)))[::-1]
    return {p: float(lam[p-1]/max(lam[p], 1e-12)) for p in positions}

def run(V, weights, D, NL, steps, positions, tag, ckpt=100):
    T = chain(V, weights)
    tr = sample(T, 1500, CTX+1, V); te = sample(T, 200, CTX+1, V)
    m = Tiny(V, D, NL); opt = torch.optim.AdamW(m.parameters(), lr=2e-3)
    lf = nn.CrossEntropyLoss()
    npar = sum(p.numel() for p in m.parameters())
    hist = []
    for st in range(steps):
        idx = rng.integers(0, len(tr), 48); xb = torch.tensor(tr[idx])
        loss = lf(m(xb[:, :-1]).reshape(-1, V), xb[:, 1:].reshape(-1))
        opt.zero_grad(); loss.backward(); opt.step()
        if (st+1) % ckpt == 0:
            g = gaps(kernel(m, te, V), positions)
            hist.append((st+1, float(loss.item()), g))
    print('  %-22s V=%-3d D=%-3d слоёв=%d параметров=%-7d финальные щели: %s'
          % (tag, V, D, NL, npar, {k: round(v, 2) for k, v in hist[-1][2].items()}))
    return hist, npar

THR = 1.3
def acquired(hist, pos):
    for st, _, g in hist:
        if g[pos] >= THR: return st
    return None

print('ЧАСТЬ A: порядок появления уровней (27 состояний, щели на 3 и 9)')
histA, _ = run(27, [(3, 0.55), (9, 0.30), (27, 0.15)], 48, 2, 3000, [3, 9], 'иерархия 3×3×3')
t3, t9 = acquired(histA, 3), acquired(histA, 9)
print('  шаг приобретения: грубый уровень (щель 3) = %s | мелкий (щель 9) = %s' % (t3, t9))
PL1 = (t3 is not None) and (t9 is None or t3 < t9)
ratio = (t9/t3) if (t3 and t9) else None
PL2 = ratio is not None and abs(ratio - 2.5) <= 2.0
print('  P-L1 (грубый раньше мелкого): %s' % ('PASS' if PL1 else 'FAIL'))
print('  P-L2 отношение %s | регистр. 2.5 ± 2.0 -> %s'
      % (round(ratio, 2) if ratio else 'н/д', 'ПОПАЛ' if PL2 else 'МИМО'))
print('  траектория щелей:')
for st, ls, g in histA[::5]:
    print('    шаг %-5d loss %.3f  щель@3 = %.2f  щель@9 = %.2f' % (st, ls, g[3], g[9]))

print('\nЧАСТЬ B: правило усложнения — глубина против ширины (81 состояние, щели 3, 9, 27)')
W = [(3, 0.45), (9, 0.25), (27, 0.20), (81, 0.10)]
cfgs = [('глубина 1, ширина 96', 96, 1), ('глубина 2, ширина 56', 56, 2),
        ('глубина 3, ширина 40', 40, 3)]
res = {}
for tag, D, NL in cfgs:
    h, npar = run(81, W, D, NL, 2500, [3, 9, 27], tag)
    lv = sum(1 for p in (3, 9, 27) if h[-1][2][p] >= THR)
    res[tag] = dict(levels=lv, params=npar, gaps=h[-1][2])
    print('    приобретено уровней: %d из 3' % lv)
d1 = res['глубина 1, ширина 96']['levels']; d3 = res['глубина 3, ширина 40']['levels']
PL3 = d1 <= 1 and d3 >= 2
best = max(r['levels'] for r in res.values())
PL4 = best >= 2
print('\n  P-L3 (глубина решает, не ширина): глубина1 = %d, глубина3 = %d -> %s' % (d1, d3, 'PASS' if PL3 else 'FAIL'))
print('  P-L4 (максимум ≥ 2 уровня): достигнуто %d -> %s' % (best, 'PASS' if PL4 else 'FAIL'))
json.dump(dict(t3=t3, t9=t9, PL1=bool(PL1), ratio=ratio, PL2=bool(PL2),
               partB={k: res[k] for k in res}, PL3=bool(PL3), best=best, PL4=bool(PL4),
               histA=[(s, l, {str(k): v for k, v in g.items()}) for s, l, g in histA]),
          open('results_llm_001.json','w'), indent=1, default=float)
