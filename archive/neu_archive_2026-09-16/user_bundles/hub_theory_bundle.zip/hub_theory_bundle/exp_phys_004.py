# EXP-PHYS-004: адронный этаж. Seed=42. Пререг: prereg_exp_phys_004.md
import json, re
import numpy as np
from particle import Particle
from scipy.stats import pearsonr

def strangeness(p):
    q = p.quarks or ''
    return -(q.count('s') - q.count('S'))
def light(p):
    q = (p.quarks or '')
    return bool(q) and set(q.lower()) <= set('uds') and 'x(' not in q

# ---- декуплет 3/2+ (основные состояния) ----
DEC = {0: 2224, -1: 3224, -2: 3324, -3: 3334}      # Delta++, Sigma*+, Xi*0, Omega-
OCT = dict(N=2212, L=3122, S=3212, X=3322)          # p, Lambda, Sigma0, Xi0
PS  = dict(pi=211, K=321, eta=221)                  # pi+, K+, eta

dec = {s: Particle.from_pdgid(pid) for s, pid in DEC.items()}
for s, p in sorted(dec.items(), reverse=True):
    print('  S=%2d  %-14s m=%8.2f МэВ  quarks=%s' % (s, p.name, p.mass, p.quarks))

S = np.array([abs(s) for s in sorted(dec)], float)
M = np.array([dec[s].mass for s in sorted(dec)], float)
r, _ = pearsonr(S, M)
A = np.vstack([S, np.ones(len(S))]).T
b_full, a_full = np.linalg.lstsq(A, M, rcond=None)[0]
PH1 = abs(r) >= 0.99 and 130 <= b_full <= 165
print('\nP-H1: корреляция m(|S|) = %.6f | шаг b = %.2f МэВ (регистр. [130,165]) -> %s'
      % (r, b_full, 'PASS' if PH1 else 'FAIL'))
resid = M - (b_full*S + a_full)
print('     остатки аффинной модели, МэВ:', np.round(resid, 2))

# P-H2: слепая экстраполяция на S=-3
Sf = np.array([0, 1, 2], float); Mf = np.array([dec[0].mass, dec[-1].mass, dec[-2].mass])
Af = np.vstack([Sf, np.ones(3)]).T
bb, aa = np.linalg.lstsq(Af, Mf, rcond=None)[0]
pred = bb*3 + aa
true = dec[-3].mass
err = abs(pred-true)/true
PH2 = err <= 0.01
print('P-H2: по S=0,-1,-2 предсказано m(Omega) = %.2f МэВ, PDG = %.2f, ошибка %.3f%% -> %s'
      % (pred, true, 100*err, 'PASS' if PH2 else 'FAIL'))
print('     зарегистрированный интервал точности: 0.3%% ± 0.7%% -> [%.1f%%, %.1f%%] : %s'
      % (0.0, 1.0, 'ПОПАЛ' if abs(100*err - 0.3) <= 0.7 else 'МИМО'))
cal2 = abs(100*err - 0.3) <= 0.7

# P-H3: ГМО для октета 1/2+
oct_ = {k: Particle.from_pdgid(v) for k, v in OCT.items()}
mN, mL, mS, mX = (oct_['N'].mass, oct_['L'].mass, oct_['S'].mass, oct_['X'].mass)
lhs, rhs = 2*(mN+mX), 3*mL+mS
gmo = abs(lhs-rhs)/lhs
PH3 = gmo < 0.01
print('\nP-H3: ГМО октета: 2(N+Xi) = %.2f, 3L+S = %.2f, невязка %.3f%% -> %s'
      % (lhs, rhs, 100*gmo, 'PASS' if PH3 else 'FAIL'))

# P-H4: выбор монотона в мезонном секторе
ps = {k: Particle.from_pdgid(v) for k, v in PS.items()}
mpi, mK, meta = ps['pi'].mass, ps['K'].mass, ps['eta'].mass
lin = abs(4*mK - (mpi + 3*meta))/(4*mK)
quad = abs(4*mK**2 - (mpi**2 + 3*meta**2))/(4*mK**2)
PH4 = quad < 0.05 and lin > 0.10
print('P-H4: мезоны, ГМО на массе:   4K = %.1f, pi+3eta = %.1f, невязка %.1f%%'
      % (4*mK, mpi+3*meta, 100*lin))
print('      мезоны, ГМО на квадрате: 4K² = %.0f, pi²+3eta² = %.0f, невязка %.1f%% -> %s'
      % (4*mK**2, mpi**2+3*meta**2, 100*quad, 'PASS' if PH4 else 'FAIL'))

# P-H5: leave-one-out по мультиплетам
def loo(masses, svals, square=False):
    y = np.array(masses, float); x = np.array([abs(s) for s in svals], float)
    if square: y = y**2
    errs = []
    for i in range(len(y)):
        m = np.ones(len(y), bool); m[i] = False
        Ai = np.vstack([x[m], np.ones(m.sum())]).T
        bi, ai = np.linalg.lstsq(Ai, y[m], rcond=None)[0]
        p = bi*x[i] + ai
        t = y[i]
        if square: p, t = np.sqrt(max(p, 1e-9)), np.sqrt(t)
        errs.append(abs(p-t)/t)
    return errs
E = []
E += loo([dec[s].mass for s in sorted(dec)], sorted(dec))                     # декуплет
E += loo([mN, mL, mX], [0, -1, -2])                                           # октет: N, Lambda, Xi
E += loo([mpi, mK, meta], [0, -1, -2], square=True)                           # псевдоскаляры на m²
med = float(np.median(E))
PH5 = True  # числовой пункт, засчитывается интервалом
print('\nP-H5: leave-one-out по трём мультиплетам, n=%d; ошибки, %%:' % len(E),
      np.round(100*np.array(E), 2))
print('      медиана %.2f%% | зарегистрировано 1.5%% ± 1.5%% -> [0.0%%, 3.0%%] : %s'
      % (100*med, 'ПОПАЛ' if abs(100*med - 1.5) <= 1.5 else 'МИМО'))
cal5 = abs(100*med - 1.5) <= 1.5

# сводка
dirs = [('P-H1', PH1), ('P-H2', PH2), ('P-H3', PH3), ('P-H4', PH4)]
print('\n=== СВОДКА ===')
for nm, ok in dirs: print('  %s: %s' % (nm, 'PASS' if ok else 'FAIL'))
print('  калибровочные интервалы: P-H2 %s, P-H5 %s'
      % ('ПОПАЛ' if cal2 else 'МИМО', 'ПОПАЛ' if cal5 else 'МИМО'))
print('  kill (P-H1):', 'FIRED' if not PH1 else 'no')
json.dump(dict(decuplet={str(s): [dec[s].name, dec[s].mass] for s in dec},
               r=float(r), b=float(b_full), PH1=bool(PH1),
               omega=dict(pred=float(pred), true=float(true), err=float(err)), PH2=bool(PH2),
               gmo_baryon=float(gmo), PH3=bool(PH3),
               meson=dict(lin=float(lin), quad=float(quad)), PH4=bool(PH4),
               loo=[float(x) for x in E], loo_median=med,
               calib=dict(PH2=bool(cal2), PH5=bool(cal5))),
          open('results_phys_004.json','w'), indent=1, ensure_ascii=False)
