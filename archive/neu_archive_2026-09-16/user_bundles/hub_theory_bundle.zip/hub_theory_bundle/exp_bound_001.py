# EXP-BOUND-001: шкала хаб-шунт / хаб-среда. Seed=42.
# ПРЕРЕГИСТРАЦИЯ (до счёта). R = |LCC после удаления| / |узлов до|.
# Два удаления: доменный хаб-набор (где определён) и top-5% по степени.
# Зарегистрированные предсказания:
#  (a) R(ядро - include-слой) - минимум среди реальных систем (известно 0.037);
#  (b) R(star - хаб) ~ 0 (чистая среда), R(clique - top5%) ~ 0.95 (чистая база);
#  (c) R(FX1910 - {GBR,FRA,DEU}) > R(FX1890 - те же) - утолщение обхода = эрозия;
#  (d) пространственные сети (rail, grid top5%) > авиация top5% (уязвимость
#      скейл-фри к целевой атаке) - честно неуверенное предсказание;
#  (e) метаболизм (-валюты) в средней зоне ~0.6-0.8.
import csv, json, re
import numpy as np, networkx as nx

rng = np.random.default_rng(42)
R = {}

def retention(G, rem):
    H = G.copy(); H.remove_nodes_from(rem)
    if H.number_of_nodes() == 0 or H.number_of_edges() == 0:
        return 0.0
    return len(max(nx.connected_components(H), key=len)) / G.number_of_nodes()

def topdeg(G, frac=0.05):
    k = max(1, int(round(frac * G.number_of_nodes())))
    return [v for v, _ in sorted(G.degree, key=lambda kv: -kv[1])[:k]]

# контроли
star = nx.star_graph(59); clique = nx.complete_graph(60)
ba = nx.barabasi_albert_graph(60, 2, seed=42)
gr8 = nx.convert_node_labels_to_integers(nx.grid_2d_graph(8, 8))
R['star_hub'] = retention(star, [0])
R['clique_top5'] = retention(clique, topdeg(clique))
R['BA_top5'] = retention(ba, topdeg(ba))
R['grid8_top5'] = retention(gr8, topdeg(gr8))

# метаболизм (импорт пересчитывает EXP-HUB-001 - детерминизм)
from exp_hub_001 import MET, cur_in_graph
GM = nx.Graph(MET)
R['metabolism_currency'] = retention(GM, [v for v in cur_in_graph if v in GM])
R['metabolism_top5'] = retention(GM, topdeg(GM))

# FX 1890/1910
rows = list(csv.DictReader(open('fj_data.txt'), delimiter='\t'))
for yr in ('1890', '1910'):
    q = 'quote' + yr
    Gx = nx.Graph()
    for r in rows:
        r = {k: v.strip('"') for k, v in r.items()}
        if r[q] == '1':
            Gx.add_edge(r['country_A'], r['country_B'])
    R['fx%s_hub3' % yr] = retention(Gx, ['GBR', 'FRA', 'DEU'])

# электросеть ACTIVSg2000
def read_block(path, name):
    m = re.search(r'mpc\.' + name + r'\s*=\s*\[(.*?)\];', open(path).read(), re.S)
    return np.array([[float(x) for x in l.split('%')[0].strip().rstrip(';').split()]
                     for l in m.group(1).strip().splitlines()
                     if l.split('%')[0].strip().rstrip(';')])
bus = read_block('case_ACTIVSg2000.m', 'bus')
br = read_block('case_ACTIVSg2000.m', 'branch')
GT = nx.Graph()
for row in br:
    if row[10] > 0: GT.add_edge(int(row[0]), int(row[1]))
GT = GT.subgraph(max(nx.connected_components(GT), key=len)).copy()
kvm = dict(zip(bus[:, 0].astype(int), bus[:, 9]))
R['grid_500kV'] = retention(GT, [v for v in GT if kvm[v] == 500.0])
R['grid_500_230'] = retention(GT, [v for v in GT if kvm[v] in (500.0, 230.0)])
R['grid_top5'] = retention(GT, topdeg(GT))

# авиация
country = {}
for row in csv.reader(open('airports.dat', encoding='utf-8', errors='replace')):
    if len(row) >= 12: country[row[0]] = row[3]
GA = nx.Graph()
for row in csv.reader(open('routes.dat', encoding='utf-8', errors='replace')):
    if len(row) >= 6 and row[3] in country and row[5] in country and row[3] != row[5]:
        GA.add_edge(row[3], row[5])
GA = GA.subgraph(max(nx.connected_components(GA), key=len)).copy()
R['aviation_top5'] = retention(GA, topdeg(GA))

# рельсы Индии
st = json.load(open('stations.json'))['features']
scodes = {f['properties'].get('code') for f in st if f['properties'].get('code')}
from collections import defaultdict
sc = json.load(open('schedules.json'))
bytrain = defaultdict(list)
def tkey(r):
    t = r.get('departure')
    if not t or t == 'None': t = r.get('arrival')
    if not t or t == 'None': t = '00:00:00'
    h, m, s = (list(map(int, t.split(':'))) + [0, 0])[:3]
    return ((r.get('day') or 1), h * 3600 + m * 60 + s)
for r in sc:
    if r.get('station_code') in scodes:
        bytrain[r['train_number']].append((tkey(r), r['station_code']))
GR = nx.Graph()
for tr, stops in bytrain.items():
    stops.sort(); seq = [s for _, s in stops]
    GR.add_edges_from((a, b) for a, b in zip(seq, seq[1:]) if a != b)
GR = GR.subgraph(max(nx.connected_components(GR), key=len)).copy()
R['rail_top5'] = retention(GR, topdeg(GR))

# ядро
E = np.load('kernel_graph.npz')['edges']
nodes_all = json.load(open('kernel_nodes.json'))
GK = nx.Graph(); GK.add_edges_from(map(tuple, E))
GK = GK.subgraph(max(nx.connected_components(GK), key=len)).copy()
hubk = [i for i in GK if nodes_all[i].startswith('include/') or '/include/' in nodes_all[i]]
R['kernel_include'] = retention(GK, hubk)
R['kernel_top5'] = retention(GK, topdeg(GK))

for k in sorted(R, key=R.get):
    print('%-24s R=%.3f' % (k, R[k]))
json.dump({k: float(v) for k, v in R.items()}, open('results_bound_001.json', 'w'), indent=1)
