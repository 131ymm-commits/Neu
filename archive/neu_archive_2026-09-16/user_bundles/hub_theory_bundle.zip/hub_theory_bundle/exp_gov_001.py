# EXP-GOV-001: анализ. Seed=42. Пререг: prereg_exp_gov_001.md
import json
import numpy as np, networkx as nx
from scipy import sparse

rng = np.random.default_rng(42)
E = np.load('gov_graph.npz')['edges']
nodes = [tuple(v) for v in json.load(open('gov_nodes.json'))]
jur = json.load(open('gov_jur.json'))

CODEX_ABBR = ['GG', 'BGB', 'StGB', 'StPO', 'ZPO', 'HGB', 'AO', 'VwVfG',
              'VwGO', 'EStG', 'UStG', 'InsO', 'SGB 1', 'SGB 5', 'SGB 10']
def norm(a): return a.replace(' ', '').replace('-', '').lower()
want = {norm(a) for a in CODEX_ABBR}
codex_slugs = {s for s, j in jur.items() if j and norm(j) in want}
print('кодексные слаги:', sorted(codex_slugs))

D = nx.DiGraph(); D.add_nodes_from(range(len(nodes)))
D.add_edges_from(map(tuple, E))
U = nx.Graph(D)
lcc = max(nx.connected_components(U), key=len)
print('LCC: %d из %d узлов (%.1f%%)' % (len(lcc), len(nodes), 100*len(lcc)/len(nodes)))
UL = U.subgraph(lcc).copy()
keep = sorted(UL.nodes())
paths = [nodes[i] for i in keep]
slug_of = np.array([p[0] for p in paths])
n = len(keep)

bt = nx.betweenness_centrality(UL, k=200, seed=42)
order = sorted(bt, key=bt.get, reverse=True)
top20 = order[:20]
in_codex = [nodes[i][0] in codex_slugs for i in top20]
share = np.mean(in_codex)
print('top-20 betweenness:')
for i in top20[:20]:
    print('   %-18s § %-6s bt=%.4f %s' % (nodes[i][0], nodes[i][1], bt[i],
          '[КОДЕКС]' if nodes[i][0] in codex_slugs else ''))
PG1 = share >= 0.6
print('P-G1: доля кодексов в top-20 = %.2f ->' % share, 'PASS' if PG1 else 'FAIL')

idx2 = {v: i for i, v in enumerate(keep)}
r = [idx2[a] for a, b in UL.edges()] + [idx2[b] for a, b in UL.edges()]
c = [idx2[b] for a, b in UL.edges()] + [idx2[a] for a, b in UL.edges()]
A = sparse.csr_matrix((np.ones(len(r), np.float32), (r, c)), shape=(n, n))
deg = np.asarray(A.sum(1)).ravel(); deg[deg == 0] = 1
P = sparse.diags((1/deg).astype(np.float32)) @ A
PL = (0.5*(sparse.identity(n, dtype=np.float32) + P)).tocsr()

from collections import Counter
cnt = Counter(slug_of)
big = {s for s, k in cnt.items() if k >= 30}
lab = np.array([s if s in big else 'OTHER' for s in slug_of])
def eps_mean(labels):
    classes = sorted(set(labels)); ci = {cc: j for j, cc in enumerate(classes)}
    li = np.array([ci[x] for x in labels])
    M = sparse.csr_matrix((np.ones(n, np.float32), (np.arange(n), li)),
                          shape=(n, len(classes)))
    Agg = np.asarray((P @ M).todense())
    tot = tw = 0.0
    for cc in classes:
        ids = np.where(labels == cc)[0]
        if len(ids) < 2: continue
        m = min(2000, len(ids)*(len(ids)-1)//2)
        a = rng.choice(ids, m); b = rng.choice(ids, m); ok = a != b
        if not ok.any(): continue
        d = 0.5*np.abs(Agg[a[ok]]-Agg[b[ok]]).sum(1).mean()
        tot += d*len(ids); tw += len(ids)
    return tot/tw
e_true = eps_mean(lab)
nulls = [eps_mean(rng.permutation(lab)) for _ in range(30)]
PG2 = e_true < min(nulls)
print('P-G2: eps=%.4f min(null)=%.4f ->' % (e_true, min(nulls)), 'PASS' if PG2 else 'FAIL')

pi = np.ones(n, np.float32)/n
for _ in range(2000):
    pi = np.asarray(pi @ PL).ravel(); pi /= pi.sum()
def tau_batch(F, tmax=300):
    F = F - (pi @ F); c0 = (pi[:, None]*F*F).sum(0)
    out = np.full(F.shape[1], float(tmax)); G = F.copy()
    alive = np.ones(F.shape[1], bool)
    for t in range(1, tmax+1):
        G = np.asarray(PL @ G); cc = (pi[:, None]*F*G).sum(0)
        cr = alive & (cc/np.maximum(c0, 1e-12) < np.exp(-1))
        out[cr] = t; alive &= ~cr
        if not alive.any(): break
    return out
laws_big = sorted(big)
Fl = np.stack([(slug_of == s).astype(np.float32) for s in laws_big], 1)
tl = tau_batch(Fl)
trd = tau_batch(rng.standard_normal((n, 50)).astype(np.float32))
ml, mr = np.median(tl), np.median(trd)
PG3 = ml >= 3*mr
print('P-G3: tau законов медиана %.1f (n=%d) vs случайные %.1f ->' %
      (ml, len(laws_big), mr), 'PASS' if PG3 else 'FAIL')

bgb_nodes = [i for i in keep if nodes[i][0] == 'bgb']
def secnum(x):
    try: return int(''.join(ch for ch in x if ch.isdigit()))
    except Exception: return 10**6
bgb_sorted = sorted(bgb_nodes, key=lambda i: -bt[i])[:30]
at_share_top = np.mean([secnum(nodes[i][1]) <= 240 for i in bgb_sorted])
at_share_all = np.mean([secnum(nodes[i][1]) <= 240 for i in bgb_nodes])
PG4 = at_share_top >= 2*at_share_all
print('P-G4: Allg. Teil в top-30 BGB %.2f vs база %.2f (x%.1f) ->' %
      (at_share_top, at_share_all, at_share_top/max(at_share_all, 1e-9)),
      'PASS' if PG4 else 'FAIL')

rem = [i for i in keep if nodes[i][0] in codex_slugs]
H = UL.copy(); H.remove_nodes_from(rem)
R = (len(max(nx.connected_components(H), key=len))/n) if H.number_of_edges() else 0.0
PG5 = R >= 0.3
print('P-G5: R после удаления кодексов = %.3f (удалено %d узлов) ->' %
      (R, len(rem)), 'PASS' if PG5 else 'FAIL')

ind = Counter()
for a, b in D.edges():
    ind[b] += 1
top_in = max((i for i in ind if i in idx2), key=lambda i: ind[i])
soft = nodes[top_in][0] in codex_slugs
print('max in-degree: %s § %s (in=%d) [кодекс: %s]' %
      (nodes[top_in][0], nodes[top_in][1], ind[top_in], soft))

json.dump(dict(n=n, lcc_share=len(lcc)/len(nodes), top20=[[nodes[i][0], nodes[i][1]] for i in top20],
               PG1=bool(PG1), share=float(share), eps=[float(e_true), float(min(nulls))],
               PG2=bool(PG2), tau=[float(ml), float(mr)], PG3=bool(PG3),
               PG4=bool(PG4), at=[float(at_share_top), float(at_share_all)],
               R=float(R), PG5=bool(PG5), soft_currency=bool(soft),
               top_in=[nodes[top_in][0], nodes[top_in][1], ind[top_in]]),
          open('results_gov_001.json', 'w'), indent=1, ensure_ascii=False)
