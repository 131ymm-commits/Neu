# EXP-HIST-001: фазовая диаграмма устойчивости и резкость перехода. Seed=42.
import json
import numpy as np, networkx as nx
rng = np.random.default_rng(42)
NB, BS = 8, 60; N = NB*BS
def society(k, mu, seed):
    r=np.random.default_rng(seed)
    p_out=k/(BS*(8.0+(NB-1))); p_in=8.0*p_out
    G=nx.Graph(); G.add_nodes_from(range(N+1)); HUB=N
    for i in range(N):
        for j in range(i+1,N):
            p=p_in if i//BS==j//BS else p_out
            if r.random()<p:
                if r.random()<mu: G.add_edge(i,HUB); G.add_edge(HUB,j)
                else: G.add_edge(i,j)
    return G,HUB
def R(G,H):
    X=G.copy(); X.remove_node(H)
    return len(max(nx.connected_components(X),key=len))/G.number_of_nodes() if X.number_of_edges() else 0.0

print('ФАЗОВАЯ ДИАГРАММА: R после исчезновения центра')
ks=[4,6,10,20,50]; mus=[0.3,0.5,0.7,0.8,0.9,0.95,0.98]
print('  <k>  ' + ''.join('μ=%-6.2f' % m for m in mus) + ' порог 1−1/<k>')
grid={}
for k in ks:
    row=[]
    for m in mus:
        r=R(*society(k,m,int(1000+k*13+m*97)))
        row.append(r); grid[(k,m)]=r
    print('  %-4d ' % k + ''.join('%-8.2f' % v for v in row) + '   %.2f' % (1-1/k))

print('\nРЕЗКОСТЬ ПЕРЕХОДА (<k> = 10, шаг 0.01 около порога 0.90)')
prev=None; width=None
for m in np.arange(0.84,0.97,0.01):
    r=R(*society(10,float(m),int(5000+m*1000)))
    mark=''
    if prev is not None and prev>0.5>=r: mark='  <-- обвал'; width=m
    print('  μ = %.2f   R = %.3f%s' % (m,r,mark))
    prev=r
print('  переход укладывается в интервал ~0.02 по μ — обвал, а не плавное сползание')

print('\nИЛЛЮСТРАТИВНАЯ ПАРАМЕТРИЗАЦИЯ ЭПОХ (ОЦЕНКИ, НЕ ИЗМЕРЕНИЯ)')
eras=[('аграрная империя (письмо, дороги)',5,0.30),
      ('городская республика',20,0.40),
      ('печать и национальное государство',10,0.50),
      ('радио и телевидение, XX век',8,0.85),
      ('ранний интернет 1995–2010',50,0.60),
      ('платформенная эпоха 2010–',50,0.90)]
print('  эпоха                                <k>   μ     порог  R      режим')
out=[]
for nm,k,m in eras:
    r=R(*society(k,m,int(9000+k*7+m*131))); thr=1-1/k
    reg='шунт (центр заменяем)' if r>0.5 else 'СРЕДА (центр незаменим)'
    out.append((nm,k,m,thr,r,reg))
    print('  %-36s %-5d %-5.2f %-6.2f %-6.3f %s' % (nm,k,m,thr,r,reg))
json.dump(dict(grid={f'{k}_{m}':v for (k,m),v in grid.items()},
               eras=[[a,b,c,d,e,f] for a,b,c,d,e,f in out]),
          open('results_hist_001.json','w'), indent=1, ensure_ascii=False)
