# EXP-REAL-001. Seed=42. Пререг: prereg_exp_real_001.md
import json, time
import numpy as np, torch, torch.nn as nn
rng = np.random.default_rng(42); torch.manual_seed(42)
CTX, V = 24, 81
def blk(size):
    P = np.zeros((V,V))
    for s in range(0,V,size): P[s:s+size, s:s+size] = 1.0/size
    return P
R0 = rng.dirichlet(np.ones(V), size=V)
T = 0.95*(0.45*blk(3)+0.25*blk(9)+0.20*blk(27)+0.10*blk(81)) + 0.05*R0
def sample(P,n,L):
    pi=np.ones(V)/V
    for _ in range(3000): pi=pi@P; pi/=pi.sum()
    cs=P.cumsum(1); x=np.zeros((n,L),int); x[:,0]=rng.choice(V,n,p=pi)
    for t in range(1,L):
        u=rng.random(n); x[:,t]=(cs[x[:,t-1]]<u[:,None]).sum(1)
    return x
tr, te = sample(T,2500,CTX+1), sample(T,300,CTX+1)
class Tiny(nn.Module):
    def __init__(s,D,NL):
        super().__init__(); s.NL=NL
        s.te=nn.Embedding(V,D); s.pe=nn.Embedding(CTX,D)
        s.at=nn.ModuleList([nn.MultiheadAttention(D,2,batch_first=True) for _ in range(NL)])
        s.ff=nn.ModuleList([nn.Sequential(nn.Linear(D,2*D),nn.GELU(),nn.Linear(2*D,D)) for _ in range(NL)])
        s.l1=nn.ModuleList([nn.LayerNorm(D) for _ in range(NL)])
        s.l2=nn.ModuleList([nn.LayerNorm(D) for _ in range(NL)])
        s.out=nn.Linear(D,V)
    def forward(s,x):
        L=x.shape[1]; h=s.te(x)+s.pe(torch.arange(L))[None]
        m=torch.triu(torch.ones(L,L,dtype=torch.bool),1)
        for i in range(s.NL):
            hn=s.l1[i](h); a,_=s.at[i](hn,hn,hn,attn_mask=m,need_weights=False)
            h=h+a; h=h+s.ff[i](s.l2[i](h))
        return s.out(h)
@torch.no_grad()
def gaps(m):
    x=torch.tensor(te); pr=torch.softmax(m(x[:,:-1]),-1).numpy()
    cur=te[:,:-1]; P=np.zeros((V,V)); c=np.zeros(V)
    for s in range(V):
        k=cur==s
        if k.sum(): P[s]=pr[k].sum(0); c[s]=k.sum()
    P=P/np.maximum(c[:,None],1)
    lam=np.sort(np.abs(np.linalg.eigvals(P)))[::-1]
    return {p: float(lam[p-1]/max(lam[p],1e-12)) for p in (3,9,27)}
def train(D,NL,steps,tag):
    t0=time.time(); m=Tiny(D,NL); opt=torch.optim.AdamW(m.parameters(),lr=2e-3); lf=nn.CrossEntropyLoss()
    for st in range(steps):
        idx=rng.integers(0,len(tr),48); xb=torch.tensor(tr[idx])
        loss=lf(m(xb[:,:-1]).reshape(-1,V),xb[:,1:].reshape(-1)); opt.zero_grad(); loss.backward(); opt.step()
    g=gaps(m); lv=sum(1 for p in (3,9,27) if g[p]>=1.3)
    npar=sum(p.numel() for p in m.parameters())
    print('  %-24s параметров %-7d CE %.3f  щели %s  ярусов %d  (%.0f с)'
          % (tag,npar,loss.item(),{k:round(v,2) for k,v in g.items()},lv,time.time()-t0))
    return lv,g,npar
print('удлинённое обучение (2500 шагов), цепь из 81 состояния, три настоящих яруса')
lv3,g3,_ = train(40,3,2500,'глубина 3, ширина 40')
lv1,g1,_ = train(112,1,2500,'глубина 1, ширина 112')
lv2,g2,_ = train(56,2,2500,'глубина 2, ширина 56')
PR1 = lv3>=3; PR2 = lv1<=1
print('\nP-R1 (глубина 3 → 3 яруса): %s (получено %d)' % ('PASS' if PR1 else 'FAIL', lv3))
print('P-R2 (глубина 1 → не больше 1): %s (получено %d)' % ('PASS' if PR2 else 'FAIL', lv1))
print('сводка: глубина 1 → %d, глубина 2 → %d, глубина 3 → %d ярусов' % (lv1,lv2,lv3))
# P-R3: шкала R по этажам (из наших отчётов)
Rvals = {'ядро Linux, include':0.037,'генетический код (оценка)':0.0,'звезда (контроль)':0.0,
         'право ФРГ, кодексы':0.695,'метаболизм, валюты':0.708,'культура, доноры':0.718,
         'валюты 1890':0.733,'сеть 500кВ':0.800,'stdlib Python':0.895,'рельсы top-5%':0.929}
v=np.array(sorted(Rvals.values())); env=v[v<0.1]; sh=v[v>0.6]
gap=sh.min()-env.max()
PR3 = len(env)>0 and len(sh)>0 and gap>=0.4 and not ((v>=0.1)&(v<=0.6)).any()
print('\nP-R3: значения R по этажам: среда %s | шунт %s | пустой промежуток %.3f -> %s'
      % (np.round(env,3).tolist(), np.round(sh,3).tolist(), gap, 'PASS' if PR3 else 'FAIL'))
json.dump(dict(lv=[lv1,lv2,lv3], gaps=[g1,g2,g3], PR1=bool(PR1), PR2=bool(PR2),
               gap=float(gap), PR3=bool(PR3)), open('results_real_001.json','w'), indent=1, default=float)
