# EXP-STR-002: достроить ландшафт монотоном. Seed=42. Пререг: prereg_exp_str_002.md
import json, itertools
import numpy as np

rng = np.random.default_rng(42)
L0 = 8.0

def landscape(J, seed):
    r = np.random.default_rng(seed)
    q = r.uniform(0.8, 1.2, J)
    R2 = 2*(L0 + 1.0)                      # держим Λ ≤ 1
    nmax = [int(np.floor(np.sqrt(R2)/qi)) for qi in q]
    states, lam = [], []
    for n in itertools.product(*[range(0, m+1) for m in nmax]):
        v = -L0 + 0.5*np.sum(np.array(n)**2 * q**2)
        if v <= 1.0:
            states.append(n); lam.append(v)
    return np.array(states), np.array(lam), q

# ---- P-M1: болезнь ----
S8, L8, _ = landscape(8, 42)
pos = L8 > 0
N_eps = int(((L8 > 0) & (L8 < 0.05)).sum())
print('J=8: всего вакуумов %d, из них Λ>0: %d | в окне 0<Λ<0.05: %d'
      % (len(L8), pos.sum(), N_eps))
PM1 = N_eps >= 100
print('P-M1 (нет предсказания без монотона):', 'PASS' if PM1 else 'FAIL')
for J in [4, 5, 6, 7, 8]:
    _, Lj, _ = landscape(J, 42)
    print('   J=%d: вакуумов %6d | в окне %4d' % (J, len(Lj), int(((Lj>0)&(Lj<0.05)).sum())))

# ---- P-M2: единственность argmin ----
uniq = 0
for s in range(200):
    _, Lj, _ = landscape(5, 1000+s)
    p = Lj[Lj > 0]
    if len(p) == 0: continue
    uniq += int((p == p.min()).sum() == 1)
frac = uniq/200
PM2 = frac >= 0.99
print('\nP-M2: глобальный argmin единствен в %.1f%% ландшафтов ->' % (100*frac),
      'PASS' if PM2 else 'FAIL')

# ---- P-M3/P-M4: достижимость ----
def descend(states, lam, starts=200, seed=0):
    r = np.random.default_rng(seed)
    idx = {tuple(s): i for i, s in enumerate(states)}
    J = states.shape[1]
    posidx = np.where(lam > 0)[0]
    if len(posidx) == 0: return None, None
    ends = []
    for _ in range(starts):
        i = posidx[r.integers(len(posidx))]
        for _ in range(500):
            n = states[i]; best, bl = i, lam[i]
            for k in range(J):
                for d in (-1, 1):
                    m = n.copy(); m[k] += d
                    if m[k] < 0: continue
                    j = idx.get(tuple(m))
                    if j is not None and 0 < lam[j] < bl:
                        best, bl = j, lam[j]
            if best == i: break
            i = best
        ends.append(i)
    return ends, posidx

ratios, shares = [], []
for s in range(30):
    st, lm, _ = landscape(6, 2000+s)
    ends, posidx = descend(st, lm, starts=150, seed=s)
    if ends is None: continue
    gmin = lm[posidx].min()
    lmin = np.median([lm[e] for e in ends])
    ratios.append(lmin/gmin)
    shares.append(len(set(ends))/len(posidx))
med_r, med_s = float(np.median(ratios)), float(np.median(shares))
PM3 = abs(med_r - 30) <= 25
PM4 = med_s <= 0.05
print('\nP-M3: медиана Λ_локальный/Λ_глобальный = %.1f | регистр. 30 ± 25 -> %s'
      % (med_r, 'ПОПАЛ' if PM3 else 'МИМО'))
print('P-M4: доля различных конечных точек = %.3f%% положительных вакуумов -> %s'
      % (100*med_s, 'PASS' if PM4 else 'FAIL'))
print('      сжатие ландшафта: в %.0f раз' % (1/med_s))
json.dump(dict(N_eps=N_eps, PM1=bool(PM1), frac_unique=frac, PM2=bool(PM2),
               med_ratio=med_r, PM3=bool(PM3), med_share=med_s, PM4=bool(PM4)),
          open('results_str_002.json','w'), indent=1, default=float)
