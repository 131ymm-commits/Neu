# EXP-HUB-008: M. tuberculosis iNJ661 + кросс-организменная лестница. Seed=42.
import json, re
import xml.etree.ElementTree as ET
import numpy as np, networkx as nx
from scipy.sparse.linalg import eigsh

T1B = ['h', 'h2o', 'atp', 'adp', 'amp', 'pi', 'ppi', 'nad', 'nadh', 'nadp',
       'nadph', 'co2', 'o2', 'nh4', 'fad', 'fadh2']
QUIN = re.compile(r'^(q\d+|q\d+h2|mqn\d+|mql\d+|2dmmq\d+|2dmmql\d+)$')
T2B = ['glu_dash_l', 'gln_dash_l', 'ser_dash_l', 'gly', 'thf', 'mlthf',
       '10fthf', '5mthf', 'amet', 'ahcys', 'coa', 'acp']
T3B = ['gtp', 'gdp', 'gmp', 'ctp', 'cdp', 'cmp', 'utp', 'udp', 'ump',
       'r5p', 'prpp']
CARB = ['pyr', 'accoa', 'oaa', 'akg']
GLYC = ['g6p', 'f6p', 'fdp', 'g3p', 'dhap', '13dpg', '3pg', '2pg', 'pep', 'pyr']

def base_comp(node):
    low = node.lower()
    i = low.rfind('_')
    return (low[:i], low[i:]) if i > 0 else (low, '')

def in_set(node, bases):
    b, _ = base_comp(node)
    return b in bases

def is_t1(node):
    b, _ = base_comp(node)
    return b in T1B or bool(QUIN.match(b))

def load_sbml(path):
    root = ET.fromstring(open(path, 'rb').read())
    ns = {'s': root.tag.split('}')[0].strip('{')}
    model = root.find('s:model', ns)
    mets = {sp.get('id') for sp in model.find('s:listOfSpecies', ns)
            if sp.get('boundaryCondition') != 'true'}
    G = nx.DiGraph()
    for rx in model.find('s:listOfReactions', ns):
        rid = (rx.get('id') or '').upper()
        if 'EX_' in rid or 'BIOMASS' in rid: continue
        rev = rx.get('reversible') == 'true'
        lr = rx.find('s:listOfReactants', ns); lp = rx.find('s:listOfProducts', ns)
        R = [x.get('species') for x in lr] if lr is not None else []
        P = [x.get('species') for x in lp] if lp is not None else []
        for a in R:
            for b in P:
                if a in mets and b in mets and a != b:
                    G.add_edge(a, b)
                    if rev: G.add_edge(b, a)
    return nx.relabel_nodes(G, {n: (n[2:] if n.startswith('M_') else n) for n in G.nodes()})

def crystal_fast(U):
    C = U.subgraph(max(nx.connected_components(U), key=len))
    if C.number_of_nodes() < 3: return None
    A = nx.to_scipy_sparse_array(C, dtype=float)
    try:
        ev = np.sort(eigsh(A, k=2, which='LA', return_eigenvectors=False,
                           maxiter=3000))[::-1]
    except Exception:
        ev = np.sort(np.linalg.eigvalsh(A.todense()))[::-1][:2]
    return float(ev[1] / ev[0]) if ev[0] > 0 else None

def tiers_of(G):
    t1 = [v for v in G if is_t1(v)]
    t2 = [v for v in G if in_set(v, set(T2B))]
    t3 = [v for v in G if in_set(v, set(T3B))]
    return t1, t2, t3

def rank_stage(G, quartet):
    b = nx.betweenness_centrality(G)
    order = [k for k, _ in sorted(b.items(), key=lambda kv: -kv[1])]
    r = {q: (order.index(q) + 1) for q in quartet if q in order}
    return r, order

def trajectory(G):
    t1, t2, t3 = tiers_of(G)
    quartet = [v for v in G if base_comp(v)[0] in CARB and base_comp(v)[1] == '_c']
    stages, meds, tops = [], [], []
    cur = G
    for rem in [[], t1, t2, t3]:
        if rem:
            cur = cur.copy(); cur.remove_nodes_from(rem)
            cur = cur.subgraph(max(nx.weakly_connected_components(cur), key=len)).copy()
        r, order = rank_stage(cur, quartet)
        stages.append(r); meds.append(float(np.median(list(r.values()))) if r else None)
        tops.append(order[:10])
    return meds, stages, tops, (t1, t2, t3)

# ---- iNJ661 ----
G = load_sbml('iNJ661.xml')
t1, t2, t3 = tiers_of(G)
comps = {}
for v in G:
    comps[base_comp(v)[1]] = comps.get(base_comp(v)[1], 0) + 1
print('узлов %d рёбер %d | ярусы: %d/%d/%d | компартменты: %s'
      % (G.number_of_nodes(), G.number_of_edges(), len(t1), len(t2), len(t3), comps))
meds, stages, tops, _ = trajectory(G)
print('P8.4 top-10 полного:', tops[0])
P84 = sum(1 for k in tops[0] if is_t1(k))
print('P8.4: ярус-1 в top-10 =', P84, '->', 'PASS' if P84 >= 6 else 'FAIL')
print('траектория медиан каркаса:', meds)
print('ранги по стадиям:', stages)
P81 = all(meds[i + 1] < meds[i] for i in range(3)) and meds[3] <= 10
print('P8.1:', 'PASS' if P81 else 'FAIL')
top3 = tops[3][:3]
P82 = sum(1 for k in top3 if base_comp(k)[0] in set(CARB) | set(GLYC))
print('top-3 после трёх ярусов:', top3, '| P8.2:', P82, '->',
      'PASS' if P82 >= 2 else 'FAIL')
Gu = nx.Graph(G); Gu.remove_nodes_from(t1)
R = len(max(nx.connected_components(Gu), key=len)) / G.number_of_nodes()
print('P8.5: retention = %.3f ->' % R, 'PASS' if R >= 0.5 else 'FAIL')

# детектор
Gd = nx.Graph(G); removed, prev, streak = [], crystal_fast(Gd), 0
for step in range(25):
    best, bestm = None, -2.0
    for v in list(Gd.nodes()):
        H = Gd.copy(); H.remove_node(v)
        if H.number_of_nodes() < 3 or H.number_of_edges() == 0: continue
        mm = crystal_fast(H)
        if mm is not None and mm > bestm: bestm, best = mm, v
    gain = bestm - prev
    Gd.remove_node(best); removed.append(best)
    streak = streak + 1 if gain < 0.01 else 0
    prev = bestm
    if streak >= 2:
        removed = removed[:-2] if len(removed) >= 2 else []
        break
GTn = set(t1) | set(t2) | set(t3)
prec = sum(1 for r in removed if r in GTn) / len(removed) if removed else 0
p1 = [i for i, r in enumerate(removed) if r in t1]
p2 = [i for i, r in enumerate(removed) if r in t2]
order_ok = (np.median(p1) < np.median(p2)) if (p1 and p2) else None
print('P8.3: точность %.2f (шагов %d) ->' % (prec, len(removed)),
      'PASS' if prec >= 0.70 else 'FAIL', '| порядок Я1<Я2:', order_ok)
print('удалено:', removed)

out = dict(organism='iNJ661', meds=meds, stages=stages, top10=tops[0],
           top3_final=top3, P81=bool(P81), P82=int(P82), P84=int(P84),
           R=float(R), detector=dict(removed=removed, prec=float(prec),
                                     order=(bool(order_ok) if order_ok is not None else None)))

# ---- кросс-организменная лестница (помеченное расширение) ----
ladder = {'iNJ661 (M.tb)': meds}
for name, path in [('iIT341 (H.pylori)', 'iIT341.xml'),
                   ('iAF692 (M.barkeri)', 'iAF692.xml'),
                   ('iND750 (дрожжи)', 'iND750.xml')]:
    Gx = load_sbml(path)
    m, _, _, _ = trajectory(Gx)
    ladder[name] = m
    print('лестница', name, m)
out['ladder'] = ladder
json.dump(out, open('results_hub_008.json', 'w'), indent=1, ensure_ascii=False)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(6.5, 4))
xs = ['полный', '−Я1', '−Я1−Я2', '−Я1−Я2−Я3']
for name, m in ladder.items():
    ax.plot(xs, m, 'o-', label=name)
ax.set_yscale('log'); ax.set_ylabel('медиана ранга каркаса (log)')
ax.axhline(10, color='gray', ls=':', lw=0.8)
ax.legend(fontsize=8); ax.set_title('Лестница ярусов: каркас поднимается при снятии валютных слоёв', fontsize=9)
plt.tight_layout(); plt.savefig('fig_tiers_ladder.png', dpi=150)
print('fig ok')
