# EXP-PRED-001: слепая числовая калибровка. Seed=42. Пререг: prereg_exp_pred_001.md
import ast, os, sys, json, sysconfig
import numpy as np, networkx as nx
from scipy import sparse
from collections import Counter

rng = np.random.default_rng(42)
IFACE = ['sys','os','types','typing','collections','abc','warnings','re',
         'functools','itertools','enum','dataclasses','io','time','contextlib']

def top_module(path, root):
    rel = os.path.relpath(path, root)
    parts = rel.replace('.py','').split(os.sep)
    if parts[-1] == '__init__': parts = parts[:-1]
    return parts

def scan(root, mode):
    """mode='top' — узлы = top-level модули; mode='sub' — узлы = полные пути подмодулей."""
    files = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in ('test','tests','__pycache__','site-packages','idlelib')] \
                if mode == 'top' else [d for d in dn if d != '__pycache__']
        for f in fn:
            if f.endswith('.py'): files.append(os.path.join(dp, f))
    names = {}
    for f in files:
        parts = top_module(f, root)
        if not parts: continue
        names[f] = parts[0] if mode == 'top' else '.'.join(parts)
    universe = set(names.values())
    tops = {n.split('.')[0] for n in universe}
    G = nx.DiGraph()
    for f, src_name in names.items():
        try:
            tree = ast.parse(open(f, encoding='utf-8', errors='replace').read())
        except Exception:
            continue
        for node in ast.walk(tree):
            targets = []
            if isinstance(node, ast.Import):
                targets = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                if node.level and node.level > 0 and mode == 'sub':
                    base = src_name.split('.')[:-node.level] if node.level <= len(src_name.split('.')) else []
                    targets = ['.'.join(base + ([node.module] if node.module else []))]
                elif node.module:
                    targets = [node.module]
            for t in targets:
                if not t: continue
                if mode == 'top':
                    tgt = t.split('.')[0]
                    if tgt in universe and tgt != src_name: G.add_edge(src_name, tgt)
                else:
                    cand = t
                    while cand and cand not in universe:
                        cand = cand.rsplit('.', 1)[0] if '.' in cand else ''
                    if cand and cand != src_name and cand.split('.')[0] in tops:
                        G.add_edge(src_name, cand)
    return G

def crystal(U):
    C = U.subgraph(max(nx.connected_components(U), key=len))
    if C.number_of_nodes() < 3: return None
    A = nx.to_scipy_sparse_array(C, dtype=float)
    from scipy.sparse.linalg import eigsh
    try:
        ev = np.sort(eigsh(A, k=2, which='LA', return_eigenvectors=False, maxiter=3000))[::-1]
    except Exception:
        ev = np.sort(np.linalg.eigvalsh(A.todense()))[::-1][:2]
    return float(ev[1]/ev[0]) if ev[0] > 0 else None

def retention(U, rem):
    H = U.copy(); H.remove_nodes_from(rem)
    if H.number_of_edges() == 0: return 0.0
    return len(max(nx.connected_components(H), key=len))/U.number_of_nodes()

def topdeg(U, frac=0.05):
    k = max(1, int(round(frac*U.number_of_nodes())))
    return [v for v, _ in sorted(U.degree, key=lambda kv: -kv[1])[:k]]

RES = {}
# ---------- СИСТЕМА A ----------
stdroot = sysconfig.get_paths()['stdlib']
GA = scan(stdroot, 'top')
UA = nx.Graph(GA)
UA = UA.subgraph(max(nx.connected_components(UA), key=len)).copy()
print('A: модулей %d, рёбер %d (LCC %d)' % (GA.number_of_nodes(), GA.number_of_edges(), UA.number_of_nodes()))
ind = Counter()
for a, b in GA.edges(): ind[b] += 1
top5in = [m for m, _ in ind.most_common(5)]
A1 = sum(1 for m in top5in if m in IFACE) >= 3
print('A1: top-5 по in-degree:', top5in, '->', 'PASS' if A1 else 'FAIL')
iface_present = [m for m in IFACE if m in UA]
A2v = retention(UA, iface_present)
A3v = retention(UA, topdeg(UA))
m1_before = crystal(UA)
Ua = UA.copy(); Ua.remove_nodes_from(iface_present)
m1_after = crystal(Ua)
A4 = (m1_after is not None and m1_before is not None and m1_after > m1_before)
bt = nx.betweenness_centrality(UA, k=min(300, UA.number_of_nodes()), seed=42)
top20 = [v for v, _ in sorted(bt.items(), key=lambda kv: -kv[1])[:20]]
A5v = np.mean([v in IFACE for v in top20])
print('A2: R(интерфейс) = %.3f | A3: R(top5%%) = %.3f | A4: M1 %.3f -> %.3f (%s) | A5: доля = %.2f'
      % (A2v, A3v, m1_before, m1_after, 'PASS' if A4 else 'FAIL', A5v))
print('    top-20 btw:', top20[:10])

# ---------- СИСТЕМА B ----------
sp = [p for p in sys.path if p.endswith('site-packages') and os.path.isdir(p)]
sp = sp[0] if sp else '/usr/lib/python3/dist-packages'
GB = scan(sp, 'sub')
UB = nx.Graph(GB)
UB = UB.subgraph(max(nx.connected_components(UB), key=len)).copy()
nodes = sorted(UB.nodes()); idx = {v: i for i, v in enumerate(nodes)}; n = len(nodes)
pkg = np.array([v.split('.')[0] for v in nodes])
cnt = Counter(pkg); big = {p for p, k in cnt.items() if k >= 30}
print('B: подмодулей %d, рёбер %d (LCC %d) | пакетов >=30: %d — %s'
      % (GB.number_of_nodes(), GB.number_of_edges(), n, len(big), sorted(big)[:8]))
lab = np.array([p if p in big else 'OTHER' for p in pkg])
r = [idx[a] for a, b in UB.edges()] + [idx[b] for a, b in UB.edges()]
c = [idx[b] for a, b in UB.edges()] + [idx[a] for a, b in UB.edges()]
A = sparse.csr_matrix((np.ones(len(r), np.float32), (r, c)), shape=(n, n))
deg = np.asarray(A.sum(1)).ravel(); deg[deg == 0] = 1
P = sparse.diags((1/deg).astype(np.float32)) @ A
def eps(labels):
    cls = sorted(set(labels)); ci = {x: j for j, x in enumerate(cls)}
    li = np.array([ci[x] for x in labels])
    M = sparse.csr_matrix((np.ones(n, np.float32), (np.arange(n), li)), shape=(n, len(cls)))
    Agg = np.asarray((P @ M).todense()); tot = tw = 0.0
    for x in cls:
        ids = np.where(labels == x)[0]
        if len(ids) < 2: continue
        m = min(2000, len(ids)*(len(ids)-1)//2)
        a = rng.choice(ids, m); b = rng.choice(ids, m); ok = a != b
        if not ok.any(): continue
        tot += 0.5*np.abs(Agg[a[ok]]-Agg[b[ok]]).sum(1).mean()*len(ids); tw += len(ids)
    return tot/tw
B2v = eps(lab)
nulls = np.array([eps(rng.permutation(lab)) for _ in range(30)])
Dv = (B2v - nulls.mean())/nulls.std()
B1 = Dv < -20
print('B1: eps=%.4f null=%.4f±%.4f D=%.1f ->' % (B2v, nulls.mean(), nulls.std(), Dv),
      'PASS' if B1 else 'FAIL')
PL = (0.5*(sparse.identity(n, dtype=np.float32) + P)).tocsr()
pi = np.ones(n, np.float32)/n
for _ in range(2000):
    pi = np.asarray(pi @ PL).ravel(); pi /= pi.sum()
def tau_batch(F, tmax=300):
    F = F - (pi @ F); c0 = (pi[:, None]*F*F).sum(0)
    out = np.full(F.shape[1], float(tmax)); G2 = F.copy(); alive = np.ones(F.shape[1], bool)
    for t in range(1, tmax+1):
        G2 = np.asarray(PL @ G2); cc = (pi[:, None]*F*G2).sum(0)
        cr = alive & (cc/np.maximum(c0, 1e-12) < np.exp(-1)); out[cr] = t; alive &= ~cr
        if not alive.any(): break
    return out
bigs = sorted(big)
tp = tau_batch(np.stack([(pkg == p).astype(np.float32) for p in bigs], 1))
tr = tau_batch(rng.standard_normal((n, 50)).astype(np.float32))
B3v, mr = float(np.median(tp)), float(np.median(tr))
B4 = B3v >= 3*mr
B5v = retention(UB, topdeg(UB))
print('B3: медиана τ пакетов = %.1f (случайные %.1f) | B4 %s | B5: R(top5%%) = %.3f'
      % (B3v, mr, 'PASS' if B4 else 'FAIL', B5v))

# ---------- СЧЁТ ----------
num = [('A2', A2v, 0.55, 0.20), ('A3', A3v, 0.72, 0.15), ('A5', float(A5v), 0.50, 0.25),
       ('B2', float(B2v), 0.20, 0.15), ('B3', B3v, 40.0, 35.0), ('B5', B5v, 0.80, 0.15)]
hits = []
print('\n=== ЧИСЛОВЫЕ (точка ± интервал) ===')
for nm, val, pt, w in num:
    ok = abs(val - pt) <= w
    hits.append(ok)
    print('  %s: предсказано %.2f ± %.2f → [%.2f, %.2f] | факт %.3f | %s'
          % (nm, pt, w, pt-w, pt+w, val, 'ПОПАЛ' if ok else 'МИМО'))
dirs = [('A1', A1), ('A4', A4), ('B1', B1), ('B4', B4)]
print('=== НАПРАВЛЕННЫЕ ===')
for nm, ok in dirs: print('  %s: %s' % (nm, 'PASS' if ok else 'FAIL'))
hit_rate = sum(hits)/len(hits); dir_rate = sum(ok for _, ok in dirs)/len(dirs)
M1ok = abs(hit_rate - 0.50) <= 0.25
M2ok = dir_rate == 1.0
print('\n=== МЕТА-ПРЕДСКАЗАНИЕ (самокалибровка) ===')
print('  интервалы: %d/6 = %.2f | предсказано 0.50 ± 0.25 → %s' % (sum(hits), hit_rate, 'ПОПАЛ' if M1ok else 'МИМО'))
print('  направленные: %d/4 = %.2f | предсказано 1.00 → %s' % (sum(ok for _, ok in dirs), dir_rate, 'ПОПАЛ' if M2ok else 'МИМО'))
print('  kill (направленных < 3/4):', 'FIRED' if sum(ok for _, ok in dirs) < 3 else 'no')
json.dump(dict(A=dict(n=GA.number_of_nodes(), m=GA.number_of_edges(), top5in=top5in,
                      A1=bool(A1), A2=A2v, A3=A3v, m1=[m1_before, m1_after], A4=bool(A4),
                      A5=float(A5v), top20=top20),
               B=dict(n=GB.number_of_nodes(), m=GB.number_of_edges(), pkgs=sorted(big),
                      eps=float(B2v), D=float(Dv), B1=bool(B1), tau=[B3v, mr], B4=bool(B4), B5=B5v),
               numeric=[[nm, val, pt, w, bool(h)] for (nm, val, pt, w), h in zip(num, hits)],
               directional=[[nm, bool(ok)] for nm, ok in dirs],
               hit_rate=hit_rate, dir_rate=dir_rate, M1=bool(M1ok), M2=bool(M2ok)),
          open('results_pred_001.json', 'w'), indent=1, default=float)
