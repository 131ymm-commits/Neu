# EXP-AA-001: структурная причина порядка рекрутирования. Seed=42.
import json, re
import xml.etree.ElementTree as ET
import numpy as np, networkx as nx
from scipy.stats import mannwhitneyu, spearmanr, pointbiserialr

T1B = ['h','h2o','atp','adp','amp','pi','ppi','nad','nadh','nadp','nadph',
       'co2','o2','nh4','fad','fadh2']
QUIN = re.compile(r'^(q\d+|q\d+h2|mqn\d+|mql\d+|2dmmq\d+|2dmmql\d+)$')
SCAFFOLD = ['g6p','f6p','r5p','e4p','g3p','3pg','pep','pyr','accoa','akg','succoa','oaa']
AA = {'gly':'Gly','ala_DASH_L':'Ala','asp_DASH_L':'Asp','glu_DASH_L':'Glu',
      'val_DASH_L':'Val','ser_DASH_L':'Ser','ile_DASH_L':'Ile','leu_DASH_L':'Leu',
      'pro_DASH_L':'Pro','thr_DASH_L':'Thr','arg_DASH_L':'Arg','asn_DASH_L':'Asn',
      'lys_DASH_L':'Lys','gln_DASH_L':'Gln','cys_DASH_L':'Cys','his_DASH_L':'His',
      'phe_DASH_L':'Phe','met_DASH_L':'Met','tyr_DASH_L':'Tyr','trp_DASH_L':'Trp'}
PREBIOTIC = {'Gly','Ala','Asp','Glu','Val','Ser','Ile','Leu','Pro','Thr'}
TRIFONOV = {'Gly':1.5,'Ala':1.5,'Val':3.5,'Asp':3.5,'Pro':5,'Ser':6,'Glu':7.5,
            'Leu':7.5,'Thr':9,'Arg':10,'Asn':11,'Lys':12,'Gln':13,'Ile':14,
            'Cys':15,'His':16,'Phe':17,'Met':18,'Tyr':19,'Trp':20}

def base(node):
    low = node.lower(); i = low.rfind('_')
    return low[:i] if i > 0 else low
def is_t1(node):
    b = base(node)
    return b in T1B or bool(QUIN.match(b))

def load(path):
    root = ET.fromstring(open(path,'rb').read())
    ns = {'s': root.tag.split('}')[0].strip('{')}
    fbc = 'http://www.sbml.org/sbml/level3/version1/fbc/version2'
    model = root.find('s:model', ns)
    mets, formula = set(), {}
    for sp in model.find('s:listOfSpecies', ns):
        if sp.get('boundaryCondition') == 'true': continue
        sid = sp.get('id'); mets.add(sid)
        f = sp.get('{%s}chemicalFormula' % fbc)
        if f: formula[sid[2:] if sid.startswith('M_') else sid] = f
    G = nx.DiGraph()
    for rx in model.find('s:listOfReactions', ns):
        rid = (rx.get('id') or '').upper()
        if 'EX_' in rid or 'BIOMASS' in rid: continue
        rev = rx.get('reversible') == 'true'
        lr = rx.find('s:listOfReactants', ns); lp = rx.find('s:listOfProducts', ns)
        R = [x.get('species') for x in lr] if lr is not None else []
        P = [x.get('species') for x in lp] if lp is not None else []
        for a in R:
            for b in P:
                if a in mets and b in mets and a != b:
                    G.add_edge(a,b)
                    if rev: G.add_edge(b,a)
    G = nx.relabel_nodes(G, {n:(n[2:] if n.startswith('M_') else n) for n in G.nodes()})
    return G, formula

def carbons(f):
    if not f: return None
    m = re.match(r'^C(\d*)', f)
    return (int(m.group(1)) if m.group(1) else 1) if m else 0

ROWS, PER = [], {}
for name, path in [('iIT341','iIT341.xml'), ('iAF692','iAF692.xml'),
                   ('iND750','iND750.xml'), ('iNJ661','iNJ661.xml')]:
    G, formula = load(path)
    H = G.copy(); H.remove_nodes_from([v for v in G if is_t1(v)])
    src = [v for v in H if base(v) in SCAFFOLD and v.endswith('_c')]
    # мультиисточниковый BFS
    S = nx.DiGraph(); S.add_nodes_from(H.nodes()); S.add_edges_from(H.edges())
    S.add_node('__SRC__')
    for s in src: S.add_edge('__SRC__', s)
    dist = nx.single_source_shortest_path_length(S, '__SRC__')
    bt = nx.betweenness_centrality(H, k=min(300, H.number_of_nodes()), seed=42)
    order = sorted(bt, key=bt.get, reverse=True)
    brank = {v: i+1 for i, v in enumerate(order)}
    rows = []
    for key, nm in AA.items():
        node = key + '_c'
        if node not in H: continue
        d = dist.get(node)
        if d is None: continue
        rows.append(dict(org=name, aa=nm, d=d-1, pre=int(nm in PREBIOTIC),
                         trif=TRIFONOV[nm], brank=brank.get(node, len(order)),
                         C=carbons(formula.get(node))))
    PER[name] = rows; ROWS += rows
    dpre = [r['d'] for r in rows if r['pre']]; dlat = [r['d'] for r in rows if not r['pre']]
    rho, p = spearmanr([r['d'] for r in rows], [r['trif'] for r in rows])
    bpre = np.median([r['brank'] for r in rows if r['pre']])
    blat = np.median([r['brank'] for r in rows if not r['pre']])
    print('%-8s n=%2d | медиана d: пребио %.1f поздние %.1f | Спирмен(d,Трифонов)=%+.3f p=%.3f | btw-ранг: пребио %.0f поздние %.0f'
          % (name, len(rows), np.median(dpre), np.median(dlat), rho, p, bpre, blat))

# P-A1
ok1 = sum(1 for nm in PER if np.median([r['d'] for r in PER[nm] if r['pre']])
          < np.median([r['d'] for r in PER[nm] if not r['pre']]))
allpre = [r['d'] for r in ROWS if r['pre']]; alllat = [r['d'] for r in ROWS if not r['pre']]
U, p1 = mannwhitneyu(allpre, alllat, alternative='two-sided')
PA1 = ok1 >= 3 and p1 < 0.01
print('\nP-A1: направление в %d/4 организмах; объединённый Манн–Уитни p=%.2e ->' % (ok1, p1),
      'PASS' if PA1 else 'FAIL')
# P-A2
ok2 = 0
for nm in PER:
    rho, p = spearmanr([r['d'] for r in PER[nm]], [r['trif'] for r in PER[nm]])
    ok2 += (rho > 0 and p < 0.05)
PA2 = ok2 >= 3
print('P-A2: Спирмен>0 при p<0.05 в %d/4 ->' % ok2, 'PASS' if PA2 else 'FAIL')
# P-A3: контроль числа углеродов
d = np.array([r['d'] for r in ROWS], float)
pre = np.array([r['pre'] for r in ROWS], float)
C = np.array([r['C'] if r['C'] else np.nan for r in ROWS], float)
m = ~np.isnan(C)
rb, pb = pointbiserialr(pre[m], d[m])
# частная корреляция d~pre при контроле C
def resid(y, x):
    A = np.vstack([x, np.ones(len(x))]).T
    return y - A @ np.linalg.lstsq(A, y, rcond=None)[0]
rp, pp = spearmanr(resid(d[m], C[m]), resid(pre[m], C[m]))
print('P-A3: сырая связь d~пребиотичность r=%+.3f p=%.1e | частная при контроле C: rho=%+.3f p=%.1e ->'
      % (rb, pb, rp, pp), 'PASS' if pp < 0.05 else 'FAIL')
print('  связь числа углеродов с пребиотичностью: r=%+.3f | C с d: rho=%+.3f'
      % (pointbiserialr(pre[m], C[m])[0], spearmanr(C[m], d[m])[0]))
PA3 = pp < 0.05
# P-A4
ok4 = sum(1 for nm in PER if np.median([r['brank'] for r in PER[nm] if r['pre']])
          < np.median([r['brank'] for r in PER[nm] if not r['pre']]))
PA4 = ok4 >= 3
print('P-A4: центральность пребиотических выше в %d/4 ->' % ok4, 'PASS' if PA4 else 'FAIL')
kill = ok1 <= 1
print('kill:', 'FIRED' if kill else 'no')

# профиль по аминокислотам (усреднение по организмам)
prof = {}
for r in ROWS: prof.setdefault(r['aa'], []).append(r['d'])
print('\nсредняя структурная глубина по аминокислотам (эталон Трифонова в скобках):')
for aa, v in sorted(prof.items(), key=lambda kv: np.mean(kv[1])):
    print('  %-4s d=%.2f  (%.1f)%s' % (aa, np.mean(v), TRIFONOV[aa], '  [пребио]' if aa in PREBIOTIC else ''))

json.dump(dict(rows=ROWS, PA1=bool(PA1), PA2=bool(PA2), PA3=bool(PA3), PA4=bool(PA4),
               ok=[ok1, ok2, int(PA3), ok4], p_mwu=float(p1),
               partial=[float(rp), float(pp)], raw=[float(rb), float(pb)],
               kill=bool(kill)),
          open("results_aa_001.json","w"), indent=1, ensure_ascii=False, default=float)
