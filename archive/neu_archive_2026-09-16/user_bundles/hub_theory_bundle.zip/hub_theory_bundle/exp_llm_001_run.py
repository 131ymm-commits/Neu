import sys, time, json
src = open('/home/claude/exp_hub_001/exp_llm_001.py').read().split("print('ЧАСТЬ A")[0]
exec(src)
# ЧАСТЬ A с плотными ранними точками
T = chain(27, [(3,0.55),(9,0.30),(27,0.15)])
tr = sample(T, 1500, CTX+1, 27); te = sample(T, 200, CTX+1, 27)
m = Tiny(27, 48, 2); opt = torch.optim.AdamW(m.parameters(), lr=2e-3); lf = nn.CrossEntropyLoss()
hist = []
for st in range(400):
    idx = rng.integers(0, len(tr), 48); xb = torch.tensor(tr[idx])
    loss = lf(m(xb[:, :-1]).reshape(-1, 27), xb[:, 1:].reshape(-1))
    opt.zero_grad(); loss.backward(); opt.step()
    if st < 60 or st % 10 == 0:
        g = gaps(kernel(m, te, 27), [3, 9])
        hist.append((st+1, float(loss.item()), g))
def acq(h, p, thr=1.3):
    for st,_,g in h:
        if g[p] >= thr: return st
    return None
t3, t9 = acq(hist,3), acq(hist,9)
print('A: щель@3 (грубый) приобретена на шаге %s | щель@9 (мелкий) на шаге %s' % (t3,t9))
print('  ранняя динамика:')
for st,ls,g in hist[:24]:
    print('   шаг %-4d loss %.3f  щель@3 %.3f  щель@9 %.3f' % (st,ls,g[3],g[9]))
json.dump(dict(t3=t3,t9=t9,hist=[(s,l,{str(k):v for k,v in g.items()}) for s,l,g in hist]),
          open('/home/claude/exp_hub_001/results_llm_A.json','w'), default=float)
# ЧАСТЬ B
print('\nB: глубина против ширины, 81 состояние, щели 3/9/27')
W = [(3,0.45),(9,0.25),(27,0.20),(81,0.10)]
res = {}
for tag, D, NL in [('глубина1_ширина96',96,1), ('глубина2_ширина56',56,2), ('глубина3_ширина40',40,3)]:
    t0=time.time()
    h, npar = run(81, W, D, NL, 800, [3,9,27], tag, ckpt=200)
    lv = sum(1 for p in (3,9,27) if h[-1][2][p] >= 1.3)
    res[tag] = dict(levels=lv, params=npar, gaps={str(k):v for k,v in h[-1][2].items()})
    print('    уровней приобретено: %d из 3 (%.0f с)' % (lv, time.time()-t0))
json.dump(res, open('/home/claude/exp_hub_001/results_llm_B.json','w'), default=float)
