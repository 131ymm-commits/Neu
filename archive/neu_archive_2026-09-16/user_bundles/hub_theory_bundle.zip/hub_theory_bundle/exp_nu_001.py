# EXP-NU-001. Пререг: prereg_exp_nu_001.md
import json
import numpy as np
from scipy.optimize import brentq

dm21, dm31 = 7.5e-5, 2.5e-3           # эВ²
s12, s13 = 0.307, 0.022
Ue1 = (1-s12)*(1-s13); Ue2 = s12*(1-s13); Ue3 = s13

# P-N1: длины осцилляций
LE = lambda dm2: (np.pi/2)/(1.267*dm2)
le_atm, le_sol = LE(dm31), LE(dm21)
PN1 = abs(le_atm-496) <= 50 and abs(le_sol-16500) <= 2000
print('P-N1: L/E атмосферное %.0f км/ГэВ (регистр. 496 ± 50), солнечное %.0f (16500 ± 2000) -> %s'
      % (le_atm, le_sol, 'ПОПАЛ' if PN1 else 'МИМО'))

# орбита масс: один свободный параметр
def masses_NO(m1): return np.array([m1, np.sqrt(m1**2+dm21), np.sqrt(m1**2+dm31)])
def masses_IO(m3): return np.array([np.sqrt(m3**2+dm31-dm21), np.sqrt(m3**2+dm31), m3])
sum_NO = lambda m1: masses_NO(m1).sum()
sum_IO = lambda m3: masses_IO(m3).sum()
mn_NO, mn_IO = sum_NO(0.0), sum_IO(0.0)
PN2 = abs(mn_NO-0.0587) <= 0.002 and abs(mn_IO-0.0985) <= 0.005
print('P-N2: минимум Σm — нормальный порядок %.4f эВ, обратный %.4f эВ -> %s'
      % (mn_NO, mn_IO, 'ПОПАЛ' if PN2 else 'МИМО'))

# P-N3: где космологический якорь режет орбиту
def cut(sumf, bound):
    if sumf(0.0) >= bound: return 0.0
    return brentq(lambda m: sumf(m)-bound, 0, 1.0)
print('\nгде якорь режет орбиту (верхняя граница на легчайшую массу):')
rows = []
for name, b in [('DESI 0.064', 0.064), ('иерарх. приор 0.092', 0.092),
                ('консерв. 0.12', 0.12), ('CPL 0.111', 0.111)]:
    c1 = cut(sum_NO, b); c3 = cut(sum_IO, b)
    rows.append((name, b, c1*1e3, c3*1e3))
    print('  Σm < %-22s → m_лёгк < %6.2f мэВ (норм.) | %6.2f мэВ (обратн.)'
          % (name, c1*1e3, c3*1e3))
m1_desi = cut(sum_NO, 0.064)*1e3
PN3 = abs(m1_desi - 5) <= 3
print('P-N3: при DESI m₁ < %.2f мэВ | регистр. 5 ± 3 -> %s' % (m1_desi, 'ПОПАЛ' if PN3 else 'МИМО'))

# эффективные массы вдоль орбиты
print('\nэффективные наблюдаемые вдоль орбиты (нормальный порядок):')
print('  m₁, мэВ   Σm, эВ    m_β, мэВ   (KATRIN предел 450 мэВ)')
for m1 in [0, 2, 5, 10, 20, 50]:
    m = masses_NO(m1*1e-3)
    mb = np.sqrt(Ue1*m[0]**2 + Ue2*m[1]**2 + Ue3*m[2]**2)*1e3
    print('  %-9.0f %-9.4f %-10.2f' % (m1, m.sum(), mb))
m = masses_NO(0.0)
mb0 = np.sqrt(Ue1*m[0]**2 + Ue2*m[1]**2 + Ue3*m[2]**2)*1e3
print('  вывод: в минимуме орбиты m_β = %.2f мэВ — в %.0f раз ниже предела KATRIN' % (mb0, 450/mb0))

# P-N4: лестница СМ
print('\nP-N4: лестница K_τ Стандартной модели (ранг решётки точных зарядов):')
lad = [('сильные и ЭМ, τ < 10⁻¹⁵ с', 8, '{Q,B,Le,Lμ,Lτ,S,C,B′}', 'ИЗМЕРЕНО (PHYS-001)'),
       ('слабые распады, лаб. времена', 5, '{Q,B,Le,Lμ,Lτ}', 'ИЗМЕРЕНО (PHYS-001)'),
       ('осцилляционные базы L/E > %.0f км/ГэВ' % le_atm, 3, '{Q,B,L}', 'вычислено здесь'),
       ('выше электрослабого перехода, T > 100 ГэВ', 2, '{Q,B−L}', 'из литературы')]
for s, r, w, src in lad:
    print('  ранг %d  %-42s %-22s %s' % (r, s, w, src))
print('  диапазон масштабов ступеней: от 10⁻¹⁵ с до космологических баз — свыше 30 порядков')

json.dump(dict(le_atm=le_atm, le_sol=le_sol, PN1=bool(PN1),
               min_NO=mn_NO, min_IO=mn_IO, PN2=bool(PN2),
               cuts=rows, m1_desi=m1_desi, PN3=bool(PN3),
               mbeta_min=mb0, ladder=[[s,r,w] for s,r,w,_ in lad]),
          open('results_nu_001.json','w'), indent=1, ensure_ascii=False)
