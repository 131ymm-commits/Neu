# EXP-ISO-001: разрешающая способность. Пререг: prereg_exp_iso_001.md
import json
import numpy as np, networkx as nx
from networkx.generators.atlas import graph_atlas_g
from collections import Counter

Gs = [g for g in graph_atlas_g() if g.number_of_nodes() == 7 and nx.is_connected(g)]
print('связных графов на 7 вершинах: %d' % len(Gs))

def spec_adj(G):
    return tuple(np.round(np.sort(np.linalg.eigvalsh(nx.to_numpy_array(G))), 6))
def spec_lap(G):
    return tuple(np.round(np.sort(np.linalg.eigvalsh(nx.laplacian_matrix(G).todense())), 6))
def triple(G):
    A = nx.to_numpy_array(G)
    ev = np.sort(np.abs(np.linalg.eigvalsh(A)))[::-1]
    m1 = ev[1]/ev[0]
    w, V = np.linalg.eigh(A)
    p = np.abs(V[:, -1]); p = p/p.sum()
    neff = np.exp(-(p*np.log(np.maximum(p, 1e-15))).sum())/len(p)
    bt = nx.betweenness_centrality(G); s = sum(bt.values())
    top = max(bt.values())/s if s > 0 else 0.0
    return tuple(np.round([m1, neff, top], 4))

def unresolved(keys):
    c = Counter(keys)
    return sum(v for v in c.values() if v >= 2)/len(keys), sum(1 for v in c.values() if v >= 2)

ka = [spec_adj(g) for g in Gs]
kl = [spec_lap(g) for g in Gs]
kt = [triple(g) for g in Gs]
kb = [a+b for a, b in zip(ka, kl)]
fa, ga = unresolved(ka)
fl, gl = unresolved(kl)
ft, gt = unresolved(kt)
fb, gb = unresolved(kb)
print('\nдоля НЕРАЗЛИЧЁННЫХ графов:')
print('  спектр смежности      %.1f%%  (групп-двойников %d)' % (100*fa, ga))
print('  спектр Лапласа        %.1f%%  (групп %d)' % (100*fl, gl))
print('  наша тройка           %.1f%%  (групп %d)' % (100*ft, gt))
print('  смежность + Лаплас    %.1f%%  (групп %d)' % (100*fb, gb))
PI1 = abs(100*fa - 10) <= 6
PI2 = abs(100*ft - 25) <= 20 and ft > fa
PI3 = fb < fa
print('\nP-I1 (спектр смежности в 10%% ± 6%%):', 'ПОПАЛ' if PI1 else 'МИМО')
print('P-I2 (тройка слепее, 25%% ± 20%%):', 'PASS' if PI2 else 'FAIL',
      '| отношение слепоты: %.1f×' % (ft/fa if fa > 0 else float('inf')))
print('P-I3 (объединение операторов помогает):', 'PASS' if PI3 else 'FAIL')

# сколько информации даёт каждый оператор поверх другого
print('\nдополняемость: пар, различённых ТОЛЬКО Лапласом (при равном спектре смежности):')
pairs_adj_same = Counter(ka)
extra = 0
for key, cnt in pairs_adj_same.items():
    if cnt < 2: continue
    idx = [i for i, k in enumerate(ka) if k == key]
    subs = Counter(kl[i] for i in idx)
    extra += cnt - max(subs.values())
print('  %d графов из %d коспектральных по смежности разводятся Лапласом' % (extra, ga and int(100*fa*len(Gs)/100)))
json.dump(dict(n=len(Gs), f_adj=fa, f_lap=fl, f_triple=ft, f_both=fb,
               PI1=bool(PI1), PI2=bool(PI2), PI3=bool(PI3),
               ratio=float(ft/fa) if fa > 0 else None, extra=int(extra)),
          open('results_iso_001.json','w'), indent=1)
