# EXP-BOUND-002: фазовая диаграмма. Seed=42. Пререг: prereg_exp_bound_002.md
import json
import numpy as np, networkx as nx
from scipy import sparse

NB, BS, HUB = 8, 40, 40
NBASE = NB * BS
KIN_RATIO, KMEAN = 8.0, 6.0
MUS = [0.0, 0.3, 0.5, 0.7, 0.8, 0.85, 0.9, 0.95, 1.0]
SEEDS = range(8)

def make_graph(mu, seed):
    rng = np.random.default_rng(1000 * seed + int(mu * 100))
    # SBM: p_in/p_out=8, средняя степень 6
    # k = BS*p_in + (NB-1)*BS*p_out; p_in = 8*p_out
    p_out = KMEAN / (BS * (KIN_RATIO + (NB - 1)))
    p_in = KIN_RATIO * p_out
    G = nx.Graph()
    G.add_nodes_from(range(NBASE + HUB))
    base_edges = []
    for i in range(NBASE):
        for j in range(i + 1, NBASE):
            p = p_in if i // BS == j // BS else p_out
            if rng.random() < p:
                base_edges.append((i, j))
    hubs = list(range(NBASE, NBASE + HUB))
    for i in range(NBASE, NBASE + HUB):
        for j in range(i + 1, NBASE + HUB):
            if rng.random() < 4.0 / (HUB - 1):
                G.add_edge(i, j)
    for (u, v) in base_edges:
        if rng.random() < mu:
            h = hubs[rng.integers(HUB)]
            G.add_edge(u, h); G.add_edge(h, v)
        else:
            G.add_edge(u, v)
    return G

def chain(G):
    nodes = sorted(G.nodes()); idx = {v: i for i, v in enumerate(nodes)}
    n = len(nodes)
    r = [idx[u] for u, v in G.edges()] + [idx[v] for u, v in G.edges()]
    c = [idx[v] for u, v in G.edges()] + [idx[u] for u, v in G.edges()]
    A = sparse.csr_matrix((np.ones(len(r), np.float64), (r, c)), shape=(n, n))
    deg = np.asarray(A.sum(1)).ravel(); deg[deg == 0] = 1
    PL = 0.5 * (sparse.identity(n) + sparse.diags(1 / deg) @ A)
    pi = np.ones(n) / n
    for _ in range(1500):
        pi = np.asarray(pi @ PL).ravel(); pi /= pi.sum()
    return nodes, idx, PL, pi

def tau_batch(PL, pi, F, tmax=200):
    F = F - (pi @ F); c0 = (pi[:, None] * F * F).sum(0)
    out = np.full(F.shape[1], float(tmax)); Gm = F.copy()
    alive = np.ones(F.shape[1], bool)
    for t in range(1, tmax + 1):
        Gm = np.asarray(PL @ Gm)
        c = (pi[:, None] * F * Gm).sum(0)
        cross = alive & (c / np.maximum(c0, 1e-12) < np.exp(-1))
        out[cross] = t; alive &= ~cross
        if not alive.any(): break
    return out

def align(PL, pi, nodes, blocks_of, base_mask):
    n = PL.shape[0]
    vals, vecs = np.linalg.eig(PL.T.toarray())
    order = np.argsort(-np.abs(vals))
    r2s = []
    lb = np.array([blocks_of.get(v, -1) for v in nodes])
    sel = base_mask
    for j in order[1:4]:
        v = np.real(vecs[:, j])[sel]; l = lb[sel]
        mu_ = v.mean(); sst = ((v - mu_) ** 2).sum()
        ssw = sum(((v[l == c] - v[l == c].mean()) ** 2).sum() for c in set(l))
        r2s.append(1 - ssw / sst if sst > 0 else 0)
    return float(np.mean(r2s))

RES = {}
for mu in MUS:
    rows = []
    for s in SEEDS:
        G = make_graph(mu, s)
        blocks_of = {i: i // BS for i in range(NBASE)}
        hubset = set(range(NBASE, NBASE + HUB))
        # до удаления
        Gc = G.subgraph(max(nx.connected_components(G), key=len)).copy()
        nodes, idx, PL, pi = chain(Gc)
        base_mask = np.array([v < NBASE for v in nodes])
        Fb = []
        blocks_present = []
        for b in range(NB):
            ind = np.array([1.0 if (v < NBASE and blocks_of[v] == b) else 0.0 for v in nodes])
            if ind.sum() >= 10:
                Fb.append(ind); blocks_present.append(b)
        tau_before = tau_batch(PL, pi, np.stack(Fb, 1))
        al_before = align(PL, pi, nodes, blocks_of, base_mask)
        # после удаления хаб-слоя
        H = G.copy(); H.remove_nodes_from(hubset)
        if H.number_of_edges() == 0:
            R = 0.0; surv = 0.0; dtau = np.nan; al_after = 0.0
        else:
            lcc = max(nx.connected_components(H), key=len)
            R = len(lcc) / G.number_of_nodes()
            Hc = H.subgraph(lcc).copy()
            nodes2, idx2, PL2, pi2 = chain(Hc)
            F2, blocks2 = [], []
            for b in blocks_present:
                ind = np.array([1.0 if blocks_of.get(v, -1) == b else 0.0 for v in nodes2])
                if ind.sum() >= 10:
                    F2.append(ind); blocks2.append(b)
            surv = len(blocks2) / NB
            if blocks2:
                tau_after = tau_batch(PL2, pi2, np.stack(F2, 1))
                m = [blocks_present.index(b) for b in blocks2]
                dtau = float(np.median(tau_after) - np.median(tau_before[m]))
                al_after = align(PL2, pi2, nodes2, blocks_of,
                                 np.ones(len(nodes2), bool))
            else:
                dtau = np.nan; al_after = 0.0
        rows.append(dict(R=R, surv=surv, dtau=dtau,
                         tb=float(np.median(tau_before)), al_b=al_before, al_a=al_after))
    RES[mu] = rows
    Rm = np.mean([r['R'] for r in rows])
    sv = np.mean([r['surv'] for r in rows])
    dt = np.nanmedian([r['dtau'] for r in rows])
    win = sum(1 for r in rows if not np.isnan(r['dtau']) and r['dtau'] > 0
              and r['al_a'] >= r['al_b'])
    print('mu=%.2f  R=%.3f  surv=%.2f  medΔτ=%s  τ_до=%.1f  (Δτ>0 и al↑): %d/8'
          % (mu, Rm, sv, ('%.1f' % dt) if not np.isnan(dt) else 'nan',
             np.mean([r['tb'] for r in rows]), win))

# вердикты
means = {mu: np.mean([r['R'] for r in RES[mu]]) for mu in MUS}
from scipy.stats import spearmanr
rho, _ = spearmanr(MUS, [means[m] for m in MUS])
PB1 = rho <= -0.95 and sum(1 for m in MUS if 0.1 <= means[m] <= 0.6) >= 2
shunt = [m for m in MUS if 0 < m < 1 and means[m] >= 0.6]
PB2 = all(sum(1 for r in RES[m] if not np.isnan(r['dtau']) and r['dtau'] > 0
              and r['al_a'] >= r['al_b']) >= 6 for m in shunt)
work = [m for m in MUS if 0 < m < 1 and
        np.nanmedian([r['dtau'] for r in RES[m]]) > 0 and
        np.mean([r['surv'] for r in RES[m]]) >= 6 / 8]
Rstar = min(means[m] for m in work) if work else None
PB3 = Rstar is not None and 0.25 <= Rstar <= 0.65
mu95 = [m for m in MUS if m >= 0.95]
PB4 = all(np.mean([r['surv'] for r in RES[m]]) < 0.5 for m in mu95)
print('P-B1', 'PASS' if PB1 else 'FAIL', '(rho=%.3f)' % rho)
print('P-B2', 'PASS' if PB2 else 'FAIL', 'шунтовые mu:', shunt)
print('P-B3', 'PASS' if PB3 else 'FAIL', 'R*=%.3f (рабочие mu: %s)' % (Rstar or -1, work))
print('P-B4', 'PASS' if PB4 else 'FAIL')
json.dump(dict(means={str(m): float(means[m]) for m in MUS},
               Rstar=float(Rstar) if Rstar else None,
               PB1=bool(PB1), PB2=bool(PB2), PB3=bool(PB3), PB4=bool(PB4),
               rows={str(m): RES[m] for m in MUS}),
          open('results_bound_002.json', 'w'), indent=1, default=float)
