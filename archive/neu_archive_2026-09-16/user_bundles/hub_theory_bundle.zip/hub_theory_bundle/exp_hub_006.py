# EXP-HUB-006: репликация на H. pylori (iIT341) и M. barkeri (iAF692, архей).
# Seed=42. Пререг: prereg_exp_hub_006.md. Замена RBC->iAF692 по контингентности,
# адаптация R2 зафиксирована до парсинга (см. сообщение и отчёт).
import json
import xml.etree.ElementTree as ET
import numpy as np, networkx as nx
from scipy import sparse
from scipy.sparse.linalg import eigsh

rng = np.random.default_rng(42)

CUR = set()
for b in ['h', 'h2o', 'atp', 'adp', 'amp', 'pi', 'ppi', 'nad', 'nadh',
          'nadp', 'nadph', 'co2', 'o2', 'nh4', 'q8', 'q8h2']:
    for c in ['_c', '_e', '_p']:
        CUR.add(b + c)
CARBON = ['pyr_c', 'accoa_c', 'oaa_c', 'akg_c']

def load_sbml(path):
    root = ET.fromstring(open(path, 'rb').read())
    ns = {'s': root.tag.split('}')[0].strip('{')}
    model = root.find('s:model', ns)
    mets = {sp.get('id') for sp in model.find('s:listOfSpecies', ns)
            if sp.get('boundaryCondition') != 'true'}
    G = nx.DiGraph()
    for rx in model.find('s:listOfReactions', ns):
        rid = (rx.get('id') or '').upper()
        if 'EX_' in rid or 'BIOMASS' in rid: continue
        rev = rx.get('reversible') == 'true'
        lr = rx.find('s:listOfReactants', ns); lp = rx.find('s:listOfProducts', ns)
        R = [x.get('species') for x in lr] if lr is not None else []
        P = [x.get('species') for x in lp] if lp is not None else []
        for a in R:
            for b in P:
                if a in mets and b in mets and a != b:
                    G.add_edge(a, b)
                    if rev: G.add_edge(b, a)
    return nx.relabel_nodes(G, {n: (n[2:] if n.startswith('M_') else n) for n in G.nodes()})

def crystal_fast(U):
    C = U.subgraph(max(nx.connected_components(U), key=len))
    n = C.number_of_nodes()
    if n < 3: return None
    A = nx.to_scipy_sparse_array(C, dtype=float)
    try:
        ev = eigsh(A, k=2, which='LA', return_eigenvectors=False, maxiter=2000)
        ev = np.sort(ev)[::-1]
    except Exception:
        ev = np.sort(np.linalg.eigvalsh(A.todense()))[::-1][:2]
    return float(ev[1] / ev[0]) if ev[0] > 0 else None

def btw_top(G):
    b = nx.betweenness_centrality(G)
    s = sum(b.values()) or 1.0
    items = sorted(b.items(), key=lambda kv: -kv[1])
    return items, items[0][1] / s

def battery(name, path):
    print('===', name, '===')
    G = load_sbml(path)
    n, m = G.number_of_nodes(), G.number_of_edges()
    cur = sorted(set(G) & CUR)
    print('узлов %d, рёбер %d | валютных в графе %d (базовая доля %.2f)'
          % (n, m, len(cur), len(cur) / n))
    items, top1 = btw_top(G)
    top10 = [k for k, _ in items[:10]]
    R1n = sum(1 for k in top10 if k in CUR)
    print('top-10 btw:', top10)
    print('R1: валютных в top-10 = %d (порог >=6) ->' % R1n, 'PASS' if R1n >= 6 else 'FAIL')
    # M1 до/после, удаление валют
    U = nx.Graph(G)
    m1_before = crystal_fast(U)
    Gnc = G.copy(); Gnc.remove_nodes_from(cur)
    wcc = max(nx.weakly_connected_components(Gnc), key=len)
    Gnc = Gnc.subgraph(wcc).copy()
    items2, _ = btw_top(Gnc)
    top3 = [k for k, _ in items2[:3]]
    carbon_present = [c for c in CARBON if c in G]
    R2a = sum(1 for k in top3 if k in CARBON)
    print('top-3 после удаления валют:', top3, '| углеродный набор в модели:', carbon_present)
    print('R2: попаданий из {pyr,accoa,oaa,akg} в top-3 =', R2a, '->',
          'PASS' if R2a >= 1 else 'FAIL')
    sub_acc = 'accoa_c' in top3
    m1_after = crystal_fast(nx.Graph(Gnc))
    R4 = m1_after is not None and m1_before is not None and m1_after > m1_before
    print('R4: M1 %.3f -> %.3f ->' % (m1_before, m1_after), 'PASS' if R4 else 'FAIL')
    # R3: ER-нуль
    nulls = []
    for i in range(50):
        H = nx.gnm_random_graph(n, m, seed=500 + i, directed=True)
        _, t1 = btw_top(H)
        nulls.append(t1)
    nulls = np.array(nulls)
    z = (top1 - nulls.mean()) / nulls.std()
    print('R3: top1=%.4f null=%.4f±%.4f z=%.1f ->' % (top1, nulls.mean(), nulls.std(), z),
          'PASS' if z >= 3 else 'FAIL')
    # R6: удержание
    Uc = nx.Graph(G); Uc.remove_nodes_from(cur)
    R6v = (len(max(nx.connected_components(Uc), key=len)) / n) if Uc.number_of_edges() else 0
    print('R6: retention после удаления валют = %.3f ->' % R6v, 'PASS' if R6v >= 0.5 else 'FAIL')
    # R5: детектор с правилом остановки
    Gd = nx.Graph(G)
    removed, prev, low_streak = [], crystal_fast(Gd), 0
    for step in range(25):
        best, bestm = None, -2.0
        for v in list(Gd.nodes()):
            H = Gd.copy(); H.remove_node(v)
            if H.number_of_nodes() < 3 or H.number_of_edges() == 0: continue
            mm = crystal_fast(H)
            if mm is not None and mm > bestm:
                bestm, best = mm, v
        gain = bestm - prev
        Gd.remove_node(best); removed.append((best, best in CUR))
        low_streak = low_streak + 1 if gain < 0.01 else 0
        prev = bestm
        if low_streak >= 2:
            removed = removed[:-2] if len(removed) >= 2 else []
            break
    hits = sum(1 for _, c in removed if c)
    prec = hits / len(removed) if removed else 0.0
    print('R5: остановка на шаге %d, точность %d/%d = %.2f (порог 0.60) ->'
          % (len(removed), hits, len(removed), prec), 'PASS' if prec >= 0.6 else 'FAIL')
    print('удалено:', [r[0] for r in removed])
    return dict(n=n, m=m, base_rate=len(cur) / n, R1=R1n, top10=top10,
                top3_nc=top3, R2=R2a, sub_accoa=bool(sub_acc),
                m1=[m1_before, m1_after], z=float(z), R6=float(R6v),
                R5=dict(steps=len(removed), prec=float(prec),
                        removed=[r[0] for r in removed]))

out = {}
out['iIT341_Hpylori'] = battery('iIT341 (H. pylori)', 'iIT341.xml')
out['iAF692_Mbarkeri'] = battery('iAF692 (M. barkeri, архей)', 'iAF692.xml')
json.dump(out, open('results_hub_006.json', 'w'), indent=1, ensure_ascii=False)
