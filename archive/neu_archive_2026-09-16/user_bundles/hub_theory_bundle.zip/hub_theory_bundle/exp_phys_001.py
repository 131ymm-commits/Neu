# EXP-PHYS-001: Стандартная модель из DECAY_LHCB.DEC. Seed=42.
import json, os, glob, math
import numpy as np, networkx as nx
from decaylanguage import DecFileParser
from particle import Particle
from particle import pdgid as PID

HBAR = 6.582119569e-22  # МэВ*с
TAU_FAST = 1e-15        # порог сильное+ЭМ

import decaylanguage
dec = glob.glob(os.path.dirname(decaylanguage.__file__) + '/data/DECAY_LHCB.DEC')[0]
dfp = DecFileParser(dec)
dfp.parse()
mothers = dfp.list_decay_mother_names()
print('матерей в файле:', len(mothers))

cache = {}
def part(name):
    if name not in cache:
        try:
            cache[name] = Particle.from_evtgen_name(name)
        except Exception:
            cache[name] = None
    return cache[name]

def charges(p):
    pid = int(p.pdgid)
    Q = p.charge if p.charge is not None else 0.0
    B = (1 if pid > 0 else -1) if PID.is_baryon(pid) else 0
    Le = Lm = Lt = 0
    a = abs(pid)
    if a in (11, 12): Le = 1 if pid > 0 else -1
    if a in (13, 14): Lm = 1 if pid > 0 else -1
    if a in (15, 16): Lt = 1 if pid > 0 else -1
    qs = p.quarks or ''
    S = qs.count('S') - qs.count('s')
    C = qs.count('c') - qs.count('C')
    Bq = qs.count('B') - qs.count('b')
    return dict(Q=Q, B=B, Le=Le, Lm=Lm, Lt=Lt, S=S, C=C, Bq=Bq)

# калибровка знаков
for nm, key, want in [('K+', 'S', 1), ('Lambda0', 'S', -1), ('D0', 'C', 1), ('B0', 'Bq', 1)]:
    got = charges(part(nm))[key]
    print('калибровка %s %s: %+d (ожидалось %+d)' % (nm, key, got, want))
    assert got == want

channels = []      # (mother_particle, [daughter_particles])
skipped = total = 0
for m in mothers:
    pm = part(m)
    modes = dfp.list_decay_modes(m)
    for mode in modes:
        total += 1
        ds = [part(d) for d in mode]
        if pm is None or any(d is None for d in ds) or len(ds) == 0:
            skipped += 1
            continue
        channels.append((pm, ds))
frac_skip = skipped / total
print('каналов: %d, пропущено (нераспознанные): %d (%.1f%%)' % (total, skipped, 100 * frac_skip))
GATE1 = frac_skip < 0.15

CH = ['Q', 'B', 'Le', 'Lm', 'Lt', 'S', 'C', 'Bq']
def viol_count(chans, key):
    v = 0
    for pm, ds in chans:
        d = sum(charges(x)[key] for x in ds) - charges(pm)[key]
        if abs(d) > 1e-9: v += 1
    return v

viol_full = {k: viol_count(channels, k) for k in CH}
print('нарушения на полной сети:', viol_full)
GATE2 = viol_full['Q'] == 0
print('санитарный шлюз:', 'PASS' if (GATE1 and GATE2) else 'FAIL')

# быстрая подсеть (родитель tau < 1e-15 c)
def tau_of(p):
    w = p.width
    if w is None or w <= 0: return None
    return HBAR / w
fast = [(pm, ds) for pm, ds in channels
        if (tau_of(pm) is not None and tau_of(pm) < TAU_FAST)]
slow = [(pm, ds) for pm, ds in channels
        if (tau_of(pm) is not None and tau_of(pm) > 1e-14)]
print('каналов: быстрых %d, медленных %d, без ширины %d'
      % (len(fast), len(slow), sum(1 for pm, _ in channels if tau_of(pm) is None)))
viol_fast = {k: viol_count(fast, k) for k in ['S', 'C', 'Bq']}
print('нарушения S/C/Bq на быстрой подсети:', viol_fast)

# SVD: измеренная размерность решётки точных зарядов
species = sorted({int(p.pdgid) for pm, ds in channels for p in [pm] + ds})
sidx = {s: i for i, s in enumerate(species)}
M = np.zeros((len(species), len(channels)))
for j, (pm, ds) in enumerate(channels):
    M[sidx[int(pm.pdgid)], j] -= 1
    for d in ds:
        M[sidx[int(d.pdgid)], j] += 1
sv = np.linalg.svd(M, compute_uv=False)
null_dim = int(np.sum(sv < 1e-8 * sv[0])) + (len(species) - len(sv) if len(sv) < len(species) else 0)
print('видов: %d | каналов: %d | dim левого ядра (полная сеть): %d'
      % (len(species), len(channels), null_dim))
def residual(chans, key):
    r = 0.0
    for pm, ds in chans:
        r = max(r, abs(sum(charges(x)[key] for x in ds) - charges(pm)[key]))
    return r
res_full = {k: residual(channels, k) for k in CH}
res_fast = {k: residual(fast, k) for k in CH}
print('невязки (полная):', {k: round(v, 9) for k, v in res_full.items()})
print('невязки (быстрая):', {k: round(v, 9) for k, v in res_fast.items()})

PP1 = (all(res_full[k] < 1e-8 for k in ['Q', 'B', 'Le', 'Lm', 'Lt'])
       and viol_full['S'] >= 50 and res_full['S'] > 0.1)
PP2 = (all(res_fast[k] < 1e-8 for k in ['S', 'C', 'Bq'])
       and all(res_full[k] > 0.1 for k in ['S', 'C', 'Bq']))
print('P-P1:', 'PASS' if PP1 else 'FAIL', '| P-P2:', 'PASS' if PP2 else 'FAIL')

# P-P3: щели времён жизни
taus = sorted({math.log10(tau_of(pm)) for pm, _ in channels
               if tau_of(pm) is not None and -24 < math.log10(tau_of(pm)) < -11})
gaps = [(taus[i + 1] - taus[i], taus[i], taus[i + 1]) for i in range(len(taus) - 1)]
gmax = max(gaps) if gaps else (0, 0, 0)
bands = 1 + sum(1 for g, _, _ in gaps if g >= 1.5)
print('частиц в окне: %d | max щель: %.2f декад (%.1f..%.1f) | полос (щель>=1.5): %d'
      % (len(taus), gmax[0], gmax[1], gmax[2], bands))
PP3 = gmax[0] >= 1.5 and bands >= 2
print('P-P3:', 'PASS' if PP3 else 'FAIL')

# P-P4: граф на классах |pdgid|, betweenness
G = nx.DiGraph()
for pm, ds in channels:
    a = abs(int(pm.pdgid))
    for d in ds:
        b = abs(int(d.pdgid))
        if a != b: G.add_edge(a, b)
bt = nx.betweenness_centrality(G)
top = sorted(bt.items(), key=lambda kv: -kv[1])[:10]
def nm(pid):
    try: return Particle.from_pdgid(pid).name
    except Exception: return str(pid)
top_named = [(nm(k), round(v, 4)) for k, v in top]
print('top-10 betweenness:', top_named)
r211 = [k for k, _ in sorted(bt.items(), key=lambda kv: -kv[1])].index(211) + 1
r111 = [k for k, _ in sorted(bt.items(), key=lambda kv: -kv[1])].index(111) + 1
PP4 = (min(r211, r111) <= 3) and (max(r211, r111) <= 5)
print('ранги: pi+ = %d, pi0 = %d | P-P4:' % (r211, r111), 'PASS' if PP4 else 'FAIL')

json.dump(dict(mothers=len(mothers), channels=len(channels), skipped=skipped,
               frac_skip=frac_skip, viol_full=viol_full, viol_fast=viol_fast,
               null_dim=null_dim, res_full=res_full, res_fast=res_fast,
               PP1=bool(PP1), PP2=bool(PP2),
               gap=dict(width=gmax[0], lo=gmax[1], hi=gmax[2], bands=bands),
               PP3=bool(PP3), top10=top_named, rank_pip=r211, rank_pi0=r111,
               PP4=bool(PP4)),
          open('results_phys_001.json', 'w'), indent=1, ensure_ascii=False)
