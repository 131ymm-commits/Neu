# Индекс архива

Файлов: 106. Соглашение: prereg → exp → results → report.

## Документы

- `README.md` — обзор программы, домены, соглашения, происхождение данных, статус и очередь
- `INDEX.md` — этот файл: полный перечень содержимого
- `article_popular.md` — научно-популярная статья по итогам программы
- `prior_art.md` — что в работе не наше: приоритет и ссылки
- `analysis_power_history.md` — власть как конфигурация: разбор и направленный прогноз
- `design_democracy.md` — процедура вместо голосования: девять правил из измеренного
- `analysis_chemical_languages.md` — разбор концепции Сахарова и др. в аппарате программы
- `validity_map.md` — КАРТА ГРАНИЦ: 25 записей «где/почему/граница/статус» + шкала R + мета-паттерны
- `origin_of_life.md` — формализация появления жизни (v2, после рецензии)
- `review_origin_and_program.md` — рецензия с проверкой по литературе: 5 дефектов + вердикт по стадии

## Эксперименты

- **HUB-001** — метаболизм e_coli_core: калибровка инструментов, валютные хабы
  `prereg_exp_hub_001.md`, `exp_hub_001.py`, `results_hub_001.json`, `report_exp_hub_001.md`
- **HUB-004** — валюты 1890–1910: стерлинговая звезда, эрозия хаба
  `prereg_exp_hub_004.md`, `exp_hub_004.py`, `results_hub_004.json`, `report_exp_hub_004.md`
- **HUB-005** — слепой детектор валют: горизонт и правило остановки
  `exp_hub_005.py`, `results_hub_005.json`, `report_exp_hub_005.md`
- **HUB-006** — H. pylori и архей: универсальность валют, ярусность волокна
  `prereg_exp_hub_006.md`, `exp_hub_006.py`, `results_hub_006.json`, `report_exp_hub_006.md`
- **HUB-007** — дрожжи: ярусы, компартменты, детектор 1.00
  `prereg_exp_hub_007.md`, `exp_hub_007.py`, `results_hub_007.json`, `report_exp_hub_007.md`
- **HUB-008** — M. tuberculosis + лестница ярусов по 4 организмам
  `prereg_exp_hub_008.md`, `exp_hub_008.py`, `results_hub_008.json`, `report_exp_hub_008.md`
- **HUB-009** — клиентурный механизм валюты (8/8 корреляций)
  `prereg_exp_hub_009.md`, `exp_hub_009.py`, `results_hub_009.json`, `report_exp_hub_009.md`
- **LEV-001** — синтетика 3×3×3: калибровка уровневых инструментов
  `exp_lev_001.py`, `results_lev_001.json`, `report_exp_lev_001.md`
- **LEV-002** — авиация: континенты/страны как уровни
  `prereg_exp_lev_002.md`, `exp_lev_002.py`, `results_lev_002.json`, `report_exp_lev_002.md`
- **LEV-003** — электросеть Техаса: зоны-уровни, напряжения-хаб
  `exp_lev_003.py`, `results_lev_003.json`, `report_exp_lev_003_004.md`
- **LEV-004** — рельсы Индии: зоны и штаты
  `exp_lev_004.py`, `results_lev_004.json`, `report_exp_lev_003_004.md`
- **LEV-005** — ядро Linux: номенклатура против механизма, хаб-как-среда
  `prereg_exp_lev_005.md`, `exp_lev_005.py`, `results_lev_005.json`, `report_exp_lev_005.md`
- **BOUND-001** — шкала R: измерение шунт↔среда на всех системах
  `exp_bound_001.py`, `results_bound_001.json`
- **BOUND-002** — фазовая диаграмма: механизм границы = перколяция базы
  `prereg_exp_bound_002.md`, `exp_bound_002.py`, `results_bound_002.json`, `report_exp_bound_002.md`
- **Q-001** — эксергия: нулевая энтропия в собственной валюте
  `prereg_exp_q_001.md`, `exp_q_001.py`, `results_q_001.json`, `report_exp_q_001.md`
- **PHYS-001** — Стандартная модель из таблиц распадов: решётка зарядов
  `prereg_exp_phys_001.md`, `exp_phys_001.py`, `results_phys_001.json`, `report_exp_phys_001.md`
- **PHYS-002** — кварковый сектор: цвет как шестой заряд, конфайнмент
  `prereg_exp_phys_002.md`, `exp_phys_002.py`, `results_phys_002.json`, `report_exp_phys_002.md`
- **PHYS-003** — ядра: четыре ряда, лестница K_τ, массовый монотон
  `prereg_exp_phys_003.md`, `exp_phys_003.py`, `results_phys_003.json`, `report_exp_phys_003.md`
- **TRANS-001** — обучение: переносится ли башня через трансформер
  `prereg_exp_trans_001.md`, `exp_trans_001.py`, `results_trans_001.json`, `report_exp_trans_001.md`
- **GOV-001** — право ФРГ: законы как уровни и заряды
  `prereg_exp_gov_001.md`, `exp_gov_001.py`, `results_gov_001.json`, `report_exp_gov_001.md`
- **CULT-001** — этимология: доноры-валюты, модульность без памяти
  `prereg_exp_cult_001.md`, `exp_cult_001.py`, `results_cult_001.json`, `report_exp_cult_001.md`

- **HIST-001** — фазовая диаграмма устойчивости конфигураций власти
  `exp_hist_001.py`, `results_hist_001.json`, `analysis_power_history.md`

- **DEM-001** — проектные границы процедуры: централизация и право форка
  `exp_dem_001.py`, `results_dem_001.json`, `design_democracy.md`

- **NEU-002** — глубина синтеза передатчика против времени его действия
  `exp_neu_002.py`, `results_neu_002.json`, `analysis_chemical_languages.md`

- **NEU-001** — нейромедиаторы как ярус сигнальной валюты (тест неинформативен)
  `prereg_exp_neu_001.md`, `exp_neu_001.py`, `results_neu_001.json`, `results_neu_001_diag.json`, `report_exp_neu_001.md`

- **REAL-001** — сводная башня и граница самовключения (kill сработал)
  `prereg_exp_real_001.md`, `exp_real_001.py`, `results_real_001.json`, `results_real_001_true.json`, `report_exp_real_001.md`

- **LLM-002** — искусственно добавленные уровни: обмен верности на когерентность
  `prereg_exp_llm_002.md`, `exp_llm_002.py`, `results_llm_002.json`, `results_llm_002_posthoc.json`, `report_exp_llm_002.md`

- **LLM-001** — как появляются уровни в модели: порядок, момент, правило усложнения
  `prereg_exp_llm_001.md`, `exp_llm_001.py`, `exp_llm_001_run.py`, `results_llm_A.json`, `results_llm_B.json`, `report_exp_llm_001.md`

- **COL-002** — Коллатц в восьмимерном кубе: полярная шапка и точная биномиальность
  `prereg_exp_col_002.md`, `exp_col_002.py`, `results_col_002.json`, `results_col_002_fixed.json`, `report_exp_col_002.md`

- **COL-001** — гипотеза Коллатца: точная башня без поточечного монотона
  `prereg_exp_col_001.md`, `exp_col_001.py`, `results_col_001.json`, `report_exp_col_001.md`

- **HAE-001** — гипотеза Хемерса: случайное вырождение против структурного
  `prereg_exp_hae_001.md`, `exp_hae_001.py`, `results_hae_001.json`, `report_exp_hae_001.md`

- **STR-004** — Эйлер в теории струн: заряд, квотиент, база, потолок лестницы
  `prereg_exp_str_004.md`, `exp_str_004.py`, `results_str_004.json`, `report_exp_str_004.md`

- **NU-001** — масса нейтрино: орбита, якоря и лестница зарядов СМ
  `prereg_exp_nu_001.md`, `exp_nu_001.py`, `results_nu_001.json`, `report_exp_nu_001.md`

- **WOL-001** — заряды и уровни против вычислительной несводимости (256 автоматов)
  `prereg_exp_wol_001.md`, `exp_wol_001.py`, `results_wol_001.json`, `results_wol_001_final.json`, `report_exp_wol_001.md`

- **SELF-001** — теория о самой себе: что даёт разрешающую способность инструменту
  `prereg_exp_self_001.md`, `exp_self_001.py`, `results_self_001.json`, `report_exp_self_001.md`

- **ISO-001** — приоритет находки и разрешающая способность наших инструментов
  `prereg_exp_iso_001.md`, `exp_iso_001.py`, `results_iso_001.json`, `report_exp_iso_001.md`

- **STR-003** — спектр не определяет структуру: тэта-ряды двух гетеротических решёток
  `prereg_exp_str_003.md`, `exp_str_003.py`, `results_str_003.json`, `report_exp_str_003.md`

- **STR-002** — достроить теорию струн монотоном: рецепт программы и где он ломается
  `prereg_exp_str_002.md`, `exp_str_002.py`, `results_str_002.json`, `report_exp_str_002.md`

- **STR-001** — теория струн как задача о балансе зарядов
  `prereg_exp_str_001.md`, `exp_str_001.py`, `results_str_001.json`, `report_exp_str_001.md`

- **GR-001** — ОТО и СМ в языке программы: этаж действия группы и ранг зарядов
  `prereg_exp_gr_001.md`, `exp_gr_001.py`, `results_gr_001.json`, `results_gr_001_exact.json`, `report_exp_gr_001.md`

- **SM-001** — есть ли у теории добавленная стоимость для Стандартной модели (отрицательный результат)
  `prereg_exp_sm_001.md`, `exp_sm_001.py`, `results_sm_001.json`, `report_exp_sm_001.md`

- **PHYS-005** — бозон Хиггса как хаб домена масс: v, юкавы, ширины, бег заряда
  `prereg_exp_phys_005.md`, `exp_phys_005.py`, `results_phys_005.json`, `report_exp_phys_005.md`

- **PHYS-004** — адронный спектр: заряд, монотон, слепое предсказание массы Ω⁻
  `prereg_exp_phys_004.md`, `exp_phys_004.py`, `results_phys_004.json`, `report_exp_phys_004.md`

- **PRED-001** — слепая числовая калибровка теории на двух новых системах
  `prereg_exp_pred_001.md`, `exp_pred_001.py`, `results_pred_001.json`, `report_exp_pred_001.md`

- **AA-001** — химия: причина порядка рекрутирования аминокислот (отрицательный результат)
  `prereg_exp_aa_001.md`, `exp_aa_001.py`, `results_aa_001.json`, `report_exp_aa_001.md`

- **HUB-002a/003a** — деньги и энергия: `exp_hub_002_003_report.md` (расчёты внутри отчёта)

## Данные в архиве

- `textbook.xml.gz` — e_coli_core (BiGG)
- `fj_data.txt` — валютные пары 1890–1910
- `routes.dat` — OpenFlights: рейсы
- `airports.dat` — OpenFlights: аэропорты
- `case_ACTIVSg2000.m` — электросеть ACTIVSg2000 (MATPOWER)
- `iIT341.xml` — H. pylori
- `iAF692.xml` — M. barkeri (архей)
- `iND750.xml` — S. cerevisiae
- `iNJ661.xml` — M. tuberculosis
- `gov_graph.npz` — граф права ФРГ (рёбра)
- `gov_nodes.json` — узлы права
- `gov_jur.json` — аббревиатуры законов

## Сборщики (качают крупное сырьё)

- `build_kernel_graph.py` — сборщик графа ядра Linux (качает сырьё)
- `build_gov_graph.py` — сборщик графа права ФРГ (качает сырьё)
- `build_cult_graph.py` — сборщик этимологической сети (качает сырьё)

## Рисунки

- `fig_hub_signatures.png` — сигнатуры хаба (HUB-001)
- `fig_hub_004.png` — эрозия валютного хаба
- `fig_bound_002.png` — фазовая диаграмма шунт↔среда
- `fig_tiers_ladder.png` — лестница ярусов, 4 организма
- `fig_trans_001.png` — башня в спектре выученного ядра
- `fig_phys_003.png` — лестница K_τ ядерного домена

## Прочее

- `posthoc_trans_001.py` — пост-хок к TRANS-001: башня в unembedding (не пререгистрирован)
