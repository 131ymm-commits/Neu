# EXP-COL-002: Коллатц в 8-мерном кубе. Пререг: prereg_exp_col_002.md
import json
import numpy as np
from math import comb, log
from scipy.stats import chisquare

rng = np.random.default_rng(42)

def parity_int(n, k):
    v = 0
    for i in range(k):
        b = n & 1
        v |= (b << i)
        n = (3*n+1)//2 if b else n//2
    return v

# P-G1: биективность Q_k
print('P-G1: проверка биективности Q_k полным перебором')
ok = True
for k in range(1, 17):
    img = np.array([parity_int(n, k) for n in range(2**k)])
    bij = len(np.unique(img)) == 2**k
    ok &= bij
    if k <= 8 or k == 16:
        print('  k=%2d: 2^k = %-6d различных образов %-6d биекция: %s'
              % (k, 2**k, len(np.unique(img)), bij))
print('P-G1 ->', 'PASS' if ok else 'FAIL')

# P-G2: полярная шапка и дрейф
cap = sum(comb(8, w) for w in range(6, 9))
drift = 4*log(3) - 8*log(2)
PG2 = cap == 37 and abs(drift + 1.1507) <= 1e-4
print('\nP-G2: вершин в шапке {w ≥ 6}: %d из 256 = %.2f%% | дрейф за блок = %.4f (за шаг %.4f) -> %s'
      % (cap, 100*cap/256, drift, drift/8, 'PASS' if PG2 else 'FAIL'))
print('      геометрия: рост ⟺ образ Q₈ попал в шапку; вес ≥ 6 ⟺ 3^w > 2^8')

# распределение веса по всем 256 классам — точное
img8 = np.array([parity_int(n, 8) for n in range(256)])
w8 = np.array([bin(v).count('1') for v in img8])
hist = np.bincount(w8, minlength=9)
print('      точное распределение веса по классам:', hist.tolist())
print('      биномиальное C(8,w):                 ', [comb(8, w) for w in range(9)])

# P-G3: независимость последовательных блоков
W = []
for _ in range(3000):
    n = int(rng.integers(10**12, 10**15))
    ws = []
    for _ in range(20):
        v = parity_int(n, 8); ws.append(bin(v).count('1'))
        for _ in range(8):
            n = (3*n+1)//2 if (n & 1) else n//2
    W.append(ws)
W = np.array(W)
flat = W.ravel()
obs = np.bincount(flat, minlength=9).astype(float)
exp = np.array([comb(8, w) for w in range(9)], float)/256*len(flat)
chi2, p = chisquare(obs, exp)
lag1 = np.corrcoef(W[:, :-1].ravel(), W[:, 1:].ravel())[0, 1]
PG3 = abs(lag1) < 0.02 and p > 0.05
print('\nP-G3: блоков %d | средний вес %.4f (теория 4.0) | хи-квадрат p = %.3f | автокорр. лаг-1 = %+.4f -> %s'
      % (flat.size, flat.mean(), p, lag1, 'PASS' if PG3 else 'FAIL'))

# P-G4: максимальная серия внутри шапки
incap = (W >= 6)
runs = []
for row in incap:
    r = c = 0
    for x in row:
        c = c+1 if x else 0
        r = max(r, c)
    runs.append(r)
# длинный одиночный прогон для 1e6 блоков
n = int(rng.integers(10**15, 10**18)); best = cur = 0
for _ in range(10**6):
    v = parity_int(n, 8)
    cur = cur+1 if bin(v).count('1') >= 6 else 0
    best = max(best, cur)
    for _ in range(8):
        n = (3*n+1)//2 if (n & 1) else n//2
    if n <= 1: n = int(rng.integers(10**15, 10**18))
pred = log(10**6)/log(1/(37/256))
PG4 = abs(best - 7) <= 3
print('P-G4: максимальная серия блоков в шапке на 10⁶ блоков: %d | независимая модель даёт %.1f | регистр. 7 ± 3 -> %s'
      % (best, pred, 'ПОПАЛ' if PG4 else 'МИМО'))
json.dump(dict(PG1=bool(ok), cap=cap, drift=drift, PG2=bool(PG2),
               mean_w=float(flat.mean()), chi2_p=float(p), lag1=float(lag1),
               PG3=bool(PG3), max_run=int(best), pred_run=float(pred), PG4=bool(PG4),
               hist=hist.tolist()),
          open('results_col_002.json','w'), indent=1)
