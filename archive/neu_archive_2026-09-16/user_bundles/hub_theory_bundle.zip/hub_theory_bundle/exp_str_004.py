# EXP-STR-004: Эйлер в теории струн. Пререг: prereg_exp_str_004.md
import json
import numpy as np

# ---- P-E1: zeta(-1) численно, через эта-функцию Дирихле ----
# eta(s) = (1-2^(1-s)) zeta(s);  eta(-1) = sum (-1)^(n-1) n  (Абель)
def eta_abel(s, N=200000):
    n = np.arange(1, N+1, dtype=float)
    terms = ((-1.0)**(n-1))*n**(-s)
    # суммирование Абеля–Эйлера (усреднение частичных сумм)
    part = np.cumsum(terms)
    for _ in range(30):
        part = 0.5*(part[:-1] + part[1:])
    return float(part[-1])
eta_m1 = eta_abel(-1.0)
zeta_m1 = eta_m1/(1 - 2**(1-(-1.0)))
print('P-E1: eta(-1) численно = %.10f (точно 1/4) | zeta(-1) = %.10f (точно -1/12 = %.10f)'
      % (eta_m1, zeta_m1, -1/12))
ok_zeta = abs(zeta_m1 + 1/12) < 1e-6
# критическая размерность из интерсепта a = -(D-2)*zeta(-1)/2 = (D-2)/24
D_bos = 2 + 24*1.0                 # a = 1
D_sup = 2 + 8*1.0                  # суперструна: a = 1/2, (D-2)/16 = 1/2
print('      интерсепт a = (D−2)/24 = 1 → D = %d | суперструна (D−2)/16 = 1/2 → D = %d'
      % (D_bos, D_sup))
PE1 = ok_zeta and D_bos == 26 and D_sup == 10
print('      -> %s' % ('PASS' if PE1 else 'FAIL'))

# ---- P-E2: индекс Римана–Роха как эйлерова характеристика ----
print('\nP-E2: «добавили χ, убрали метрику» → индекс')
print('  g   χ=2−2g   модули   КВК   модули−КВК   −3χ')
known = {0: (0, 6), 1: (2, 2), 2: (6, 0), 3: (12, 0), 4: (18, 0)}
ok2 = True
for g in range(5):
    chi = 2 - 2*g
    mod, ckv = known[g]
    ok2 &= (mod - ckv == -3*chi)
    print('  %d   %+6d   %6d   %3d   %10d   %4d' % (g, chi, mod, ckv, mod-ckv, -3*chi))
print('P-E2:', 'PASS' if ok2 else 'FAIL')

# ---- P-E3: вырождение уровней = разбиения в 24 цвета (точная рекурсия) ----
NMAX = 600
series = [0]*(NMAX+1); series[0] = 1
from math import comb
for k in range(1, NMAX+1):
    # умножаем на 1/(1-q^k)^24 = sum_j C(j+23,23) q^{jk}
    fac = []
    j = 0
    while j*k <= NMAX:
        fac.append((j*k, comb(j+23, 23))); j += 1
    new = [0]*(NMAX+1)
    for idx, val in enumerate(series):
        if val == 0: continue
        for off, c in fac:
            if idx+off > NMAX: break
            new[idx+off] += val*c
    series = new
d = np.array([series[n] for n in range(1, NMAX+1)], dtype=object)
Ns = np.arange(1, NMAX+1)
logd = np.array([float(np.log(float(x))) if x > 0 else 0.0 for x in d])
m = Ns >= 100
A = np.vstack([np.sqrt(Ns[m]), np.log(Ns[m]), np.ones(m.sum())]).T
c1, c2, c3 = np.linalg.lstsq(A, logd[m], rcond=None)[0]
PE3 = abs(c1 - 4*np.pi) <= 0.5
print('\nP-E3: p₂₄(1) = %d, p₂₄(10) = %d, p₂₄(100) = %.3e'
      % (series[1], series[10], float(series[100])))
print('      подгонка log d(N) = c₁√N + c₂ log N + c₃ на N ≥ 100:')
print('      c₁ = %.4f | 4π = %.4f | c₂ = %.2f (теория −27/4 = −6.75) -> %s'
      % (c1, 4*np.pi, c2, 'PASS' if PE3 else 'FAIL'))

# ---- P-E4: температура Хагедорна ----
beta_H = c1          # в единицах sqrt(alpha')
PE4 = abs(beta_H - 4*np.pi) <= 0.5
print('\nP-E4: плотность состояний по массе ρ(m) ~ exp(β_H·m), β_H/√α′ = %.4f' % beta_H)
print('      теоретическое 4π = %.4f -> %s' % (4*np.pi, 'PASS' if PE4 else 'FAIL'))
print('      смысл: выше T_H = 1/(4π√α′) лестница уровней перестаёт быть лестницей —')
print('      число состояний растёт быстрее больцмановского подавления.')
json.dump(dict(zeta=zeta_m1, D_bos=D_bos, D_sup=D_sup, PE1=bool(PE1),
               index_ok=bool(ok2), c1=float(c1), c2=float(c2), PE3=bool(PE3),
               beta_H=float(beta_H), PE4=bool(PE4),
               p24=[int(series[n]) for n in (1,2,3,10,50)]),
          open('results_str_004.json','w'), indent=1)
