# EXP-GOV-001 build: сеть параграфов права. Детерминизм, seed не нужен.
import os, re, json
import numpy as np

root = 'gesetze/gesetze-master'
laws = {}   # slug -> dict(title, jurabk, sections=set, text)
for dp, dn, fn in os.walk(root):
    if 'index.md' in fn:
        p = os.path.join(dp, 'index.md')
        txt = open(p, encoding='utf-8', errors='replace').read()
        m = re.match(r'---\n(.*?)\n---\n', txt, re.S)
        if not m: continue
        fm = m.group(1)
        def fmv(key):
            mm = re.search(r'^%s:\s*(.+)$' % key, fm, re.M)
            return mm.group(1).strip().strip('"') if mm else None
        slug, title, jur = fmv('slug'), fmv('Title'), fmv('jurabk')
        if not slug: continue
        laws[slug] = dict(title=title or '', jur=jur or '', text=txt[m.end():])

print('законов:', len(laws))

# секции: заголовки вида '#### § 12a ...' или '### Art 12 ...'
sec_pat = re.compile(r'^#{2,6}\s*(?:\(XXXX\)\s*)?(?:§\s*(\d+[a-z]?)|Artikel\s+(\d+[a-z]?)|Art\.?\s+(\d+[a-z]?))\b', re.M)
sections = {}
for slug, L in laws.items():
    secs = []
    for m in sec_pat.finditer(L['text']):
        num = (m.group(1) or m.group(2) or m.group(3)).lower()
        secs.append((num, m.start()))
    L['secs'] = secs
    for num, _ in secs:
        sections[(slug, num)] = True
print('параграфов всего:', len(sections))

# индексы для резолюции межзаконных отсылок
abbr2slug = {}
for slug, L in laws.items():
    j = L['jur']
    if j:
        abbr2slug.setdefault(j, slug)
        abbr2slug.setdefault(j.replace(' ', ''), slug)
# генитивы из официальных названий (автоматически, для всех законов)
def genitives(title):
    t = title.strip()
    outs = set()
    low = t
    if re.search(r'gesetzbuch$', low, re.I):
        outs |= {('des', t + 's'), ('des', t + 'es'), ('des', t + 'e')}
    elif re.search(r'gesetz$', low, re.I):
        outs |= {('des', t + 'es'), ('des', t + 's')}
    elif re.search(r'(ordnung|verordnung|satzung|richtlinie)$', low, re.I):
        outs |= {('der', t)}
    elif re.search(r'buch$', low, re.I):
        outs |= {('des', t + 's'), ('des', t + 'es')}
    else:
        outs |= {('des', t + 's'), ('des', t + 'es'), ('der', t)}
    return outs
gen2slug = {}
for slug, L in laws.items():
    if not L['title']: continue
    for art, g in genitives(L['title']):
        gen2slug.setdefault((art + ' ' + g).lower(), slug)
print('аббревиатур:', len(abbr2slug), '| генитивных форм:', len(gen2slug))

ref_num = r'(?:§§?|Artikels?|Art\.?)\s*(\d+[a-z]?)'
tail_abbr = r'[ \t]+(?:Abs(?:atz|\.)?\s*\d+[a-z]?\s*)?(?:Satz\s*\d+\s*)?(?:Nr\.?\s*\d+\s*)?(?:des|der)?\s*([A-ZÄÖÜ][A-Za-zÄÖÜäöüß0-9]{1,20}(?:\s[IVX0-9]+)?)'
pat_abbr = re.compile(ref_num + tail_abbr)
pat_gen = re.compile(ref_num + r'.{0,60}?(des|der)\s+([A-ZÄÖÜ][\wäöüß\-, ]{5,90}?)(?=[,.;)\n]|\s(?:bleibt|gilt|find|ist|sind|in\b))')

edges = set()
stats = dict(internal=0, x_abbr=0, x_gen=0, unresolved=0)
for slug, L in laws.items():
    secs = L['secs']
    if not secs: continue
    text = L['text']
    bounds = [s for _, s in secs] + [len(text)]
    secset = {n for n, _ in secs}
    for i, (num, start) in enumerate(secs):
        chunk = text[start:bounds[i + 1]]
        src = (slug, num)
        used = set()
        for m in pat_abbr.finditer(chunk):
            n2, ab = m.group(1).lower(), m.group(2).strip()
            tgt_slug = abbr2slug.get(ab) or abbr2slug.get(ab.replace(' ', ''))
            if tgt_slug and (tgt_slug, n2) in sections:
                edges.add((src, (tgt_slug, n2))); stats['x_abbr'] += 1
                used.add(m.start())
        for m in pat_gen.finditer(chunk):
            if m.start() in used: continue
            n2 = m.group(1).lower()
            key = (m.group(2) + ' ' + m.group(3).strip().rstrip(',')).lower()
            tgt_slug = gen2slug.get(key)
            if tgt_slug and (tgt_slug, n2) in sections:
                edges.add((src, (tgt_slug, n2))); stats['x_gen'] += 1
            else:
                stats['unresolved'] += 1
        for m in re.finditer(r'§§?\s*(\d+[a-z]?)(?![\wäöü])(?!\s*(?:des|der)\b)', chunk):
            n2 = m.group(1).lower()
            after = chunk[m.end():m.end() + 24]
            if re.match(r'\s+[A-ZÄÖÜ][A-Za-z]{1,12}\b', after) and pat_abbr.match(chunk[m.start():m.end() + 26]):
                continue
            if n2 in secset and n2 != num:
                edges.add((src, (slug, n2))); stats['internal'] += 1

print('рёбра:', len(edges), '| статистика отсылок:', stats)
nodes = sorted({a for a, b in edges} | {b for a, b in edges})
idx = {v: i for i, v in enumerate(nodes)}
E = np.array([(idx[a], idx[b]) for a, b in edges], dtype=np.int32)
np.savez_compressed('gov_graph.npz', edges=E)
json.dump([list(v) for v in nodes], open('gov_nodes.json', 'w'))
json.dump({s: laws[s]['jur'] for s in laws}, open('gov_jur.json', 'w'))
print('узлов в графе:', len(nodes))
