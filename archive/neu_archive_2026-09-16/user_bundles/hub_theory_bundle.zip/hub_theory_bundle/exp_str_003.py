# EXP-STR-003: спектр против структуры. Пререг: prereg_exp_str_003.md
import json, itertools
import numpy as np
import networkx as nx

MAXN = 10  # максимальная норма

def poly_pow(coefs, n, deg):
    r = np.zeros(deg+1, dtype=object); r[0] = 1
    for _ in range(n):
        r = np.convolve(r, coefs)[:deg+1]
    return r

def theta_Dn_plus(n, maxnorm):
    """L_n = D_n ∪ (D_n + s), s=(1/2)^n; чётная унимодулярная при n ≡ 0 (mod 8).
       Возвращает число векторов каждой нормы 0..maxnorm."""
    deg = maxnorm
    K = int(np.sqrt(maxnorm)) + 2
    # целая часть: x ∈ Z^n, Σx чётна, норма Σx²
    a = np.zeros(deg+1, dtype=object); b = np.zeros(deg+1, dtype=object)
    for k in range(-K, K+1):
        if k*k <= deg:
            a[k*k] += 1
            b[k*k] += (-1)**k
    A = poly_pow(a, n, deg); B = poly_pow(b, n, deg)
    integer_part = (A + B)//2
    # сдвинутая часть: x = k + s, норма = Σk² + Σk + n/4, Σk чётна (ровно половина)
    f = np.zeros(deg+1, dtype=object)
    for k in range(-K, K+1):
        e = k*k + k
        if 0 <= e <= deg: f[e] += 1
    F = poly_pow(f, n, deg)
    shift = n//4
    shifted = np.zeros(deg+1, dtype=object)
    for m in range(deg+1-shift):
        shifted[m+shift] = F[m]//2
    return integer_part + shifted

t8 = theta_Dn_plus(8, MAXN)
t16 = theta_Dn_plus(16, MAXN)
# Θ(E8⊕E8) = Θ(E8)²  (свёртка по нормам)
t88 = np.convolve(t8, t8)[:MAXN+1]
print('нормы:            ', list(range(0, MAXN+1, 2)))
print('Θ(E8):            ', [int(t8[m]) for m in range(0, MAXN+1, 2)])
print('Θ(E8⊕E8):         ', [int(t88[m]) for m in range(0, MAXN+1, 2)])
print('Θ(D16⁺):          ', [int(t16[m]) for m in range(0, MAXN+1, 2)])
same = all(t88[m] == t16[m] for m in range(0, MAXN+1))
print('\nP-L1: тэта-ряды совпадают почленно до нормы %d -> %s'
      % (MAXN, 'PASS' if same else 'FAIL'))
c3 = int(t88[6])
PL2 = (c3 == 1050240)
print('P-L2: коэффициент при q³ (норма 6) = %d | регистр. 1050240 -> %s'
      % (c3, 'ПОПАЛ' if PL2 else 'МИМО'))

# ---- P-L3: корневые графы ----
def roots_E8():
    R = []
    for i, j in itertools.combinations(range(8), 2):
        for si in (1, -1):
            for sj in (1, -1):
                v = np.zeros(8, int); v[i] = si; v[j] = sj; R.append(v)
    for signs in itertools.product((1, -1), repeat=8):
        if np.prod(signs) == 1:
            R.append(np.array(signs)/2)
    return np.array(R, dtype=float)
def roots_D(n):
    R = []
    for i, j in itertools.combinations(range(n), 2):
        for si in (1, -1):
            for sj in (1, -1):
                v = np.zeros(n); v[i] = si; v[j] = sj; R.append(v)
    return np.array(R)

E8 = roots_E8()
EE = np.vstack([np.hstack([E8, np.zeros((len(E8), 8))]),
                np.hstack([np.zeros((len(E8), 8)), E8])])
D16 = roots_D(16)
def components(R):
    G = nx.Graph(); G.add_nodes_from(range(len(R)))
    M = R @ R.T
    idx = np.argwhere(np.abs(M) > 1e-9)
    G.add_edges_from([(int(a), int(b)) for a, b in idx if a < b])
    return nx.number_connected_components(G)
cEE, cD = components(EE), components(D16)
print('\nкорней: E8⊕E8 = %d, D16⁺ = %d (норма 2 в обеих)' % (len(EE), len(D16)))
print('P-L3: компонент графа неортогональности: E8⊕E8 = %d, D16⁺ = %d -> %s'
      % (cEE, cD, 'PASS' if (cEE == 2 and cD == 1) else 'FAIL'))
PL3 = (cEE == 2 and cD == 1)
json.dump(dict(theta_E8=[int(t8[m]) for m in range(0, MAXN+1, 2)],
               theta_EE=[int(t88[m]) for m in range(0, MAXN+1, 2)],
               theta_D16=[int(t16[m]) for m in range(0, MAXN+1, 2)],
               PL1=bool(same), c3=c3, PL2=bool(PL2),
               comps=[int(cEE), int(cD)], PL3=bool(PL3)),
          open('results_str_003.json','w'), indent=1)
