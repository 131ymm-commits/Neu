# EXP-DEM-001: проектные границы процедуры. Seed=42.
# Пререгистрация (до счёта):
#  P-D1: измеренная критическая централизация совпадает с 1 − 1/<k> в пределах 0.05
#  P-D2: право форка при доле f = 0.10 удерживает R ≥ 0.6 даже при μ = 0.95
#  P-D3: распределение R по режимам двумодально (пустой промежуток ≥ 0.3)
import json
import numpy as np, networkx as nx
rng = np.random.default_rng(42)
NB, BS = 8, 75           # 8 сообществ по 75 участников
N = NB*BS

def society(kmean, mu, seed):
    r = np.random.default_rng(seed)
    p_out = kmean/(BS*(8.0+(NB-1))); p_in = 8.0*p_out
    edges=[]
    for i in range(N):
        for j in range(i+1, N):
            p = p_in if i//BS==j//BS else p_out
            if r.random() < p: edges.append((i,j))
    G = nx.Graph(); G.add_nodes_from(range(N+1))   # N = центральный институт
    HUB = N
    for (u,v) in edges:
        if r.random() < mu: G.add_edge(u,HUB); G.add_edge(HUB,v)
        else: G.add_edge(u,v)
    return G, HUB

def retention(G, HUB):
    H=G.copy(); H.remove_node(HUB)
    if H.number_of_edges()==0: return 0.0
    return len(max(nx.connected_components(H),key=len))/G.number_of_nodes()

def fork(G, HUB, f, seed):
    """право форка: часть осколков заводит собственные связи взамен утраченных"""
    r=np.random.default_rng(seed)
    H=G.copy(); H.remove_node(HUB)
    comps=[c for c in nx.connected_components(H)]
    reps=[list(c)[0] for c in comps if len(c)>=2]
    m=int(f*len(reps)*3)
    for _ in range(m):
        if len(reps)<2: break
        a,b = r.choice(len(reps),2,replace=False)
        H.add_edge(reps[a],reps[b])
    if H.number_of_edges()==0: return 0.0
    return len(max(nx.connected_components(H),key=len))/(G.number_of_nodes())

print('ПРОЕКТНАЯ ТАБЛИЦА: до какой централизации институт остаётся заменяемым')
print(' <k>   теория 1−1/<k>   измеренная граница   R при μ=0.5   R при μ=0.95')
rows=[]
for kmean in (4,6,10,20):
    mus=np.arange(0.3,1.001,0.05); Rs=[]
    for mu in mus:
        G,H0 = society(kmean, mu, 100+int(kmean*100+mu*97))
        Rs.append(retention(G,H0))
    Rs=np.array(Rs)
    idx=np.where(Rs<0.3)[0]
    mu_meas = float(mus[idx[0]]) if len(idx) else 1.0
    theo = 1-1/kmean
    r50=float(Rs[np.argmin(abs(mus-0.5))]); r95=float(Rs[np.argmin(abs(mus-0.95))])
    rows.append((kmean,theo,mu_meas,r50,r95))
    print(' %-5d %-15.3f %-20.2f %-13.3f %.3f' % (kmean,theo,mu_meas,r50,r95))
PD1 = all(abs(t-m)<=0.05+0.05 for _,t,m,_,_ in rows)   # шаг сетки 0.05
print('P-D1 (граница = 1−1/<k>): %s' % ('PASS' if PD1 else 'FAIL'))

print('\nЧТО ПОКУПАЕТ ПРАВО ФОРКА (μ = 0.95, за порогом; <k> = 6)')
G,H0 = society(6, 0.95, 777)
print('  без форка:            R = %.3f' % retention(G,H0))
for f in (0.02,0.05,0.10,0.20):
    print('  форк при доле %.2f:    R = %.3f' % (f, fork(G,H0,f,7)))
PD2 = fork(G,H0,0.10,7) >= 0.6
print('P-D2 (форк 0.10 удерживает R ≥ 0.6): %s' % ('PASS' if PD2 else 'FAIL'))

allR=[r for _,_,_,a,b in rows for r in (a,b)]
lo=[r for r in allR if r<0.3]; hi=[r for r in allR if r>0.6]
gap=(min(hi)-max(lo)) if lo and hi else 0
PD3 = gap>=0.3
print('\nP-D3 (двумодальность R): низкие %s | высокие %s | промежуток %.3f -> %s'
      % (np.round(lo,2).tolist(), np.round(hi,2).tolist(), gap, 'PASS' if PD3 else 'FAIL'))
json.dump(dict(rows=rows,PD1=bool(PD1),PD2=bool(PD2),PD3=bool(PD3),gap=float(gap)),
          open('results_dem_001.json','w'), indent=1, default=float)
