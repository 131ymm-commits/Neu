# EXP-STR-001. Пререг: prereg_exp_str_001.md
import json, itertools
import numpy as np, networkx as nx

# ---- P-T1: критическая размерность из баланса центральных зарядов ----
def critical_D(c_per_dim, c_ghost):
    return -c_ghost/c_per_dim
D_bos = critical_D(1.0, -26.0)
D_sup = critical_D(1.5, -15.0)
PT1 = (abs(D_bos-26) < 1e-12) and (abs(D_sup-10) < 1e-12)
print('P-T1: бозонная струна: c=D·1 + (−26) = 0 → D = %g' % D_bos)
print('      суперструна:     c=D·(3/2) + (−15) = 0 → D = %g  -> %s'
      % (D_sup, 'PASS' if PT1 else 'FAIL'))

# ---- P-T2: сколько групп имеют размерность 496 ----
dims = {}
for n in range(1, 40):
    dims['A%d' % n] = n*(n+2)
for n in range(2, 30):
    dims['B%d' % n] = n*(2*n+1)
for n in range(3, 30):
    dims['C%d' % n] = n*(2*n+1)
for n in range(4, 30):
    dims['D%d' % n] = n*(2*n-1)
dims.update({'E6':78, 'E7':133, 'E8':248, 'F4':52, 'G2':14})
items = sorted({(v, k) for k, v in dims.items() if v <= 496})
print('\nразмерность SO(32) = D16 = %d | E8×E8 = %d' % (dims['D16'], 2*dims['E8']))
sols = {1: [], 2: [], 3: [], 4: []}
names = sorted(dims, key=lambda k: dims[k])
def search(target, start, cur, depth, maxd):
    if target == 0 and cur: sols[len(cur)].append(tuple(cur)); return
    if len(cur) >= maxd or target < 0: return
    for i in range(start, len(names)):
        d = dims[names[i]]
        if d > target: break
        search(target-d, i, cur+[names[i]], depth+1, maxd)
search(496, 0, [], 0, 4)
n1, n2, n3, n4 = len(sols[1]), len(sols[2]), len(sols[3]), len(sols[4])
print('решений dim = 496: 1 множитель — %d %s' % (n1, sols[1]))
print('                   2 множителя — %d: %s' % (n2, sols[2]))
print('                   3 множителя — %d, 4 множителя — %d' % (n3, n4))
has_phys = ('D16',) in sols[1] and ('E8','E8') in sols[2]
PT2 = (n1+n2+n3+n4) > 2 and has_phys
print('P-T2: физические решения найдены: SO(32) %s, E8×E8 %s | всего решений %d > 2 -> %s'
      % ('да' if ('D16',) in sols[1] else 'нет', 'да' if ('E8','E8') in sols[2] else 'нет',
         n1+n2+n3+n4, 'PASS' if PT2 else 'FAIL'))
cal = abs(n2 - 6) <= 5
print('      калибровка: решений из двух множителей = %d | регистр. 6 ± 5 -> %s'
      % (n2, 'ПОПАЛ' if cal else 'МИМО'))

# ---- P-T3: сеть дуальностей ----
G = nx.Graph()
G.add_edges_from([('I','HO'), ('HO','HE'), ('HE','11D'), ('11D','IIA'),
                  ('IIA','IIB'), ('IIB','I')])
bt = nx.betweenness_centrality(G)
ratio = max(bt.values())/min(bt.values())
Rs = []
for v in G:
    H = G.copy(); H.remove_node(v)
    Rs.append(len(max(nx.connected_components(H), key=len))/G.number_of_nodes())
R = float(np.mean(Rs))
PT3 = abs(ratio-1.0) < 1e-9 and abs(R-0.833) <= 0.02
print('\nP-T3: сеть дуальностей (6 углов): betweenness max/min = %.3f | R = %.3f (все узлы одинаковы: %s)'
      % (ratio, R, len(set(np.round(Rs,6))) == 1))
print('      -> %s' % ('PASS' if PT3 else 'FAIL'))
json.dump(dict(D_bos=D_bos, D_sup=D_sup, PT1=bool(PT1),
               sols={str(k): [list(s) for s in v] for k, v in sols.items()},
               n2=n2, PT2=bool(PT2), calib=bool(cal),
               btw_ratio=float(ratio), R=R, PT3=bool(PT3)),
          open('results_str_001.json','w'), indent=1, ensure_ascii=False)
