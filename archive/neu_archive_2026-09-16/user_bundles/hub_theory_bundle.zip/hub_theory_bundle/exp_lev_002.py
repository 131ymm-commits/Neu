# EXP-LEV-002: уровни авиасети. Seed=42. Пререгистрация: prereg_exp_lev_002.md
import csv, json
import numpy as np
import networkx as nx
from scipy import sparse
from scipy.sparse.linalg import eigs

rng = np.random.default_rng(42)

# --- данные ---
country, tz = {}, {}
with open('airports.dat', encoding='utf-8', errors='replace') as f:
    for row in csv.reader(f):
        if len(row) < 12: continue
        aid = row[0]
        country[aid] = row[3]
        tz[aid] = row[11]
G = nx.DiGraph()
with open('routes.dat', encoding='utf-8', errors='replace') as f:
    for row in csv.reader(f):
        if len(row) < 6: continue
        s, d = row[3], row[5]
        if s in country and d in country and s != d:
            G.add_edge(s, d)
scc = max(nx.strongly_connected_components(G), key=len)
G = G.subgraph(scc).copy()
nodes = sorted(G.nodes())
idx = {v: i for i, v in enumerate(nodes)}
n = len(nodes)
print('SCC: %d аэропортов, %d рёбер' % (n, G.number_of_edges()))

A = sparse.lil_matrix((n, n))
for u, v in G.edges():
    A[idx[u], idx[v]] = 1.0
A = A.tocsr()
deg = np.asarray(A.sum(axis=1)).ravel()
P = sparse.diags(1.0 / deg) @ A
Plazy = 0.5 * (sparse.identity(n) + P)

def continent(a):
    t = tz.get(a, '')
    pre = t.split('/')[0] if '/' in t else ''
    return pre if pre in ('Africa', 'America', 'Asia', 'Atlantic',
                          'Australia', 'Europe', 'Indian', 'Pacific') else 'Other'
lab_country = np.array([country[v] for v in nodes])
lab_cont = np.array([continent(v) for v in nodes])
print('стран:', len(set(lab_country)), '| континент-классов:', len(set(lab_cont)))

# --- P-1: eps-lumpability (на P, средняя попарная TV, <=2000 пар/класс) ---
def eps_mean(Pm, labels):
    classes = sorted(set(labels))
    ci = {c: j for j, c in enumerate(classes)}
    M = sparse.lil_matrix((n, len(classes)))
    for i, l in enumerate(labels):
        M[i, ci[l]] = 1.0
    Agg = np.asarray((Pm @ M.tocsr()).todense())
    tot_w, tot = 0.0, 0.0
    for c in classes:
        ids = np.where(labels == c)[0]
        if len(ids) < 2: continue
        npairs = min(2000, len(ids) * (len(ids) - 1) // 2)
        a = rng.choice(ids, size=npairs); b = rng.choice(ids, size=npairs)
        ok = a != b
        if not ok.any(): continue
        d = 0.5 * np.abs(Agg[a[ok]] - Agg[b[ok]]).sum(axis=1).mean()
        tot += d * len(ids); tot_w += len(ids)
    return tot / tot_w

def null_eps(labels, reps=50):
    return [eps_mean(P, rng.permutation(labels)) for _ in range(reps)]

e_country = eps_mean(P, lab_country)
e_cont = eps_mean(P, lab_cont)
n_country = null_eps(lab_country); n_cont = null_eps(lab_cont)
P1 = e_country < min(n_country) and e_cont < min(n_cont)
print('eps(страны)=%.4f min(null)=%.4f | eps(конт)=%.4f min(null)=%.4f | P-1 %s'
      % (e_country, min(n_country), e_cont, min(n_cont), 'PASS' if P1 else 'FAIL'))

# --- стационарное распределение ---
pi = np.ones(n) / n
for _ in range(3000):
    pi = pi @ Plazy
    pi = np.asarray(pi).ravel(); pi /= pi.sum()

# --- P-2: топ-5 медленных левых мод P' vs континенты (ANOVA R^2) ---
vals, vecs = eigs(Plazy.T.tocsc(), k=8, which='LM', maxiter=5000, tol=1e-8)
order = np.argsort(-np.abs(vals))
vals, vecs = vals[order], vecs[:, order]
slow = [np.real(vecs[:, j]) for j in range(1, 6)]
def r2(v, labels):
    mu = v.mean(); sst = ((v - mu) ** 2).sum()
    ssw = sum(((v[labels == c] - v[labels == c].mean()) ** 2).sum()
              for c in set(labels))
    return 1 - ssw / sst
hits2 = 0; r2s = []
for v in slow:
    r = r2(v, lab_cont)
    nulls = [r2(v, rng.permutation(lab_cont)) for _ in range(200)]
    ok = r > np.percentile(nulls, 95)
    hits2 += ok; r2s.append((round(float(r), 3), bool(ok)))
P2 = hits2 >= 3
print('|lambda| top-8:', np.round(np.abs(vals), 4))
print('R2 мод 2-6 по континентам:', r2s, '| P-2', 'PASS' if P2 else 'FAIL')

# --- P-3: вложенные времена жизни зарядов ---
def tau_of(f, tmax=200):
    f = f - (pi * f).sum()
    c0 = (pi * f * f).sum()
    if c0 <= 0: return 0.0
    g = f.copy()
    for t in range(1, tmax + 1):
        g = np.asarray(Plazy @ g).ravel()
        if (pi * f * g).sum() / c0 < np.exp(-1):
            return float(t)
    return float(tmax)

tau_cont = [tau_of((lab_cont == c).astype(float))
            for c in set(lab_cont) if (lab_cont == c).sum() >= 5]
big = [c for c in set(lab_country) if (lab_country == c).sum() >= 10]
tau_country = [tau_of((lab_country == c).astype(float)) for c in big]
tau_rand = [tau_of(rng.standard_normal(n)) for _ in range(100)]
mc, mk, mr = np.median(tau_cont), np.median(tau_country), np.median(tau_rand)
P3 = mc > mk > mr
print('tau медианы: континенты=%.1f (n=%d) страны=%.1f (n=%d) случайные=%.1f | P-3 %s'
      % (mc, len(tau_cont), mk, len(tau_country), mr, 'PASS' if P3 else 'FAIL'))
print('tau континентов:', sorted(np.round(tau_cont, 1), reverse=True))
print('tau стран top-10:', sorted(np.round(tau_country, 1), reverse=True)[:10])

json.dump(dict(n=n, m=G.number_of_edges(),
               eps=dict(country=float(e_country), country_null_min=float(min(n_country)),
                        cont=float(e_cont), cont_null_min=float(min(n_cont)), P1=bool(P1)),
               spec=dict(lams=[float(x) for x in np.abs(vals)], r2=r2s, P2=bool(P2)),
               tau=dict(cont=float(mc), country=float(mk), rand=float(mr), P3=bool(P3),
                        tau_cont=[float(x) for x in tau_cont])),
          open('results_lev_002.json', 'w'), indent=1)
