# EXP-LEV-005: ядро Linux. Seed=42. Пререг: prereg_exp_lev_005.md
import json, time
import numpy as np, networkx as nx
from scipy import sparse
from scipy.sparse.linalg import eigs

rng = np.random.default_rng(42)
E = np.load('kernel_graph.npz')['edges']
nodes_all = json.load(open('kernel_nodes.json'))
G = nx.Graph()
G.add_nodes_from(range(len(nodes_all)))
G.add_edges_from(map(tuple, E))
G.remove_edges_from(nx.selfloop_edges(G))
cc = max(nx.connected_components(G), key=len)
G = G.subgraph(cc).copy()
keep = sorted(G.nodes())
paths = [nodes_all[i] for i in keep]
idx = {v: i for i, v in enumerate(keep)}
n = len(keep)
print('LCC: %d узлов, %d рёбер (неориент.)' % (n, G.number_of_edges()))

def L1(p): return p.split('/')[0]
def L2(p):
    parts = p.split('/')
    return '/'.join(parts[:2]) if len(parts) > 2 else parts[0]
lab1 = np.array([L1(p) for p in paths])
lab2 = np.array([L2(p) for p in paths])
hub = np.array([p.startswith('include/') or '/include/' in p for p in paths])
print('L1 классов: %d | L2 классов: %d | хаб-слой: %d узлов (%.1f%%)'
      % (len(set(lab1)), len(set(lab2)), hub.sum(), 100 * hub.mean()))

rows = np.array([idx[u] for u, v in G.edges()] + [idx[v] for u, v in G.edges()])
cols = np.array([idx[v] for u, v in G.edges()] + [idx[u] for u, v in G.edges()])
A = sparse.csr_matrix((np.ones(len(rows), np.float32), (rows, cols)), shape=(n, n))
deg = np.asarray(A.sum(axis=1)).ravel()
P = sparse.diags((1.0 / deg).astype(np.float32)) @ A
PL = (0.5 * (sparse.identity(n, dtype=np.float32) + P)).tocsr()

def eps_mean(labels, min_size=2):
    classes = sorted(set(labels)); ci = {c: j for j, c in enumerate(classes)}
    li = np.array([ci[l] for l in labels])
    M = sparse.csr_matrix((np.ones(n, np.float32), (np.arange(n), li)),
                          shape=(n, len(classes)))
    Agg = np.asarray((P @ M).todense())
    tw = tot = 0.0
    for c in classes:
        ids_ = np.where(labels == c)[0]
        if len(ids_) < max(2, min_size): continue
        npairs = min(2000, len(ids_) * (len(ids_) - 1) // 2)
        a = rng.choice(ids_, npairs); b = rng.choice(ids_, npairs); ok = a != b
        if not ok.any(): continue
        d = 0.5 * np.abs(Agg[a[ok]] - Agg[b[ok]]).sum(axis=1).mean()
        tot += d * len(ids_); tw += len(ids_)
    return tot / tw

def check(labels, min_size=2, reps=30):
    t0 = time.time()
    e = eps_mean(labels, min_size)
    nulls = np.array([eps_mean(rng.permutation(labels), min_size) for _ in range(reps)])
    return e, nulls, (e - nulls.mean()) / nulls.std(), time.time() - t0

e1, n1, D1, t1 = check(lab1)
e2, n2, D2, t2 = check(lab2, min_size=20)
PK1 = e1 < n1.min() and e2 < n2.min()
print('eps(L1)=%.4f min(null)=%.4f D=%.1f (%.0fs) | eps(L2)=%.4f min(null)=%.4f D=%.1f (%.0fs) | P-K1 %s'
      % (e1, n1.min(), D1, t1, e2, n2.min(), D2, t2, 'PASS' if PK1 else 'FAIL'))

pi = np.ones(n, np.float32) / n
for _ in range(2000):
    pi = np.asarray(pi @ PL).ravel(); pi /= pi.sum()

def tau_batch(F, tmax=200):
    F = F - (pi @ F)
    c0 = (pi[:, None] * F * F).sum(0)
    out = np.full(F.shape[1], float(tmax))
    Gm = F.copy()
    alive = np.ones(F.shape[1], bool)
    for t in range(1, tmax + 1):
        Gm = np.asarray(PL @ Gm)
        c = (pi[:, None] * F * Gm).sum(0)
        cross = alive & (c / np.maximum(c0, 1e-12) < np.exp(-1))
        out[cross] = t; alive &= ~cross
        if not alive.any(): break
    return out

def indicators(labels, min_size):
    cs = [c for c in sorted(set(labels)) if (labels == c).sum() >= min_size]
    F = np.stack([(labels == c).astype(np.float32) for c in cs], axis=1)
    return cs, F

cs1, F1 = indicators(lab1, 50)
cs2, F2 = indicators(lab2, 50)
tau1 = tau_batch(F1); tau2 = tau_batch(F2)
taur = tau_batch(rng.standard_normal((n, 50)).astype(np.float32))
m1_, m2_, mr_ = np.median(tau1), np.median(tau2), np.median(taur)
PK2 = m1_ > m2_ > mr_
print('tau медианы: L1=%.1f (n=%d) L2=%.1f (n=%d) случайные=%.1f | P-K2 %s'
      % (m1_, len(cs1), m2_, len(cs2), mr_, 'PASS' if PK2 else 'FAIL'))
print('tau L1:', sorted(zip(np.round(tau1, 1), cs1), reverse=True)[:12])

t0 = time.time()
bt = nx.betweenness_centrality(G, k=100, seed=42)
top200 = sorted(bt, key=bt.get, reverse=True)[:200]
share_all = hub.mean()
share_top = np.mean([hub[idx[v]] for v in top200])
enrich = share_top / share_all
PK3 = enrich >= 3
print('хаб-слой: доля узлов %.3f, доля в top-200 btw %.3f, обогащение x%.1f (%.0fs) | P-K3 %s'
      % (share_all, share_top, enrich, time.time() - t0, 'PASS' if PK3 else 'FAIL'))
top10 = [(paths[idx[v]], round(bt[v], 4)) for v in top200[:10]]
print('top-10 btw:', top10)

vals, vecs = eigs(PL.T.tocsc(), k=8, which='LM', maxiter=8000, tol=1e-7)
order = np.argsort(-np.abs(vals)); vals, vecs = vals[order], vecs[:, order]
uc, li1 = np.unique(lab1, return_inverse=True)
def r2(v):
    mu = v.mean(); sst = ((v - mu) ** 2).sum()
    cnt = np.bincount(li1); s = np.bincount(li1, weights=v)
    ssb = ((s ** 2) / np.maximum(cnt, 1)).sum() - len(v) * mu ** 2
    return ssb / sst
hits, r2s = 0, []
for j in range(1, 6):
    v = np.real(vecs[:, j]); r = r2(v)
    nulls = []
    for _ in range(200):
        rng.shuffle(li1); nulls.append(r2(v))
    uc, li1 = np.unique(lab1, return_inverse=True)
    ok = r > np.percentile(nulls, 95); hits += ok; r2s.append((round(float(r), 3), bool(ok)))
PK4 = hits >= 3
print('|lambda| top-8:', np.round(np.abs(vals), 4))
print('R2 мод 2-6 по L1:', r2s, '| P-K4', 'PASS' if PK4 else 'FAIL')

# P-K5: удаление хаб-слоя
keep2 = [i for i in range(n) if not hub[i]]
G2 = G.subgraph([keep[i] for i in keep2]).copy()
cc2 = max(nx.connected_components(G2), key=len)
G2 = G2.subgraph(cc2).copy()
keep2n = sorted(G2.nodes())
paths2 = [nodes_all[i] for i in keep2n]
n2_ = len(keep2n)
lab1b = np.array([L1(p) for p in paths2])
idx2 = {v: i for i, v in enumerate(keep2n)}
rows2 = np.array([idx2[u] for u, v in G2.edges()] + [idx2[v] for u, v in G2.edges()])
cols2 = np.array([idx2[v] for u, v in G2.edges()] + [idx2[u] for u, v in G2.edges()])
A2 = sparse.csr_matrix((np.ones(len(rows2), np.float32), (rows2, cols2)), shape=(n2_, n2_))
deg2 = np.asarray(A2.sum(axis=1)).ravel()
P2 = sparse.diags((1.0 / deg2).astype(np.float32)) @ A2
PL2 = (0.5 * (sparse.identity(n2_, dtype=np.float32) + P2)).tocsr()
pi2 = np.ones(n2_, np.float32) / n2_
for _ in range(2000):
    pi2 = np.asarray(pi2 @ PL2).ravel(); pi2 /= pi2.sum()
def tau_batch2(F, tmax=200):
    F = F - (pi2 @ F); c0 = (pi2[:, None] * F * F).sum(0)
    out = np.full(F.shape[1], float(tmax)); Gm = F.copy(); alive = np.ones(F.shape[1], bool)
    for t in range(1, tmax + 1):
        Gm = np.asarray(PL2 @ Gm); c = (pi2[:, None] * F * Gm).sum(0)
        cross = alive & (c / np.maximum(c0, 1e-12) < np.exp(-1))
        out[cross] = t; alive &= ~cross
        if not alive.any(): break
    return out
csb = [c for c in sorted(set(lab1b)) if (lab1b == c).sum() >= 50 and c in cs1]
Fb = np.stack([(lab1b == c).astype(np.float32) for c in csb], axis=1)
taub = tau_batch2(Fb)
match = [cs1.index(c) for c in csb]
before = np.median(tau1[match]); after = np.median(taub)
PK5 = after > before
print('LCC без хаб-слоя: %d узлов | tau(L1) медиана до=%.1f после=%.1f (классов %d) | P-K5 %s'
      % (n2_, before, after, len(csb), 'PASS' if PK5 else 'FAIL'))
pairs = sorted(zip(csb, tau1[match], taub), key=lambda x: -(x[2] - x[1]))
print('до/после по классам:', [(c, float(a), float(b)) for c, a, b in pairs[:10]])

json.dump(dict(n=n, m=G.number_of_edges(),
               eps=dict(L1=float(e1), L1_null_min=float(n1.min()), D1=float(D1),
                        L2=float(e2), L2_null_min=float(n2.min()), D2=float(D2), PK1=bool(PK1)),
               tau=dict(L1=float(m1_), L2=float(m2_), rand=float(mr_), PK2=bool(PK2)),
               hublayer=dict(share=float(share_all), top200=float(share_top),
                             enrich=float(enrich), PK3=bool(PK3), top10=top10),
               spec=dict(lams=[float(x) for x in np.abs(vals)], r2=r2s, PK4=bool(PK4)),
               removal=dict(before=float(before), after=float(after), PK5=bool(PK5))),
          open('results_lev_005.json', 'w'), indent=1)
