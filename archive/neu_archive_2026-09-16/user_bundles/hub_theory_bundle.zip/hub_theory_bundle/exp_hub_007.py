# EXP-HUB-007: S. cerevisiae iND750. Seed=42. Пререг: prereg_exp_hub_007.md
import json
import xml.etree.ElementTree as ET
import numpy as np, networkx as nx
from scipy.sparse.linalg import eigsh

COMP = ['_c', '_e', '_m', '_x', '_n', '_r', '_g', '_v', '_p']
T1B = ['h', 'h2o', 'atp', 'adp', 'amp', 'pi', 'ppi', 'nad', 'nadh', 'nadp',
       'nadph', 'co2', 'o2', 'nh4', 'q6', 'q6h2', 'fad', 'fadh2']
T2B = ['glu_DASH_L', 'gln_DASH_L', 'ser_DASH_L', 'gly', 'thf', 'mlthf',
       '10fthf', '5mthf', 'amet', 'ahcys', 'coa', 'acp']
CARB = ['pyr', 'accoa', 'oaa', 'akg']
GLYC = ['g6p', 'f6p', 'fdp', 'g3p', 'dhap', '13dpg', '3pg', '2pg', 'pep', 'pyr']
T1 = {b + c for b in T1B for c in COMP}
T2 = {b + c for b in T2B for c in COMP}
CARBSET = {b + c for b in CARB for c in COMP}
GLYCSET = {b + c for b in GLYC for c in COMP}

def load_sbml(path):
    root = ET.fromstring(open(path, 'rb').read())
    ns = {'s': root.tag.split('}')[0].strip('{')}
    model = root.find('s:model', ns)
    mets = {sp.get('id') for sp in model.find('s:listOfSpecies', ns)
            if sp.get('boundaryCondition') != 'true'}
    G = nx.DiGraph()
    for rx in model.find('s:listOfReactions', ns):
        rid = (rx.get('id') or '').upper()
        if 'EX_' in rid or 'BIOMASS' in rid: continue
        rev = rx.get('reversible') == 'true'
        lr = rx.find('s:listOfReactants', ns); lp = rx.find('s:listOfProducts', ns)
        R = [x.get('species') for x in lr] if lr is not None else []
        P = [x.get('species') for x in lp] if lp is not None else []
        for a in R:
            for b in P:
                if a in mets and b in mets and a != b:
                    G.add_edge(a, b)
                    if rev: G.add_edge(b, a)
    return nx.relabel_nodes(G, {n: (n[2:] if n.startswith('M_') else n) for n in G.nodes()})

def crystal_fast(U):
    C = U.subgraph(max(nx.connected_components(U), key=len))
    if C.number_of_nodes() < 3: return None
    A = nx.to_scipy_sparse_array(C, dtype=float)
    try:
        ev = np.sort(eigsh(A, k=2, which='LA', return_eigenvectors=False,
                           maxiter=3000))[::-1]
    except Exception:
        ev = np.sort(np.linalg.eigvalsh(A.todense()))[::-1][:2]
    return float(ev[1] / ev[0]) if ev[0] > 0 else None

def btw_top(G):
    b = nx.betweenness_centrality(G)
    items = sorted(b.items(), key=lambda kv: -kv[1])
    return items

G = load_sbml('iND750.xml')
n = G.number_of_nodes()
t1 = sorted(set(G) & T1); t2 = sorted(set(G) & T2)
print('узлов %d, рёбер %d | ярус-1 в графе: %d, ярус-2: %d (эталон всего %d, %.2f)'
      % (n, G.number_of_edges(), len(t1), len(t2), len(t1) + len(t2),
         (len(t1) + len(t2)) / n))

items = btw_top(G)
top10 = [k for k, _ in items[:10]]
P71n = sum(1 for k in top10 if k in T1)
print('top-10:', top10)
print('P7.1: ярус-1 в top-10 =', P71n, '->', 'PASS' if P71n >= 6 else 'FAIL')

G12 = G.copy(); G12.remove_nodes_from(t1 + t2)
G12 = G12.subgraph(max(nx.weakly_connected_components(G12), key=len)).copy()
items12 = btw_top(G12)
top3 = [k for k, _ in items12[:3]]
top10b = [k for k, _ in items12[:10]]
P72n = sum(1 for k in top3 if k in CARBSET | GLYCSET)
print('top-10 после ярусов 1+2:', top10b)
print('P7.2: из КАРКАС∪ГЛИКОЛИЗ в top-3 =', P72n, '->', 'PASS' if P72n >= 2 else 'FAIL')
mito = [k for k in top10b if k in CARBSET and k.endswith('_m')]
cyto = [k for k in top10b if k in (CARBSET | GLYCSET) and k.endswith('_c')]
P73 = bool(mito) and bool(cyto)
print('P7.3: митохондриальные в top-10:', mito, '| цитозольные:', cyto, '->',
      'PASS' if P73 else 'FAIL')

Gu = nx.Graph(G); Gu.remove_nodes_from(t1)
R6 = len(max(nx.connected_components(Gu), key=len)) / n if Gu.number_of_edges() else 0
print('P7.6: retention после яруса-1 = %.3f ->' % R6, 'PASS' if R6 >= 0.5 else 'FAIL')

# детектор с правилом остановки
Gd = nx.Graph(G)
removed, prev, streak = [], crystal_fast(Gd), 0
for step in range(25):
    best, bestm = None, -2.0
    for v in list(Gd.nodes()):
        H = Gd.copy(); H.remove_node(v)
        if H.number_of_nodes() < 3 or H.number_of_edges() == 0: continue
        mm = crystal_fast(H)
        if mm is not None and mm > bestm:
            bestm, best = mm, v
    gain = bestm - prev
    Gd.remove_node(best); removed.append(best)
    streak = streak + 1 if gain < 0.01 else 0
    prev = bestm
    if streak >= 2:
        removed = removed[:-2] if len(removed) >= 2 else []
        break
GT = set(t1) | set(t2)
hits = [r for r in removed if r in GT]
prec = len(hits) / len(removed) if removed else 0.0
print('P7.4: шагов %d, точность %d/%d = %.2f ->' % (len(removed), len(hits),
      len(removed), prec), 'PASS' if prec >= 0.70 else 'FAIL')
print('удалено:', removed)
pos1 = [i for i, r in enumerate(removed) if r in T1]
pos2 = [i for i, r in enumerate(removed) if r in T2]
if pos1 and pos2:
    P75 = np.median(pos1) < np.median(pos2)
    print('P7.5: медианные позиции ярус-1=%.1f ярус-2=%.1f ->' %
          (np.median(pos1), np.median(pos2)), 'PASS' if P75 else 'FAIL')
else:
    P75 = None
    print('P7.5: неопределено (одна из групп пуста): t1=%s t2=%s' % (pos1, pos2))

json.dump(dict(n=n, m=G.number_of_edges(), top10=top10, P71=P71n,
               top10_after=top10b, P72=P72n, mito=mito, cyto=cyto,
               P73=bool(P73), R=float(R6),
               detector=dict(removed=removed, prec=float(prec)),
               P75=(bool(P75) if P75 is not None else None)),
          open('results_hub_007.json', 'w'), indent=1, ensure_ascii=False)
