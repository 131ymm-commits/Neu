# EXP-SELF-001: бинокулярность инструментов. Пререг: prereg_exp_self_001.md
import json, itertools
import numpy as np, networkx as nx
from networkx.generators.atlas import graph_atlas_g
from collections import Counter
from scipy.stats import spearmanr

rng = np.random.default_rng(42)
Gs = [g for g in graph_atlas_g() if g.number_of_nodes() == 7 and nx.is_connected(g)]
N = len(Gs)
print('графов: %d' % N)

def observables(G):
    A = nx.to_numpy_array(G)
    ev = np.linalg.eigvalsh(A)
    aev = np.sort(np.abs(ev))[::-1]
    L = nx.laplacian_matrix(G).todense()
    lev = np.sort(np.linalg.eigvalsh(L))
    w, V = np.linalg.eigh(A); p = np.abs(V[:, -1]); p = p/p.sum()
    neff = np.exp(-(p*np.log(np.maximum(p, 1e-15))).sum())/len(p)
    bt = nx.betweenness_centrality(G); s = sum(bt.values())
    sp = dict(nx.all_pairs_shortest_path_length(G))
    dists = [d for u in sp for v, d in sp[u].items() if u != v]
    deg = np.array([d for _, d in G.degree()], float)
    return dict(
        lam1=aev[0], ratio=aev[1]/aev[0], ndist=len(set(np.round(ev, 6))),
        energy=np.abs(ev).sum(), fiedler=lev[1], neff=neff,
        diam=max(dists), mpl=np.mean(dists), topbtw=(max(bt.values())/s if s > 0 else 0.0),
        edges=G.number_of_edges(), tri=sum(nx.triangles(G).values())/3,
        clust=nx.average_clustering(G), degvar=deg.var())

OBS = [observables(g) for g in Gs]
names = list(OBS[0].keys())
FAM = dict(lam1='S', ratio='S', ndist='S', energy='S', fiedler='S', neff='S',
           diam='P', mpl='P', topbtw='P',
           edges='L', tri='L', clust='L', degvar='L')
M = {k: np.array([o[k] for o in OBS], float) for k in names}

def unres(keys):
    c = Counter(keys)
    return sum(v for v in c.values() if v >= 2)/N

def frac_for(subset, rnd=4):
    cols = [np.round(M[k], rnd) for k in subset]
    return unres(list(zip(*cols)))

# P-S1: зависимость от числа мер
print('\nk   медиана неразличённых   минимум   максимум')
kstar = None
for k in range(1, 5):
    subs = list(itertools.combinations(names, k))
    if len(subs) > 400:
        idx = rng.choice(len(subs), 400, replace=False); subs = [subs[i] for i in idx]
    vals = [frac_for(s) for s in subs]
    med = float(np.median(vals))
    print('%-3d %-22.4f %-9.4f %.4f' % (k, med, min(vals), max(vals)))
    if kstar is None and med < 0.01: kstar = k
PS1 = kstar is not None and abs(kstar - 3) <= 1
print('P-S1: k* = %s | регистр. 3 ± 1 -> %s' % (kstar, 'ПОПАЛ' if PS1 else 'МИМО'))

# P-S2: закон базы
homo, hetero = [], []
pair_info = []
for a, b in itertools.combinations(names, 2):
    f = frac_for((a, b))
    r = abs(spearmanr(M[a], M[b])[0])
    pair_info.append((a, b, f, r))
    (homo if FAM[a] == FAM[b] else hetero).append(f)
mh, mt = float(np.median(homo)), float(np.median(hetero))
ratio = mh/mt if mt > 0 else float('inf')
PS2 = ratio >= 2 and abs(ratio - 3) <= 2.5
print('\nP-S2: медиана неразличённых — однородные пары %.4f (n=%d), разнородные %.4f (n=%d)'
      % (mh, len(homo), mt, len(hetero)))
print('      отношение %.2f× | регистр. 3 ± 2.5 и ≥2 -> %s' % (ratio, 'PASS' if PS2 else 'FAIL'))

# P-S3: база = декорреляция
rs = [r for _, _, _, r in pair_info]; fs = [f for _, _, f, _ in pair_info]
rho, p = spearmanr(rs, fs)
PS3 = rho > 0.3 and abs(rho - 0.5) <= 0.3
print('\nP-S3: Спирмен(|корреляция пары|, доля неразличённых) = %+.3f (p=%.1e) | регистр. 0.5 ± 0.3 -> %s'
      % (rho, p, 'PASS' if PS3 else 'FAIL'))
best = sorted(pair_info, key=lambda x: x[2])[:3]
worst = sorted(pair_info, key=lambda x: -x[2])[:3]
print('      лучшие пары:', [(a, b, round(f, 4), round(r, 2)) for a, b, f, r in best])
print('      худшие пары:', [(a, b, round(f, 4), round(r, 2)) for a, b, f, r in worst])

# P-S4: самоприменение — наша тройка среди всех троек
triples = list(itertools.combinations(names, 3))
tv = [(t, frac_for(t)) for t in triples]
ours = ('ratio', 'neff', 'topbtw')
f_ours = frac_for(ours)
rank = sum(1 for _, f in tv if f < f_ours)
pct = rank/len(tv)
def disparity(t):
    return float(np.mean([1 - abs(spearmanr(M[a], M[b])[0]) for a, b in itertools.combinations(t, 2)]))
d_ours = disparity(ours)
d_all = [disparity(t) for t, _ in tv]
PS4 = pct <= 0.10 and d_ours > np.median(d_all)
print('\nP-S4: наша тройка: неразличённых %.4f | лучше неё только %.1f%% троек | разнесённость %.3f (медиана %.3f) -> %s'
      % (f_ours, 100*pct, d_ours, float(np.median(d_all)), 'PASS' if PS4 else 'FAIL'))
json.dump(dict(kstar=kstar, PS1=bool(PS1), homo=mh, hetero=mt, ratio=float(ratio),
               PS2=bool(PS2), rho=float(rho), PS3=bool(PS3),
               f_ours=f_ours, pct=float(pct), disp_ours=d_ours,
               disp_med=float(np.median(d_all)), PS4=bool(PS4)),
          open('results_self_001.json','w'), indent=1, default=float)
