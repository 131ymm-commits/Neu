# EXP-LEV-001: уровни как спектр + ε-lumpability. Seed=42.
# ПРЕРЕГИСТРАЦИЯ (до запуска): T = 0.95*(0.55*P3 + 0.30*P9 + 0.15*P27) + 0.05*R,
# 27 состояний = 3 блока x 3 блока x 3.
# P-L1: две крупнейшие мультипликативные щели |l_k|/|l_{k+1}| на позициях k=3 и k=9
#       (среди k=2..10), обе >= 1.25.
# P-L2: eps(истинное 3-разбиение) < min по 100 случайным сбалансированным 3-разбиениям;
#       то же для 9-разбиения против 50 случайных.
# P-L3 (дескриптивно): времена жизни зарядов tau=-1/ln|l| по кластерам — плато.
import numpy as np, json
rng = np.random.default_rng(42)
n = 27
def block_uniform(size):
    P = np.zeros((n, n))
    for s in range(0, n, size):
        P[s:s+size, s:s+size] = 1.0 / size
    return P
P3, P9, P27 = block_uniform(3), block_uniform(9), block_uniform(27)
R = rng.dirichlet(np.ones(n), size=n)
T = 0.95 * (0.55 * P3 + 0.30 * P9 + 0.15 * P27) + 0.05 * R

ev = np.linalg.eigvals(T)
mag = np.sort(np.abs(ev))[::-1]
ratios = {k: mag[k-1] / mag[k] for k in range(2, 11)}
top2 = sorted(ratios, key=lambda k: -ratios[k])[:2]
print('|lambda| top-12:', np.round(mag[:12], 4))
print('щели k=2..10:', {k: round(v, 2) for k, v in ratios.items()})
print('две крупнейшие щели на позициях:', sorted(top2),
      '| значения: %.2f, %.2f' % (ratios[top2[0]], ratios[top2[1]]))
PL1 = sorted(top2) == [3, 9] and all(ratios[k] >= 1.25 for k in top2)
print('P-L1:', 'PASS' if PL1 else 'FAIL')

def eps_lump(T, labels):
    k = len(set(labels)); L = np.array(labels)
    agg = np.zeros((n, k))
    for c in range(k):
        agg[:, c] = T[:, L == c].sum(axis=1)
    e = 0.0
    for c in range(k):
        idx = np.where(L == c)[0]
        for a in idx:
            for b in idx:
                e = max(e, 0.5 * np.abs(agg[a] - agg[b]).sum())
    return e

true3 = [i // 9 for i in range(n)]
true9 = [i // 3 for i in range(n)]
e3, e9 = eps_lump(T, true3), eps_lump(T, true9)
r3 = [eps_lump(T, list(rng.permutation(true3))) for _ in range(100)]
r9 = [eps_lump(T, list(rng.permutation(true9))) for _ in range(50)]
print('eps(true3)=%.4f  min(random)=%.4f | eps(true9)=%.4f  min(random)=%.4f'
      % (e3, min(r3), e9, min(r9)))
PL2 = e3 < min(r3) and e9 < min(r9)
print('P-L2:', 'PASS' if PL2 else 'FAIL')

tau = -1.0 / np.log(np.clip(mag[1:12], 1e-9, 0.999999))
print('tau (заряды, кластерами):', np.round(tau, 2))
json.dump(dict(mag=[float(x) for x in mag[:12]], gaps={str(k): float(v) for k, v in ratios.items()},
               PL1=bool(PL1), eps_true3=float(e3), eps_rand3_min=float(min(r3)),
               eps_true9=float(e9), eps_rand9_min=float(min(r9)), PL2=bool(PL2),
               tau=[float(x) for x in tau]),
          open('results_lev_001.json', 'w'), indent=1)
