# EXP-Q-001: нулевая энтропия как эксергетическая маршрутизация. Seed=42.
# Провенанс: [S] - поиск с цитатой (LED WPE>90 blue; PV 47.6% Fraunhofer 4J;
# SOEC 88-93% LHV; TPV 41.1%@2673K, 44%@1708K), [H] - инженерный справочник.
import json, itertools
import numpy as np

rng = np.random.default_rng(42)
F = ['chem', 'therm_hi', 'therm_lo', 'mech', 'elec', 'light', 'nucl', 'grav', 'elast']
q = dict(chem=0.95, therm_hi=0.669, therm_lo=0.149, mech=1.0, elec=1.0,
         light=0.93, nucl=1.0, grav=1.0, elast=1.0)
ETA = {
 ('chem','therm_hi'):(0.97,'H'), ('chem','elec'):(0.64,'H'), ('chem','mech'):(0.55,'H'),
 ('therm_hi','mech'):(0.50,'H'), ('therm_hi','elec'):(0.48,'H'),
 ('therm_hi','therm_lo'):(1.0,'H'), ('therm_hi','light'):(0.05,'H'),
 ('therm_lo','mech'):(0.10,'H'), ('therm_lo','elec'):(0.09,'H'),
 ('mech','elec'):(0.985,'H'), ('mech','therm_lo'):(1.0,'H'),
 ('mech','grav'):(0.90,'H'), ('mech','elast'):(0.95,'H'),
 ('elec','mech'):(0.97,'H'), ('elec','therm_hi'):(1.0,'H'),
 ('elec','therm_lo'):(4.0,'H'), ('elec','light'):(0.90,'S'),
 ('elec','chem'):(0.90,'S'),
 ('light','elec'):(0.476,'S'), ('light','therm_hi'):(0.65,'H'),
 ('light','therm_lo'):(0.95,'H'), ('light','chem'):(0.19,'H*'),
 ('nucl','therm_hi'):(0.99,'H'),
 ('grav','mech'):(0.92,'H'), ('elast','mech'):(0.97,'H'),
}
BONUS = [('therm@1708K','elec',0.44,1-298/1708,1.0,'S'),
         ('therm@2673K','elec',0.411,1-298/2673,1.0,'S')]

def z1(eta):
    viol = []
    for (i,j),(e,_) in eta.items():
        if e > 1.05 * q[i]/q[j]:
            viol.append((i,j,e,q[i]/q[j]))
    for nm,j,e,qi,qj,_ in BONUS:
        if e > 1.05*qi/qj: viol.append((nm,j,e,qi/qj))
    return viol

def scores(eta):
    n = len(F); idx = {f:i for i,f in enumerate(F)}
    B = np.zeros((n,n))
    for (i,j),(e,_) in eta.items():
        B[idx[i],idx[j]] = e*q[j]/q[i]
    P = B.copy()
    for k in range(n):
        for a in range(n):
            for b in range(n):
                if P[a,k]*P[k,b] > P[a,b]:
                    P[a,b] = P[a,k]*P[k,b]
    S = {}
    for h in F:
        hh = idx[h]; logs = []
        for a,b in itertools.permutations(range(n),2):
            if a==hh or b==hh or P[a,b]<=0: continue
            th = P[a,hh]*P[hh,b]
            if th<=0: continue
            logs.append(np.log(min(1.0, th/P[a,b])))
        S[h] = float(np.exp(np.mean(logs))) if logs else None
    return S, P

viol = z1(ETA)
print('Z1: нарушений границы eta <= 1.05*q_i/q_j:', len(viol), viol or 'PASS')
S, P = scores(ETA)
rank = sorted([(v,k) for k,v in S.items() if v is not None], reverse=True)
print('Хаб-счёт S (эксергетическая маршрутизация):')
for v,k in rank: print('  %-9s %.3f  (q=%.3f)' % (k, v, q[k]))
Z2a = rank[0][1] in ('elec','mech')
Z2b = S['elec'] > S['therm_hi']
Z2c = rank[-1][1] == 'therm_lo'
print('Z2a (топ - форма q=1):', 'PASS' if Z2a else 'FAIL',
      '| Z2b (elec > therm_hi):', 'PASS' if Z2b else 'FAIL',
      '| Z2c (низ - therm_lo):', 'PASS' if Z2c else 'FAIL')
from scipy.stats import spearmanr
forms3 = [f for f in F if S.get(f) is not None]
rho,_ = spearmanr([q[f] for f in forms3], [S[f] for f in forms3])
print('Z3: Спирмен(q,S) по %d формам = %.3f ->' % (len(forms3), rho),
      'PASS' if rho >= 0.8 else 'FAIL')
ok = 0
for _ in range(200):
    eta2 = {k:(v*rng.uniform(0.9,1.1), t) for k,(v,t) in ETA.items()}
    S2,_ = scores(eta2)
    ok += S2['elec'] > S2['therm_hi']
print('Z4: Z2b держится в %d/200 возмущений ->' % ok, 'PASS' if ok >= 190 else 'FAIL')
# энергетическая (не эксергетическая) версия - вторично, для контраста
qE = {f:1.0 for f in F}
qsave = dict(q); q.update(qE)
SE,_ = scores(ETA)
q.update(qsave)
rankE = sorted([(v,k) for k,v in SE.items() if v is not None], reverse=True)
print('Контраст, энергетическая метрика:', [(k, round(v,3)) for v,k in rankE[:4]])
json.dump(dict(S=S, SE=SE, rank=[k for _,k in rank], z1_viol=len(viol),
               Z2a=bool(Z2a), Z2b=bool(Z2b), Z2c=bool(Z2c),
               rho=float(rho), mc=int(ok)),
          open('results_q_001.json','w'), indent=1, ensure_ascii=False)
