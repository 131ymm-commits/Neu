# EXP-COL-001: Коллатц. Пререг: prereg_exp_col_001.md
import json
import numpy as np

rng = np.random.default_rng(42)

def parity_vector(n, k):
    p = []
    for _ in range(k):
        p.append(n & 1)
        n = (3*n+1)//2 if (n & 1) else n//2
    return tuple(p)

# P-C1: разбиение по модулю 2^k — точный уровень
bad = 0
for k in range(1, 13):
    for _ in range(200):
        n = int(rng.integers(1, 10**6))
        if parity_vector(n, k) != parity_vector(n + 2**k, k): bad += 1
PC1 = bad == 0
print('P-C1: расхождений вектора чётностей при сдвиге на 2^k: %d (k = 1…12) -> %s'
      % (bad, 'PASS (ε = 0 ровно)' if PC1 else 'FAIL'))

# P-C2: статистический дрейф
drifts = []
for _ in range(4000):
    n = int(rng.integers(10**6, 10**9))
    steps, l0 = 0, np.log(n)
    for _ in range(300):
        if n == 1: break
        n = (3*n+1)//2 if (n & 1) else n//2
        steps += 1
    if steps > 50 and n > 1:
        drifts.append((np.log(n) - l0)/steps)
d = float(np.mean(drifts))
theo = 0.5*np.log(3/4)
PC2 = abs(d - theo) <= 0.005
print('P-C2: измеренный дрейф log n за шаг = %.4f | теория ½·log(3/4) = %.4f -> %s'
      % (d, theo, 'ПОПАЛ' if PC2 else 'МИМО'))

# P-C3: поиск поточечного монотона по ярусам
print('\nдоля классов с ростом (множитель 3^a/2^k > 1):')
print('  k     классов      «плохих»     доля')
ks, fracs = [], []
for k in range(4, 23):
    n = np.arange(2**k, dtype=np.int64)
    cur = n.copy(); a = np.zeros(2**k, dtype=np.int32)
    for _ in range(k):
        odd = (cur & 1).astype(bool)
        a += odd
        cur = np.where(odd, (3*cur+1)//2, cur//2)
    logmul = a*np.log(3) - k*np.log(2)
    f = float((logmul > 0).mean())
    ks.append(k); fracs.append(f)
    if k <= 12 or k % 4 == 0:
        print('  %-5d %-12d %-12d %.6f' % (k, 2**k, int((logmul > 0).sum()), f))
ks = np.array(ks); fr = np.array(fracs)
m = fr > 0
rate = -np.polyfit(ks[m], np.log(fr[m]), 1)[0]
p = np.log(2)/np.log(3)
I = p*np.log(2*p) + (1-p)*np.log(2*(1-p))
PC3 = abs(rate - 0.0348) <= 0.008
print('\nP-C3: измеренный показатель убывания = %.4f на ярус | теория больших уклонений %.4f -> %s'
      % (rate, I, 'ПОПАЛ' if PC3 else 'МИМО'))

# P-C4: сколько ярусов до 1e-6
kstar = np.log(1e-6/fr[0])/(-rate) + ks[0]
PC4 = abs(kstar - 400) <= 150
print('P-C4: ярусов до доли 10⁻⁶: k* = %.0f | регистр. 400 ± 150 -> %s'
      % (kstar, 'ПОПАЛ' if PC4 else 'МИМО'))
print('      (при p = log2/log3 = %.5f — доле нечётных шагов, выше которой траектория растёт)' % p)
json.dump(dict(PC1=bool(PC1), drift=d, theo=theo, PC2=bool(PC2),
               ks=ks.tolist(), fracs=fr.tolist(), rate=float(rate), LD=float(I),
               PC3=bool(PC3), kstar=float(kstar), PC4=bool(PC4)),
          open('results_col_001.json','w'), indent=1)
