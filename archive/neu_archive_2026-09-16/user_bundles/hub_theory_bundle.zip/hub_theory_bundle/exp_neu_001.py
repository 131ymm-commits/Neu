# EXP-NEU-001. Seed=42. Пререг: prereg_exp_neu_001.md
import json, re
import numpy as np, networkx as nx
import xml.etree.ElementTree as ET
rng = np.random.default_rng(42)

T1B=['h','h2o','atp','adp','amp','pi','ppi','nad','nadh','nadp','nadph','co2','o2','nh4','fad','fadh2']
QUIN=re.compile(r'^(q\d+|q\d+h2|mqn\d+|mql\d+)$')
SCAF=['g6p','f6p','r5p','e4p','g3p','3pg','pep','pyr','accoa','akg','succoa','oaa']
NEURO=['glu_dash_l','gly','4abut','ser_dash_l','asp_dash_l','ach','hista','dopa','srtn',
       'tyr_dash_l','trp_dash_l','his_dash_l','arg_dash_l','chol','5htp','dhap_no','nh4no']
def base(n):
    low=n.lower(); i=low.rfind('_')
    return low[:i] if i>0 else low
def is_t1(n):
    b=base(n); return b in T1B or bool(QUIN.match(b))
def load(path):
    root=ET.fromstring(open(path,'rb').read()); ns={'s':root.tag.split('}')[0].strip('{')}
    mo=root.find('s:model',ns)
    mets={sp.get('id') for sp in mo.find('s:listOfSpecies',ns) if sp.get('boundaryCondition')!='true'}
    G=nx.DiGraph()
    for rx in mo.find('s:listOfReactions',ns):
        rid=(rx.get('id') or '').upper()
        if 'EX_' in rid or 'BIOMASS' in rid: continue
        rev=rx.get('reversible')=='true'
        lr=rx.find('s:listOfReactants',ns); lp=rx.find('s:listOfProducts',ns)
        R=[x.get('species') for x in lr] if lr is not None else []
        P=[x.get('species') for x in lp] if lp is not None else []
        for a in R:
            for b in P:
                if a in mets and b in mets and a!=b:
                    G.add_edge(a,b)
                    if rev: G.add_edge(b,a)
    return nx.relabel_nodes(G,{n:(n[2:] if n.startswith('M_') else n) for n in G.nodes()})

def reach(G, src):
    seen=set()
    for s in src:
        if s in G: seen |= nx.descendants(G,s) | {s}
    return seen

RES={}
for name,path in [('iND750','iND750.xml'),('iNJ661','iNJ661.xml'),
                  ('iIT341','iIT341.xml'),('iAF692','iAF692.xml')]:
    G=load(path)
    H=G.copy(); H.remove_nodes_from([v for v in G if is_t1(v)])
    H=H.subgraph(max(nx.weakly_connected_components(H),key=len)).copy()
    src=[v for v in H if base(v) in SCAF]
    base_reach=len(reach(H,src))
    bt=nx.betweenness_centrality(H,k=min(250,H.number_of_nodes()),seed=42)
    order=sorted(bt,key=bt.get,reverse=True); rank={v:i+1 for i,v in enumerate(order)}
    def kappa(v):
        Hv=H.copy(); Hv.remove_node(v)
        s2=[x for x in src if x!=v]
        return 1-len(reach(Hv,s2))/max(base_reach,1)
    neuro=[v for v in H if base(v) in NEURO]
    t1=[v for v in G if is_t1(v) and v in G]      # ярус-1 меряем в ПОЛНОМ графе
    # κ яруса-1 считаем на полном графе тем же способом
    srcF=[v for v in G if base(v) in SCAF]; bf=len(reach(G,srcF))
    def kappaF(v):
        Gv=G.copy(); Gv.remove_node(v)
        return 1-len(reach(Gv,[x for x in srcF if x!=v]))/max(bf,1)
    k_neuro=[kappa(v) for v in neuro]
    k_t1=[kappaF(v) for v in t1[:40]]
    others=[v for v in H if v not in neuro and base(v) not in SCAF]
    # контроль: случайные с той же доступностью
    nr=[rank[v] for v in neuro]
    ctrl=[]
    for r in nr:
        cand=[v for v in others if abs(rank[v]-r)<=max(5,int(0.05*len(order)))]
        if cand: ctrl.append(cand[rng.integers(len(cand))])
    k_ctrl=[kappa(v) for v in set(ctrl)]
    rnd=[rank[v] for v in rng.choice(others,min(200,len(others)),replace=False)]
    RES[name]=dict(n_neuro=len(neuro), neuro=[base(v) for v in neuro],
                   med_rank_neuro=float(np.median(nr)), med_rank_rnd=float(np.median(rnd)),
                   k_neuro=float(np.median(k_neuro)), k_t1=float(np.median(k_t1)),
                   k_ctrl=float(np.median(k_ctrl)) if k_ctrl else None)
    r=RES[name]
    print('%-8s нейро %2d | ранг: нейро %5.0f против случайных %5.0f | κ: нейро %.4f, ярус-1 %.4f, контроль %s'
          % (name, r['n_neuro'], r['med_rank_neuro'], r['med_rank_rnd'], r['k_neuro'], r['k_t1'],
             ('%.4f'%r['k_ctrl']) if r['k_ctrl'] is not None else 'н/д'))
    print('         найдены: %s' % sorted(set(r['neuro'])))

ok1=sum(1 for r in RES.values() if r['med_rank_neuro']<r['med_rank_rnd'])
ok2=sum(1 for r in RES.values() if r['k_neuro']<r['k_t1'])
ratios=[r['k_t1']/max(r['k_neuro'],1e-9) for r in RES.values()]
ctrl_ratios=[r['k_ctrl']/max(r['k_neuro'],1e-9) for r in RES.values() if r['k_ctrl'] is not None]
PN1=ok1>=3; PN2=ok2>=3; PN3=np.median(ratios)>=3; PN4=(len(ctrl_ratios)>0 and np.median(ctrl_ratios)>=2)
print('\nP-N1 (доступность): %d/4 -> %s' % (ok1,'PASS' if PN1 else 'FAIL'))
print('P-N2 (некритичность): %d/4 -> %s' % (ok2,'PASS' if PN2 else 'FAIL'))
print('P-N3 (κ ярус-1 / κ нейро): медиана %.2f (порог 3) -> %s' % (np.median(ratios),'PASS' if PN3 else 'FAIL'))
print('P-N4 (контроль по доступности): медиана %.2f (порог 2) -> %s'
      % (np.median(ctrl_ratios) if ctrl_ratios else -1,'PASS' if PN4 else 'FAIL'))
json.dump(dict(RES=RES,PN1=bool(PN1),PN2=bool(PN2),PN3=bool(PN3),PN4=bool(PN4),
               ratios=ratios,ctrl_ratios=ctrl_ratios), open('results_neu_001.json','w'), indent=1, default=float)
