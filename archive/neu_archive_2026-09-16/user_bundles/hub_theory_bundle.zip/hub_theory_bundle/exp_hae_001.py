# EXP-HAE-001: гипотеза Хемерса. Пререг: prereg_exp_hae_001.md
import json
import numpy as np, networkx as nx
from networkx.generators.atlas import graph_atlas_g
from collections import Counter
from math import comb, lgamma, log, exp

# P-H1: наш подсчёт на 7 вершинах (ВСЕ графы, как в литературе)
G7 = [g for g in graph_atlas_g() if g.number_of_nodes() == 7]
spec = [tuple(np.round(np.sort(np.linalg.eigvalsh(nx.to_numpy_array(g))), 6)) for g in G7]
c = Counter(spec)
cosp = sum(v for v in c.values() if v >= 2)
f7 = cosp/len(G7)
PH1 = abs(100*f7 - 10.5) <= 1.5
print('P-H1: наш подсчёт на 7 вершинах: %d коспектральных из %d = %.2f%% | литература 110/1044 = 10.54%% -> %s'
      % (cosp, len(G7), 100*f7, 'ПОПАЛ' if PH1 else 'МИМО'))

# данные литературы
gtot = {5:34, 6:156, 7:1044, 8:12346, 9:274668, 10:12005168, 11:1018997864, 12:165091172592}
cosp_lit = {5:2, 6:10, 7:110, 8:1722, 9:51039, 10:2560606, 11:215331676, 12:3106757248}
print('\nn    графов          с двойником     доля      S из модели дней рождения')
S_emp = {}
for n in sorted(gtot):
    f = cosp_lit[n]/gtot[n]
    S = -gtot[n]/log(1-f) if 0 < f < 1 else float('inf')
    S_emp[n] = S
    print('%-4d %-15d %-15d %6.2f%%   %.3e' % (n, gtot[n], cosp_lit[n], 100*f, S))

# P-H2: верхняя оценка ёмкости из границ на коэффициенты char-полинома
def log_capacity(n):
    # |a_k| <= C(n,k) * k^(k/2)  (оценка Хадамара на k x k миноры 0/1-матрицы)
    tot = 0.0
    for k in range(1, n+1):
        b = comb(n, k)*(k**(k/2) if k > 0 else 1)
        tot += log(2*b + 1)
    return tot
def log_graphs(n):
    return comb(n, 2)*log(2) - lgamma(n+1)
print('\nP-H2: рост ёмкости против роста населения')
print('n     log g(n)     log S_оценка   разность')
nstar = None
for n in range(5, 26):
    lg, ls = log_graphs(n), log_capacity(n)
    if n <= 14 or n % 5 == 0:
        print('%-5d %-12.2f %-14.2f %+.2f' % (n, lg, ls, ls-lg))
    if nstar is None and ls > lg: nstar = n
PH2 = nstar is not None and abs(nstar - 11) <= 3
print('пересечение при n* = %s | регистр. 11 ± 3 -> %s' % (nstar, 'ПОПАЛ' if PH2 else 'МИМО'))

# P-H3: структура против случайности
print('\nP-H3: наблюдаемая доля против чисто случайной модели с ёмкостью-оценкой')
ratios = []
for n in range(7, 12):
    f_obs = cosp_lit[n]/gtot[n]
    f_rand = 1 - exp(-exp(min(log_graphs(n) - log_capacity(n), 700)))
    r = f_obs/max(f_rand, 1e-300)
    ratios.append(r)
    print('  n=%d: наблюдаемая %.4f | случайная %.3e | отношение %.2e' % (n, f_obs, f_rand, r))
PH3 = min(ratios) >= 100
print('минимальное отношение %.2e -> %s' % (min(ratios), 'PASS' if PH3 else 'FAIL'))

# P-H4: проспективное предсказание для n = 13
lg13 = log_graphs(13)
g13 = exp(lg13)
print('\nP-H4: ПРОСПЕКТИВНОЕ предсказание для n = 13')
print('  графов на 13 вершинах ≈ %.3e (асимптотика; известное точное 5.05e13)' % g13)
# экстраполяция эмпирической ёмкости: log S(n) подгоняем квадратично по n
ns = np.array(sorted(S_emp)); ls = np.array([log(S_emp[n]) for n in ns])
A = np.vstack([ns**2, ns, np.ones(len(ns))]).T
q = np.linalg.lstsq(A, ls, rcond=None)[0]
lS13 = q[0]*169 + q[1]*13 + q[2]
f13 = 1 - exp(-exp(min(lg13 - lS13, 700)))
# оценка неопределённости: подгонка по n>=9 и по n>=8
def fit(nmin):
    m = ns >= nmin
    Am = np.vstack([ns[m]**2, ns[m], np.ones(m.sum())]).T
    qq = np.linalg.lstsq(Am, ls[m], rcond=None)[0]
    lS = qq[0]*169 + qq[1]*13 + qq[2]
    return 1 - exp(-exp(min(lg13 - lS, 700)))
alt = [fit(8), fit(9), fit(10)]
print('  экстраполяция ёмкости (квадратичная по n): log S(13) = %.2f против log g(13) = %.2f' % (lS13, lg13))
print('  предсказанная доля коспектральных на 13 вершинах: %.3f%%' % (100*f13))
print('  разброс по вариантам подгонки: %s' % ['%.3f%%' % (100*x) for x in alt])
PH4 = f13 < 0.01
print('  P-H4 (< 1%%): %s' % ('PASS' if PH4 else 'FAIL'))
json.dump(dict(f7_ours=f7, PH1=bool(PH1), S_emp={str(k): S_emp[k] for k in S_emp},
               nstar=nstar, PH2=bool(PH2), ratios=ratios, PH3=bool(PH3),
               f13=f13, alts=alt, PH4=bool(PH4)),
          open('results_hae_001.json','w'), indent=1, default=float)
