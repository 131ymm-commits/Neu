# EXP-HUB-001: спектральная сигнатура хаба. Seed=42.
import json, gzip, math, random
import xml.etree.ElementTree as ET
import numpy as np
import networkx as nx

random.seed(42); np.random.seed(42)
RES = {}

# ---------- метрики ----------
def crystal(G):
    U = nx.Graph(G)
    if U.number_of_nodes() < 3: return None
    C = U.subgraph(max(nx.connected_components(U), key=len))
    ev = np.sort(np.linalg.eigvalsh(nx.to_numpy_array(C)))[::-1]
    return float(ev[1] / ev[0]) if ev[0] > 0 else None

def neff_frac(G):
    U = nx.Graph(G)
    C = U.subgraph(max(nx.connected_components(U), key=len))
    A = nx.to_numpy_array(C)
    w, v = np.linalg.eigh(A)
    vec = np.abs(v[:, -1]); vec /= np.linalg.norm(vec)
    ne = 1.0 / float(np.sum(vec ** 4))
    return ne / C.number_of_nodes(), ne, C.number_of_nodes()

def btw_table(G, weight=None):
    b = nx.betweenness_centrality(G, weight=weight)
    s = sum(b.values()) or 1.0
    items = sorted(b.items(), key=lambda kv: -kv[1])
    return items, items[0][1] / s

def coverage_sets(G):
    dist = {a: d for a, d in nx.all_pairs_shortest_path_length(G)}
    nodes = list(G.nodes())
    ps = {}
    for h in nodes:
        dh = dist.get(h, {})
        s = set()
        for x, dx in dist.items():
            if x == h: continue
            dxh = dx.get(h)
            if dxh is None: continue
            for y, dxy in dx.items():
                if y == x or y == h: continue
                dhy = dh.get(y)
                if dhy is not None and dxh + dhy == dxy:
                    s.add((x, y))
        ps[h] = s
    return dist, ps

def rho_metrics(G):
    dist, ps = coverage_sets(G)
    # rho1: собственный знаменатель кандидата (пары без h)
    best_h, best_rho = None, -1.0
    for h, s in ps.items():
        tot = sum(1 for x, dx in dist.items() if x != h for y in dx if y != x and y != h)
        r = len(s) / tot if tot else 0.0
        if r > best_rho: best_rho, best_h = r, h
    # rho2: жадное покрытие, знаменатель = пары без обоих выбранных
    h1 = best_h
    best2, best_r2, chosen2 = None, -1.0, None
    for h2 in G.nodes():
        if h2 == h1: continue
        cov = {p for p in (ps[h1] | ps[h2]) if h1 not in p and h2 not in p}
        tot = sum(1 for x, dx in dist.items() if x not in (h1, h2)
                  for y in dx if y != x and y not in (h1, h2))
        r = len(cov) / tot if tot else 0.0
        if r > best_r2: best_r2, chosen2 = r, h2
    return best_h, best_rho, chosen2, best_r2

def profile(G, name, weight=None):
    m1 = crystal(G)
    m2, ne, ncc = neff_frac(G)
    items, top1 = btw_table(G, weight=weight)
    h, r1, h2, r2 = rho_metrics(G)
    out = dict(name=name, n=G.number_of_nodes(), m=G.number_of_edges(),
               M1_crystal=round(m1, 4), M2_neff_frac=round(m2, 4), N_eff=round(ne, 2),
               M3_top1_btw_share=round(top1, 4), btw_top5=[(k, round(v, 4)) for k, v in items[:5]],
               M4_rho1=round(r1, 4), hub=str(h), M5_rho2=round(r2, 4), hub2=str(h2))
    return out

# ---------- Стадия 0: синтетика ----------
synth = {}
synth['star'] = nx.star_graph(59)
synth['clique'] = nx.complete_graph(60)
synth['ring'] = nx.cycle_graph(60)
G = nx.gnm_random_graph(60, 120, seed=42)
synth['ER'] = G.subgraph(max(nx.connected_components(G), key=len)).copy()
synth['BA_m2'] = nx.barabasi_albert_graph(60, 2, seed=42)
G = nx.random_geometric_graph(60, 0.22, seed=42)
synth['RGG'] = G.subgraph(max(nx.connected_components(G), key=len)).copy()
synth['grid8x8'] = nx.convert_node_labels_to_integers(nx.grid_2d_graph(8, 8))
s1 = nx.star_graph(29)
s2 = nx.relabel_nodes(nx.star_graph(29), {i: i + 30 for i in range(30)})
ts = nx.union(s1, s2); ts.add_edge(0, 30)
synth['two_star'] = ts
RES['stage0'] = {k: profile(v, k) for k, v in synth.items()}

# ---------- Стадия 1: метаболизм ----------
def load_sbml(path):
    data = gzip.open(path, 'rb').read()
    root = ET.fromstring(data)
    ns = {'s': root.tag.split('}')[0].strip('{')}
    model = root.find('s:model', ns)
    mets = set()
    for sp in model.find('s:listOfSpecies', ns):
        if sp.get('boundaryCondition') == 'true': continue
        mets.add(sp.get('id'))
    G = nx.DiGraph(); n_rxn = 0
    for rx in model.find('s:listOfReactions', ns):
        rid = (rx.get('id') or '').upper()
        if 'EX_' in rid or 'BIOMASS' in rid: continue
        n_rxn += 1
        rev = rx.get('reversible') == 'true'
        lr = rx.find('s:listOfReactants', ns); lp = rx.find('s:listOfProducts', ns)
        R = [sr.get('species') for sr in lr] if lr is not None else []
        P = [sr.get('species') for sr in lp] if lp is not None else []
        for a in R:
            for b in P:
                if a in mets and b in mets and a != b:
                    G.add_edge(a, b)
                    if rev: G.add_edge(b, a)
    G = nx.relabel_nodes(G, {n: (n[2:] if n.startswith('M_') else n) for n in G.nodes()})
    return G, n_rxn

MET, n_rxn = load_sbml('textbook.xml.gz')
CURRENCY = set()
for base in ['h', 'h2o', 'atp', 'adp', 'amp', 'pi', 'ppi', 'nad', 'nadh',
             'nadp', 'nadph', 'co2', 'o2', 'nh4', 'q8', 'q8h2']:
    CURRENCY |= {base + '_c', base + '_e'}
cur_in_graph = sorted(CURRENCY & set(MET.nodes()))

full = profile(MET, 'metabolism_full')
MET_nc = MET.copy(); MET_nc.remove_nodes_from(cur_in_graph)
MET_nc = MET_nc.subgraph(max(nx.weakly_connected_components(MET_nc), key=len)).copy()
nocur = profile(MET_nc, 'metabolism_no_currency')
MET_nc2 = MET_nc.copy()
if 'coa_c' in MET_nc2: MET_nc2.remove_node('coa_c')
MET_nc2 = MET_nc2.subgraph(max(nx.weakly_connected_components(MET_nc2), key=len)).copy()
nocur2 = profile(MET_nc2, 'metabolism_no_currency_no_coa')

# top-10 полного графа и членство в валютах
items_full, _ = btw_table(MET)
top10 = [k for k, _ in items_full[:10]]
cur_top10 = sum(1 for k in top10 if k in CURRENCY)
atp_rank = [k for k, _ in items_full].index('atp_c') + 1 if 'atp_c' in MET else None

# нуль-модели: ER directed
n, m = MET.number_of_nodes(), MET.number_of_edges()
er_top1, er_rho1 = [], []
for i in range(50):
    H = nx.gnm_random_graph(n, m, seed=100 + i, directed=True)
    _, t1 = btw_table(H)
    er_top1.append(t1)
    if i < 20:
        _, r1, _, _ = rho_metrics(H)
        er_rho1.append(r1)
er_top1 = np.array(er_top1); er_rho1 = np.array(er_rho1)

# конфигурационная нуль-модель (эксплораторно)
cfg_top1 = []
for i in range(30):
    H = MET.copy()
    try:
        nx.directed_edge_swap(H, nswap=5 * m, max_tries=200 * m, seed=200 + i)
    except Exception:
        pass
    _, t1 = btw_table(H)
    cfg_top1.append(t1)
cfg_top1 = np.array(cfg_top1)

RES['stage1'] = dict(
    n_reactions_used=n_rxn, currency_present=cur_in_graph,
    full=full, no_currency=nocur, no_currency_no_coa=nocur2,
    P1a=dict(cur_in_top10=cur_top10, atp_rank=atp_rank, top10=top10),
    null_ER=dict(top1_mean=float(er_top1.mean()), top1_sd=float(er_top1.std()),
                 rho1_mean=float(er_rho1.mean()), rho1_sd=float(er_rho1.std()),
                 z_top1=float((full['M3_top1_btw_share'] - er_top1.mean()) / er_top1.std())),
    null_config=dict(top1_mean=float(cfg_top1.mean()), top1_sd=float(cfg_top1.std()),
                     z_top1=float((full['M3_top1_btw_share'] - cfg_top1.mean()) / (cfg_top1.std() or 1))))

# ---------- Стадия 2: энергия ----------
IND = [('chem','therm'),('chem','elec'),
       ('therm','mech'),('therm','elec'),('therm','light'),('therm','chem'),
       ('mech','elec'),('mech','therm'),('mech','elast'),('mech','grav'),
       ('elec','mech'),('elec','therm'),('elec','light'),('elec','chem'),
       ('light','elec'),('light','therm'),('light','chem'),
       ('nucl','therm'),('grav','mech'),('elast','mech')]
BIO = [('chem','mech'),('light','chem')]  # мышца; фотосинтез (light->chem уже есть индустриально — тогда без дубля)
MARG = [('chem','light'),('light','mech'),('nucl','elec'),('mech','light')]
ETA = {('chem','therm'):0.9,('chem','elec'):0.6,('therm','mech'):0.4,('therm','elec'):0.07,
       ('therm','light'):0.05,('therm','chem'):0.3,('mech','elec'):0.95,('mech','therm'):1.0,
       ('mech','elast'):0.9,('mech','grav'):0.85,('elec','mech'):0.9,('elec','therm'):1.0,
       ('elec','light'):0.5,('elec','chem'):0.7,('light','elec'):0.22,('light','therm'):0.9,
       ('light','chem'):0.05,('nucl','therm'):0.95,('grav','mech'):0.9,('elast','mech'):0.95,
       ('chem','mech'):0.25}

def eg(edges):
    g = nx.DiGraph(); g.add_edges_from(edges); return g

EA = eg(IND)
EB = eg(IND + [e for e in BIO if e not in IND])
EC = eg(list(EB.edges()) + [e for e in MARG if e not in EB.edges()])
EW = EB.copy()
for u, v in EW.edges():
    EW[u][v]['w'] = -math.log(ETA.get((u, v), 0.5))

pa = profile(EA, 'energy_A_industrial')
pb = profile(EB, 'energy_B_plus_bio')
pc = profile(EC, 'energy_C_plus_marginal')
items_w, top1w = btw_table(EW, weight='w')
# eigenvector centrality на неориентированной проекции A
evc = nx.eigenvector_centrality_numpy(nx.Graph(EA))
evc_rank = sorted(evc.items(), key=lambda kv: -kv[1])
RES['stage2'] = dict(A=pa, B=pb, C=pc,
                     eigenvector_A=[(k, round(v, 3)) for k, v in evc_rank],
                     weighted_B_btw=[(k, round(v, 4)) for k, v in items_w],
                     weighted_top1_share=round(top1w, 4))

# ---------- Стадия 3: контроли ----------
RES['stage3'] = dict(karate=profile(nx.karate_club_graph(), 'karate'))

with open('results_hub_001.json', 'w') as f:
    json.dump(RES, f, indent=1, ensure_ascii=False)

# компактный вывод
def row(p):
    return (f"{p['name']:<28} n={p['n']:<4} M1={p['M1_crystal']:<7} M2={p['M2_neff_frac']:<7} "
            f"M3={p['M3_top1_btw_share']:<7} rho1={p['M4_rho1']:<7} hub={p['hub']:<12} rho2={p['M5_rho2']}")
print("=== STAGE 0: калибровка ===")
for k in synth: print(row(RES['stage0'][k]))
print("\n=== STAGE 1: метаболизм ===")
for p in (full, nocur, nocur2): print(row(p))
print("top10 full:", top10)
print("currency in top10:", cur_top10, "| atp rank:", atp_rank)
print("btw top5 no_currency:", nocur['btw_top5'])
print("ER null top1: %.4f±%.4f  z=%.1f | rho1 null: %.3f±%.3f" %
      (er_top1.mean(), er_top1.std(), RES['stage1']['null_ER']['z_top1'], er_rho1.mean(), er_rho1.std()))
print("CFG null top1: %.4f±%.4f  z=%.1f" %
      (cfg_top1.mean(), cfg_top1.std(), RES['stage1']['null_config']['z_top1']))
print("\n=== STAGE 2: энергия ===")
for p in (pa, pb, pc): print(row(p))
print("eigenvector A:", RES['stage2']['eigenvector_A'])
print("weighted B btw:", RES['stage2']['weighted_B_btw'])
print("btw top5 A:", pa['btw_top5'])
print("\n=== STAGE 3 ===")
print(row(RES['stage3']['karate']))
