# EXP-NEU-002: глубина синтеза против времени сигнала. Пререг в отчёте (до счёта).
import json, re
import numpy as np, networkx as nx
import xml.etree.ElementTree as ET
from scipy.stats import spearmanr
T1B=['h','h2o','atp','adp','amp','pi','ppi','nad','nadh','nadp','nadph','co2','o2','nh4','fad','fadh2']
QUIN=re.compile(r'^(q\d+|q\d+h2|mqn\d+|mql\d+)$')
SCAF=['g6p','f6p','r5p','e4p','g3p','3pg','pep','pyr','accoa','akg','succoa','oaa']
def base(n):
    low=n.lower(); i=low.rfind('_'); return low[:i] if i>0 else low
def is_t1(n):
    b=base(n); return b in T1B or bool(QUIN.match(b))
def load(p):
    root=ET.fromstring(open(p,'rb').read()); ns={'s':root.tag.split('}')[0].strip('{')}
    mo=root.find('s:model',ns)
    mets={sp.get('id') for sp in mo.find('s:listOfSpecies',ns) if sp.get('boundaryCondition')!='true'}
    G=nx.DiGraph()
    for rx in mo.find('s:listOfReactions',ns):
        rid=(rx.get('id') or '').upper()
        if 'EX_' in rid or 'BIOMASS' in rid: continue
        rev=rx.get('reversible')=='true'
        lr=rx.find('s:listOfReactants',ns); lp=rx.find('s:listOfProducts',ns)
        R=[x.get('species') for x in lr] if lr is not None else []
        P=[x.get('species') for x in lp] if lp is not None else []
        for a in R:
            for b in P:
                if a in mets and b in mets and a!=b:
                    G.add_edge(a,b)
                    if rev: G.add_edge(b,a)
    return nx.relabel_nodes(G,{n:(n[2:] if n.startswith('M_') else n) for n in G.nodes()})

# глубина усредняется по четырём организмам (устойчивее одной модели)
targets={'glu_dash_l':'глутамат','asp_dash_l':'аспартат','gly':'глицин','4abut':'ГАМК',
         'ser_dash_l':'серин','tyr_dash_l':'тирозин','trp_dash_l':'триптофан','his_dash_l':'гистидин'}
acc={k:[] for k in targets}
for path in ['iND750.xml','iNJ661.xml','iIT341.xml','iAF692.xml']:
    G=load(path); H=G.copy(); H.remove_nodes_from([v for v in G if is_t1(v)])
    H=H.subgraph(max(nx.weakly_connected_components(H),key=len)).copy()
    S=nx.DiGraph(); S.add_nodes_from(H.nodes()); S.add_edges_from(H.edges()); S.add_node('SRC')
    for v in H:
        if base(v) in SCAF: S.add_edge('SRC',v)
    d=nx.single_source_shortest_path_length(S,'SRC')
    for k in targets:
        cand=[d[v]-1 for v in H if base(v)==k and v in d]
        if cand: acc[k].append(min(cand))
depth={k:(float(np.mean(v)) if v else None) for k,v in acc.items()}
print('вычисленная глубина синтеза (среднее по 4 организмам):')
for k,nm in targets.items():
    print('  %-12s %-12s %s' % (k, nm, ('%.2f'%depth[k]) if depth[k] is not None else 'нет'))

# добавка известных шагов (учебная биохимия, фиксирована до счёта)
EXTRA={'дофамин':('tyr_dash_l',2),'норадреналин':('tyr_dash_l',3),'серотонин':('trp_dash_l',2),
       'гистамин':('his_dash_l',1)}
# времена действия (фармакология, фиксированы до счёта), секунды
TAU={'глутамат':1e-3,'аспартат':1e-3,'глицин':2e-3,'ГАМК':5e-3,
     'дофамин':1.0,'норадреналин':1.0,'серотонин':1.0,'гистамин':1.0}
rows=[]
for k,nm in targets.items():
    if nm in TAU and depth[k] is not None: rows.append((nm, depth[k], TAU[nm]))
for nm,(src,ext) in EXTRA.items():
    if depth[src] is not None: rows.append((nm, depth[src]+ext, TAU[nm]))
rows.sort(key=lambda r: r[1])
print('\nпередатчик      глубина синтеза   время действия, с')
for nm,d,t in rows: print('  %-14s %-17.2f %.0e' % (nm,d,t))
D=np.array([r[1] for r in rows]); L=np.log10([r[2] for r in rows])
print('\nПРОВЕРКА РАЗРЕШЕНИЯ (запись №46):')
print('  глубина: диапазон %.2f–%.2f, различных значений %d' % (D.min(),D.max(),len(set(np.round(D,2)))))
print('  время:   диапазон %.0e–%.0e, порядков %.1f' % (10**L.min(),10**L.max(),L.max()-L.min()))
ok=(D.max()/D.min()>=2) and (L.max()-L.min()>=2)
print('  обе меры имеют разрешение: %s' % ok)
rho,p=spearmanr(D,L)
print('\nСпирмен(глубина синтеза, log времени действия) = %+.3f (p = %.4f), n = %d' % (rho,p,len(rows)))
print('вердикт (порог 0.8): %s' % ('PASS' if rho>=0.8 else 'FAIL'))
json.dump(dict(depth=depth, rows=[[a,float(b),float(c)] for a,b,c in rows],
               rho=float(rho), p=float(p), resolution_ok=bool(ok)),
          open('results_neu_002.json','w'), indent=1, ensure_ascii=False)
