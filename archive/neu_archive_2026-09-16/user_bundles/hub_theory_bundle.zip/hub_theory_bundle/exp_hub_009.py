# EXP-HUB-009: клиентурный механизм. Seed=42. Пререг: prereg_exp_hub_009.md
import json
import numpy as np, networkx as nx
from scipy.stats import spearmanr

exec(open('exp_hub_008.py').read().split("# ---- iNJ661")[0])  # load_sbml, tiers_of и др.

def ranks(G):
    b = nx.betweenness_centrality(G)
    order = sorted(b, key=lambda v: -b[v])
    return {v: i + 1 for i, v in enumerate(order)}

def frac_to_tier(G, tier):
    T = set(tier)
    out = {}
    for v in G:
        deg = G.in_degree(v) + G.out_degree(v)
        if deg == 0: out[v] = 0.0; continue
        k = sum(1 for u in G.predecessors(v) if u in T) + \
            sum(1 for u in G.successors(v) if u in T)
        out[v] = k / deg
    return out

RES = {}
for name, path in [('iIT341', 'iIT341.xml'), ('iAF692', 'iAF692.xml'),
                   ('iND750', 'iND750.xml'), ('iNJ661', 'iNJ661.xml')]:
    G0 = load_sbml(path)
    t1, t2, t3 = tiers_of(G0)
    def cut(G, rem):
        H = G.copy(); H.remove_nodes_from(rem)
        return H.subgraph(max(nx.weakly_connected_components(H), key=len)).copy()
    G1 = cut(G0, t1); G2 = cut(G1, t2); G3 = cut(G2, t3)
    res = {}
    for lab, (Ga, Gb, T) in dict(
            tier1=(G0, G1, t1), tier3=(G2, G3, t3)).items():
        ra, rb = ranks(Ga), ranks(Gb)
        f = frac_to_tier(Ga, T)
        common = [v for v in Gb if v in ra]
        dr = [rb[v] - ra[v] for v in common]
        fv = [f[v] for v in common]
        rho, p = spearmanr(dr, fv)
        res[lab] = dict(n=len(common), rho=float(rho), p=float(p))
        print('%s %s: n=%d rho=%+.3f p=%.1e' % (name, lab, len(common), rho, p))
    RES[name] = res

def verdict(lab, need_med=None):
    ok = sum(1 for r in RES.values() if r[lab]['rho'] > 0 and r[lab]['p'] < 1e-4)
    med = float(np.median([r[lab]['rho'] for r in RES.values()]))
    return ok, med

ok1, med1 = verdict('tier1')
ok3, med3 = verdict('tier3')
P91 = ok1 >= 3
P92 = ok3 >= 3
P93 = med1 >= 0.2
kill = sum(1 for r in RES.values() if r['tier1']['rho'] <= 0) >= 3
print('P9.1: %d/4 ->' % ok1, 'PASS' if P91 else 'FAIL',
      '| P9.2: %d/4 ->' % ok3, 'PASS' if P92 else 'FAIL',
      '| P9.3: median rho(Я1)=%.3f ->' % med1, 'PASS' if P93 else 'FAIL',
      '| kill:', 'FIRED' if kill else 'no')
json.dump(dict(RES=RES, P91=bool(P91), P92=bool(P92), P93=bool(P93),
               med1=med1, med3=med3, kill=bool(kill)),
          open('results_hub_009.json', 'w'), indent=1, ensure_ascii=False)
