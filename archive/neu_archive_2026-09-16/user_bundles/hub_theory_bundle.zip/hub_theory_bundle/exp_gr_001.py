# EXP-GR-001: этаж действия калибровочной группы. Seed=42. Пререг: prereg_exp_gr_001.md
import json, itertools
import numpy as np

def proj_rank(mats, n):
    P = sum(mats)/len(mats)
    return int(np.linalg.matrix_rank(P, tol=1e-10)), P

rows = []
print('N   базовая C_N   базовая S_N   слоевая U(1)^N   косинус с единичным')
for N in range(3, 13):
    I = np.eye(N)
    # базовая группа: циклические сдвиги (перестановка МЕТОК узлов)
    CN = [np.roll(I, k, axis=0) for k in range(N)]
    rC, PC = proj_rank(CN, N)
    # базовая группа: полная симметрическая (для N<=7 явно, иначе генераторы+усреднение)
    if N <= 7:
        SN = [I[list(p)] for p in itertools.permutations(range(N))]
    else:
        rng = np.random.default_rng(42)
        SN = [I[list(rng.permutation(N))] for _ in range(4000)] + CN
    rS, _ = proj_rank(SN, N)
    # слоевая группа: U(1) на каждом узле действует ВНУТРИ слоя,
    # на функционалы от узловых величин действует тождественно
    FIB = [I]
    rF, _ = proj_rank(FIB, N)
    # P-R3: направление выжившего инварианта
    w, V = np.linalg.eigh(PC)
    inv = V[:, np.argmax(w)]
    ones = np.ones(N)/np.sqrt(N)
    cos = abs(float(inv @ ones))
    rows.append((N, rC, rS, rF, cos))
    print('%-3d %-13d %-13d %-16d %.12f' % (N, rC, rS, rF, cos))

PR1 = all(r[1] == 1 and r[2] == 1 for r in rows)
PR2 = all(r[3] == r[0] for r in rows)
PR3 = all(abs(r[4]-1) < 1e-12 for r in rows)
print('\nP-R1 (базовая факторизация → ранг 1):', 'PASS' if PR1 else 'FAIL')
print('P-R2 (слоевая факторизация → ранг N):', 'PASS' if PR2 else 'FAIL')
print('P-R3 (выживший заряд равномерный):', 'PASS' if PR3 else 'FAIL')
print('\nизмеренный ранг решётки зарядов СМ (PHYS-001/002): 5 локальных, 6 с цветом')
print('ранг локальных зарядов после калибровки базы: 1 — и он глобальный, не локальный')

# ---- P-R4: арифметика стыка ----
print('\n=== P-R4(a): где гравитация становится сильной ===')
MPL = 1.220890e19           # ГэВ
MZ, ASMZ = 91.1876, 0.1179
def as_run(mu, nf=6):
    b0 = (33-2*nf)/(12*np.pi)
    return ASMZ/(1 + 2*b0*ASMZ*np.log(mu/MZ))
aem = 1/128.0
E_em = MPL*np.sqrt(aem)
print('  α_G(E) = E²/M_Pl²;  α_G = α_em(1/128) при E = %.3e ГэВ' % E_em)
E = MPL*1e-3
for _ in range(200):
    f = (E/MPL)**2 - as_run(E)
    d = 2*E/MPL**2 + 0.0
    E = E*np.exp(-0.3*np.sign(f)*abs(f)/max(abs((E/MPL)**2), 1e-30))
    if abs(f) < 1e-6: break
print('  α_G = α_s(E) при E ≈ %.3e ГэВ  (α_s там = %.4f)' % (E, as_run(E)))
print('  вывод: «ставка обмена» гравитации догоняет калибровочные при E ~ 10¹⁸ ГэВ')

print('\n=== P-R4(b): два несовместимых способа счёта состояний ===')
HBARC = 1.973269804e-16     # ГэВ·м
LP = 1.616255e-35           # м
H0_INV = 1.37e26            # м, хаббловский радиус
print('  КТП (объёмный счёт):     N ~ (L/ℓ_UV)³')
print('  гравитация (площадной):  N ≤ A/4ℓ_P² ~ (L/ℓ_P)²')
print('  совместимость требует:   L ≤ ℓ_UV³/ℓ_P²   (энтропийная форма)')
for name, Lam in [('1 ТэВ', 1e3), ('1 ГэВ', 1.0), ('1 МэВ', 1e-3)]:
    l_uv = HBARC/Lam
    Lmax = l_uv**3/LP**2
    print('    обрез %-6s → ℓ_UV = %.2e м → область валидности L ≤ %.2e м' % (name, l_uv, Lmax))
# энергетическая форма CKN: L³Λ⁴ ≤ L·M_Pl²  →  Λ ≤ (M_Pl/L)^{1/2}
L_gev = H0_INV/HBARC
Lam_max = np.sqrt(MPL/L_gev)
print('  энергетическая форма (Cohen–Kaplan–Nelson 1999, приоритет чужой):')
print('    Λ ≤ (M_Pl/L)^(1/2); при L = 1/H₀ = %.2e ГэВ⁻¹ → Λ ≤ %.3e ГэВ = %.2f мэВ'
      % (L_gev, Lam_max, Lam_max*1e12))
rho = (Lam_max*1e12)  # в мэВ
obs = 2.3
print('    наблюдаемый масштаб тёмной энергии ≈ %.1f мэВ; отношение %.2f' % (obs, rho/obs))
PR4 = 1.0 <= rho <= 10.0
print('  P-R4: обрез в диапазоне 1–10 мэВ ->', 'PASS' if PR4 else 'FAIL')

json.dump(dict(rows=rows, PR1=bool(PR1), PR2=bool(PR2), PR3=bool(PR3),
               E_em=float(E_em), E_as=float(E), lam_meV=float(rho), PR4=bool(PR4)),
          open('results_gr_001.json','w'), indent=1, default=float)
