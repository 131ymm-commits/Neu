# EXP-LEV-003: ACTIVSg2000. Seed=42. Пререґ: prereg_exp_lev_003_004.md
import re, json
import numpy as np, networkx as nx
from scipy import sparse
from scipy.sparse.linalg import eigs

rng = np.random.default_rng(42)

def read_block(path, name):
    txt = open(path).read()
    m = re.search(r'mpc\.' + name + r'\s*=\s*\[(.*?)\];', txt, re.S)
    rows = []
    for line in m.group(1).strip().splitlines():
        line = line.split('%')[0].strip().rstrip(';')
        if line:
            rows.append([float(x) for x in line.split()])
    return np.array(rows)

bus = read_block('case_ACTIVSg2000.m', 'bus')
br = read_block('case_ACTIVSg2000.m', 'branch')
ids = bus[:, 0].astype(int)
area = bus[:, 6].astype(int)
kv = bus[:, 9]
G = nx.Graph()
G.add_nodes_from(ids)
for row in br:
    if row[10] > 0:
        G.add_edge(int(row[0]), int(row[1]))
G.remove_edges_from(nx.selfloop_edges(G))
G = G.subgraph(max(nx.connected_components(G), key=len)).copy()
nodes = sorted(G.nodes()); idx = {v: i for i, v in enumerate(nodes)}; n = len(nodes)
amap = dict(zip(ids, area)); kmap = dict(zip(ids, kv))
lab_zone = np.array([str(amap[v]) for v in nodes])
lab_volt = np.array([str(kmap[v]) for v in nodes])
print('LCC: %d шин, %d ветвей | зон: %d | классы кВ: %s' %
      (n, G.number_of_edges(), len(set(lab_zone)),
       sorted(set(lab_volt), key=float)))
from collections import Counter
print('распределение кВ:', dict(Counter(lab_volt)))

A = sparse.lil_matrix((n, n))
for u, v in G.edges():
    A[idx[u], idx[v]] = 1.0; A[idx[v], idx[u]] = 1.0
A = A.tocsr()
deg = np.asarray(A.sum(axis=1)).ravel()
P = sparse.diags(1.0 / deg) @ A
PL = 0.5 * (sparse.identity(n) + P)

def eps_mean(labels):
    classes = sorted(set(labels)); ci = {c: j for j, c in enumerate(classes)}
    M = sparse.lil_matrix((n, len(classes)))
    for i, l in enumerate(labels): M[i, ci[l]] = 1.0
    Agg = np.asarray((P @ M.tocsr()).todense())
    tw, tot = 0.0, 0.0
    for c in classes:
        ids_ = np.where(labels == c)[0]
        if len(ids_) < 2: continue
        npairs = min(2000, len(ids_) * (len(ids_) - 1) // 2)
        a = rng.choice(ids_, npairs); b = rng.choice(ids_, npairs); ok = a != b
        if not ok.any(): continue
        d = 0.5 * np.abs(Agg[a[ok]] - Agg[b[ok]]).sum(axis=1).mean()
        tot += d * len(ids_); tw += len(ids_)
    return tot / tw

def null_D(labels, reps=50):
    e = eps_mean(labels)
    nulls = np.array([eps_mean(rng.permutation(labels)) for _ in range(reps)])
    return e, nulls, (e - nulls.mean()) / nulls.std()

ez, nz, Dz = null_D(lab_zone)
ev_, nv, Dv = null_D(lab_volt)
P_G1 = ez < nz.min()
P_G2 = Dz < Dv
print('eps(зоны)=%.4f min(null)=%.4f D=%.1f | eps(кВ)=%.4f min(null)=%.4f D=%.1f'
      % (ez, nz.min(), Dz, ev_, nv.min(), Dv))
print('P-G1', 'PASS' if P_G1 else 'FAIL', '| P-G2 (D_zone < D_volt)',
      'PASS' if P_G2 else 'FAIL')

bt = nx.betweenness_centrality(G)
top50 = [k for k, _ in sorted(bt.items(), key=lambda kv_: -kv_[1])[:50]]
hi = max((c for c in set(lab_volt) if (lab_volt == c).sum() >= 20), key=float)
share_all = (lab_volt == hi).mean()
share_top = np.mean([str(kmap[v]) == hi for v in top50])
enrich = share_top / share_all
P_G3 = enrich >= 3
print('высший класс %s кВ: доля узлов %.3f, доля в top-50 btw %.2f, обогащение x%.1f | P-G3 %s'
      % (hi, share_all, share_top, enrich, 'PASS' if P_G3 else 'FAIL'))

pi = np.ones(n) / n
for _ in range(3000):
    pi = np.asarray(pi @ PL).ravel(); pi /= pi.sum()

def tau_of(f, tmax=300):
    f = f - (pi * f).sum(); c0 = (pi * f * f).sum()
    if c0 <= 0: return 0.0
    g = f.copy()
    for t in range(1, tmax + 1):
        g = np.asarray(PL @ g).ravel()
        if (pi * f * g).sum() / c0 < np.exp(-1): return float(t)
    return float(tmax)

tz = [tau_of((lab_zone == c).astype(float)) for c in set(lab_zone)]
tv = [tau_of((lab_volt == c).astype(float)) for c in set(lab_volt)]
tr = [tau_of(rng.standard_normal(n)) for _ in range(100)]
mz, mv, mr = np.median(tz), np.median(tv), np.median(tr)
P_G4 = mz > mv and mz > mr
print('tau медианы: зоны=%.1f кВ-слои=%.1f случайные=%.1f | P-G4 %s'
      % (mz, mv, mr, 'PASS' if P_G4 else 'FAIL'))
print('tau зон:', sorted(np.round(tz, 1), reverse=True))
print('tau кВ-слоёв:', dict(zip(sorted(set(lab_volt), key=float),
      [round(tau_of((lab_volt == c).astype(float)), 1) for c in sorted(set(lab_volt), key=float)])))

json.dump(dict(n=n, m=G.number_of_edges(),
               eps=dict(zone=float(ez), zone_null_min=float(nz.min()), Dz=float(Dz),
                        volt=float(ev_), volt_null_min=float(nv.min()), Dv=float(Dv),
                        P_G1=bool(P_G1), P_G2=bool(P_G2)),
               hub_layer=dict(hi_kv=hi, share_all=float(share_all),
                              share_top50=float(share_top), enrich=float(enrich), P_G3=bool(P_G3)),
               tau=dict(zone=float(mz), volt=float(mv), rand=float(mr), P_G4=bool(P_G4))),
          open('results_lev_003.json', 'w'), indent=1)
