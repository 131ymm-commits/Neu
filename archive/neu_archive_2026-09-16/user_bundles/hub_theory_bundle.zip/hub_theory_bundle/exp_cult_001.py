# EXP-CULT-001: анализ. Seed=42. Пререг: prereg_exp_cult_001.md
import json
import numpy as np, networkx as nx
from scipy import sparse
from collections import Counter

rng = np.random.default_rng(42)
agg = json.load(open('cult_agg.json'))
fam = agg['fam']
def unpack(d):
    c = Counter()
    for k, v in d.items():
        a, b = k.split('||')
        c[(a, b)] += v
    return c
bor, inh = unpack(agg['bor']), unpack(agg['inh'])
don = Counter(agg['don'])

TOP5 = [x for x, _ in don.most_common(5)]
REG = {'Latin', 'French', 'English', 'Ancient Greek', 'German'}
PC1 = len(set(TOP5) & REG) >= 4 and don.most_common(1)[0][0] in {'Latin', 'French', 'English'}
kill = len(set([x for x, _ in don.most_common(3)]) & REG) == 0
print('топ-5 доноров:', TOP5, '| P-C1', 'PASS' if PC1 else 'FAIL', '| kill:', 'FIRED' if kill else 'no')

is_proto = lambda x: x.startswith('Proto-')
def simple_graph(cnt, thr=5):
    u = Counter()
    for (a, b), v in cnt.items():
        u[tuple(sorted((a, b)))] += v
    G = nx.Graph()
    for (a, b), v in u.items():
        if v >= thr: G.add_edge(a, b, w=v)
    return G
GB, GI = simple_graph(bor), simple_graph(inh)
print('слой заимствований: %d узлов %d рёбер | наследования: %d узлов %d рёбер'
      % (GB.number_of_nodes(), GB.number_of_edges(), GI.number_of_nodes(), GI.number_of_edges()))

vol_ok = sum(v for (a, b), v in bor.items()
             if a in fam and b in fam and not is_proto(a) and not is_proto(b))
gate = vol_ok / sum(bor.values())
print('шлюз: доля объёма между разрешёнными непрото = %.2f ->' % gate,
      'PASS' if gate >= 0.6 else 'LIMIT')

def layer_eps(G, reps=30):
    H = G.subgraph([v for v in G if v in fam and not is_proto(v)])
    H = H.subgraph(max(nx.connected_components(H), key=len)).copy()
    nodes = sorted(H.nodes()); idx = {v: i for i, v in enumerate(nodes)}; n = len(nodes)
    fams = Counter(fam[v] for v in nodes)
    big = {f for f, k in fams.items() if k >= 10}
    lab = np.array([fam[v] if fam[v] in big else 'OTHER' for v in nodes])
    r = [idx[a] for a, b in H.edges()] + [idx[b] for a, b in H.edges()]
    c = [idx[b] for a, b in H.edges()] + [idx[a] for a, b in H.edges()]
    A = sparse.csr_matrix((np.ones(len(r), np.float32), (r, c)), shape=(n, n))
    deg = np.asarray(A.sum(1)).ravel(); deg[deg == 0] = 1
    P = sparse.diags((1/deg).astype(np.float32)) @ A
    def eps(labels):
        classes = sorted(set(labels)); ci = {x: j for j, x in enumerate(classes)}
        li = np.array([ci[x] for x in labels])
        M = sparse.csr_matrix((np.ones(n, np.float32), (np.arange(n), li)),
                              shape=(n, len(classes)))
        Agg = np.asarray((P @ M).todense())
        tot = tw = 0.0
        for x in classes:
            ids = np.where(labels == x)[0]
            if len(ids) < 2: continue
            m = min(2000, len(ids)*(len(ids)-1)//2)
            aa = rng.choice(ids, m); bb = rng.choice(ids, m); ok = aa != bb
            if not ok.any(): continue
            d = 0.5*np.abs(Agg[aa[ok]]-Agg[bb[ok]]).sum(1).mean()
            tot += d*len(ids); tw += len(ids)
        return tot/tw
    e = eps(lab)
    nulls = np.array([eps(rng.permutation(lab)) for _ in range(reps)])
    D = (e - nulls.mean())/nulls.std()
    return n, len(big), e, nulls.min(), D, (H, nodes, lab, P)

nB, kB, eB, nmB, DB, packB = layer_eps(GB)
nI, kI, eI, nmI, DI, _ = layer_eps(GI)
print('заимствования: n=%d семей>=10: %d eps=%.4f min(null)=%.4f D=%.1f' % (nB, kB, eB, nmB, DB))
print('наследование:  n=%d семей>=10: %d eps=%.4f min(null)=%.4f D=%.1f' % (nI, kI, eI, nmI, DI))
PC2a = DI < DB
PC2b = eB < nmB
print('P-C2a (D_inh < D_bor):', 'PASS' if PC2a else 'FAIL',
      '| P-C2b (семьи — модули рынка):', 'PASS' if PC2b else 'FAIL')

# P-C3: tau на полном слое заимствований (прото включены)
GL = GB.subgraph(max(nx.connected_components(GB), key=len)).copy()
nodes = sorted(GL.nodes()); idx = {v: i for i, v in enumerate(nodes)}; n = len(nodes)
r = [idx[a] for a, b in GL.edges()] + [idx[b] for a, b in GL.edges()]
c = [idx[b] for a, b in GL.edges()] + [idx[a] for a, b in GL.edges()]
A = sparse.csr_matrix((np.ones(len(r), np.float32), (r, c)), shape=(n, n))
deg = np.asarray(A.sum(1)).ravel(); deg[deg == 0] = 1
PL = (0.5*(sparse.identity(n, dtype=np.float32) + sparse.diags((1/deg).astype(np.float32)) @ A)).tocsr()
pi = np.ones(n, np.float32)/n
for _ in range(2000):
    pi = np.asarray(pi @ PL).ravel(); pi /= pi.sum()
def tau_batch(F, tmax=300):
    F = F - (pi @ F); c0 = (pi[:, None]*F*F).sum(0)
    out = np.full(F.shape[1], float(tmax)); G = F.copy(); alive = np.ones(F.shape[1], bool)
    for t in range(1, tmax+1):
        G = np.asarray(PL @ G); cc = (pi[:, None]*F*G).sum(0)
        cr = alive & (cc/np.maximum(c0, 1e-12) < np.exp(-1))
        out[cr] = t; alive &= ~cr
        if not alive.any(): break
    return out
fams_here = Counter(fam[v] for v in nodes if v in fam and not is_proto(v))
bigf = sorted(f for f, k in fams_here.items() if k >= 10)
Ff = np.stack([np.array([1.0 if (v in fam and fam[v] == f and not is_proto(v)) else 0.0
                         for v in nodes], np.float32) for f in bigf], 1)
tf = tau_batch(Ff)
trd = tau_batch(rng.standard_normal((n, 50)).astype(np.float32))
mf, mr = np.median(tf), np.median(trd)
PC3 = mf >= 3*mr
print('P-C3: tau семей медиана %.1f (n=%d) vs случайные %.1f ->' % (mf, len(bigf), mr),
      'PASS' if PC3 else 'FAIL')
print('самые медленные семьи:', sorted(zip(np.round(tf, 1), bigf), reverse=True)[:6])

H = GL.copy(); H.remove_nodes_from([v for v in TOP5 if v in H])
R = len(max(nx.connected_components(H), key=len))/n if H.number_of_edges() else 0
PC4 = R >= 0.5
print('P-C4: R после удаления топ-5 доноров = %.3f ->' % R, 'PASS' if PC4 else 'FAIL')

json.dump(dict(top5=TOP5, PC1=bool(PC1), kill=bool(kill), gate=float(gate),
               layers=dict(bor=[nB, kB, float(eB), float(nmB), float(DB)],
                           inh=[nI, kI, float(eI), float(nmI), float(DI)]),
               PC2a=bool(PC2a), PC2b=bool(PC2b),
               tau=[float(mf), float(mr)], PC3=bool(PC3),
               slow_fams=[[float(a), b] for a, b in sorted(zip(tf, bigf), reverse=True)[:6]],
               R=float(R), PC4=bool(PC4)),
          open('results_cult_001.json', 'w'), indent=1, ensure_ascii=False)
