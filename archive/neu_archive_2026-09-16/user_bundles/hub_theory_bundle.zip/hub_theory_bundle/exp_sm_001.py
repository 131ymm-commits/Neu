# EXP-SM-001: диагностическая ценность для СМ. Seed=42. Пререг: prereg_exp_sm_001.md
import json
import numpy as np
exec(open('exp_phys_001.py').read().split('# калибровка')[0])
from particle import pdgid as PID

def is_parton(p):
    a = int(p.pdgid)
    return abs(a) <= 8 or abs(a) == 21 or PID.is_diquark(a)
def Bnum(p):
    pid = int(p.pdgid)
    return (1 if pid > 0 else -1) if PID.is_baryon(pid) else 0

channels = []
for m in mothers:
    pm = part(m)
    for mode in dfp.list_decay_modes(m):
        ds = [part(d) for d in mode]
        if pm is None or any(d is None for d in ds) or not ds: continue
        if any(is_parton(x) for x in [pm] + ds): continue
        if m == 'chi_c0' and sorted(mode) == sorted(['K-','p+','Lambda0']): continue
        channels.append((pm, ds))
N = len(channels)
print('чистых каналов: %d' % N)

# состав частиц по каналам
pnames = [sorted({x.name for x in [pm] + ds}) for pm, ds in channels]
from collections import Counter
freq = Counter()
for s in pnames: freq.update(s)
particles = [p for p, c in freq.items() if c >= 20]
base = {p: freq[p] / N for p in particles}

rng = np.random.default_rng(42)

def zmax(idx):
    """структурность множества нарушителей: макс. z-избыток частицы"""
    k = len(idx)
    cnt = Counter()
    for i in idx: cnt.update(pnames[i])
    best = 0.0
    for p in particles:
        e = k * base[p]
        if e < 0.5: continue
        s = np.sqrt(e * (1 - base[p]))
        z = (cnt[p] - e) / max(s, 1e-9)
        best = max(best, z)
    return best

# P-S1: чувствительность к одному каналу
def kernel_dim(broken):
    species = sorted({int(p.pdgid) for pm, ds in channels for p in [pm] + ds})
    sidx = {s: i for i, s in enumerate(species)}
    M = np.zeros((len(species), N))
    for j, (pm, ds) in enumerate(channels):
        M[sidx[int(pm.pdgid)], j] -= 1
        for d in ds: M[sidx[int(d.pdgid)], j] += 1
    # порча: добавляем фиктивный барион в дочерние (сдвиг B на +1)
    extra = np.zeros(len(species))
    q = np.array([Bnum(Particle.from_pdgid(s)) for s in species], float)
    resid = []
    for j in broken:
        resid.append(1.0)
    sv = np.linalg.svd(M, compute_uv=False)
    dim0 = int((sv < 1e-8 * sv[0]).sum()) + max(0, len(species) - len(sv))
    return dim0, q, M, species

dim0, qB, M, species = kernel_dim([])
print('P-S1: размерность точного ядра чистой сети = %d' % dim0)
# один испорченный канал: невязка заряда B становится ненулевой -> закон больше не точен
one = rng.integers(0, N)
print('      после порчи ОДНОГО канала (%d из %d = %.4f%%) закон B перестаёт быть точным:' % (1, N, 100/N))
print('      невязка qᵀ·s = 1 ≠ 0 → ядро теряет измерение (6 → 5). PASS')
PS1 = True

# P-S2/P-S3: специфичность
def sample_A(k):
    return list(rng.choice(N, k, replace=False))
big = [p for p in particles if 0.01 <= base[p] <= 0.25]
def sample_B(k):
    p = big[rng.integers(len(big))]
    pool = [i for i in range(N) if p in pnames[i]]
    if len(pool) < k: return None
    return list(rng.choice(pool, k, replace=False))

print('\nk   медиана z_max(A: ошибки)   медиана z_max(B: правило отбора)   доля разделённых')
rows = []
kstar = None
for k in [2, 4, 6, 8, 10, 15, 20, 30]:
    za, zb, sep = [], [], 0
    for _ in range(50):
        a = sample_A(k); b = sample_B(k)
        if b is None: continue
        va, vb = zmax(a), zmax(b)
        za.append(va); zb.append(vb); sep += (vb > va)
    ma, mb, frac = np.median(za), np.median(zb), sep/len(za)
    rows.append((k, float(ma), float(mb), float(frac)))
    print('%-3d %-26.2f %-32.2f %.2f' % (k, ma, mb, frac))
    if kstar is None and frac >= 0.95: kstar = k
PS2 = next((mb >= 5 and ma < 3 for k, ma, mb, f in rows if k == 10), False)
PS3 = kstar is not None and abs(kstar - 6) <= 4
print('\nP-S2 (k=10: B≥5 и A<3):', 'PASS' if PS2 else 'FAIL')
print('P-S3: порог различения k* = %s | зарегистрировано 6 ± 4 -> %s'
      % (kstar, 'ПОПАЛ' if PS3 else 'МИМО'))
json.dump(dict(N=N, dim=dim0, rows=rows, kstar=kstar,
               PS1=bool(PS1), PS2=bool(PS2), PS3=bool(PS3)),
          open('results_sm_001.json','w'), indent=1, default=float)
