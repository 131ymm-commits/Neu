# EXP-PHYS-003: ядерный уровень. Seed=42. Пререг: prereg_exp_phys_003.md
import re, json, math
import numpy as np, networkx as nx
import radioactivedecay as rd
import periodictable as pt

M_H, M_N, U2KEV = 1.00782503207, 1.00866491588, 931494.10242

def parse(nm):
    m = re.match(r'^([A-Za-z]+)-(\d+)([a-z]*)$', nm)
    sym, A, meta = m.group(1), int(m.group(2)), m.group(3)
    Z = pt.elements.symbol(sym).number
    return sym, Z, A, meta

nucs = list(rd.DEFAULTDATA.nuclides)
edges = []            # (parent, daughter, mode, bf)
half = {}
for nm in nucs:
    n = rd.Nuclide(str(nm))
    half[str(nm)] = n.half_life('s')
    for mode, d, bf in zip(n.decay_modes(), n.progeny(), n.branching_fractions()):
        if d == 'SF': continue
        edges.append((str(nm), d, mode, bf))
nodes = sorted({a for a, b, _, _ in edges} | {b for a, b, _, _ in edges})
info = {v: parse(v) for v in nodes}
print('нуклидов-узлов: %d, переходов: %d' % (len(nodes), len(edges)))

grading, other = [], []
for a, b, mode, bf in edges:
    dA = info[b][2] - info[a][2]
    (grading if dA in (0, -4) else other).append((a, b, mode, bf))
from collections import Counter
print('градуировочных: %d | вне градуировки: %d, моды:' % (len(grading), len(other)),
      Counter(m for _, _, m, _ in other))

# P-N1: тяжёлая область, компоненты, чистота A mod 4, стоки
heavy = {v for v in nodes if info[v][2] >= 200}
GH = nx.DiGraph()
GH.add_nodes_from(heavy)
GH.add_edges_from((a, b) for a, b, _, _ in grading if a in heavy and b in heavy)
comps = list(nx.weakly_connected_components(GH))
mixed = []
sinks_by_res = {}
for comp in comps:
    res = {info[v][2] % 4 for v in comp}
    if len(res) > 1: mixed.append(comp)
    else:
        r = res.pop()
        for v in comp:
            if GH.out_degree(v) == 0:
                sinks_by_res.setdefault(r, set()).add(v)
print('компонент в тяжёлой области: %d | смешанных по A mod 4: %d' % (len(comps), len(mixed)))
for r in sorted(sinks_by_res):
    print('  класс 4n+%d: стоки =' % r, sorted(sinks_by_res[r]))
want = {0: {'Pb-208'}, 1: {'Bi-209', 'Tl-205'}, 2: {'Pb-206'}, 3: {'Pb-207'}}
big_sink = {}
for r in range(4):
    cand = sinks_by_res.get(r, set())
    # терминал класса: сток компоненты, содержащей самый долгоживущий/крупный ряд
    big_sink[r] = cand
PN1 = (len(mixed) == 0 and all(want[r] & sinks_by_res.get(r, set()) for r in range(4)))
print('P-N1:', 'PASS' if PN1 else 'FAIL')

# P-N2: лестница K_tau + чистота на каждом уровне
taus = [10.0**k for k in range(-6, 27)]
curve = []
pure_all = True
allV = sorted(nodes)
for t in taus:
    G = nx.Graph(); G.add_nodes_from(allV)
    G.add_edges_from((a, b) for a, b, _, _ in grading if half.get(a, math.inf) < t)
    ncomp = nx.number_connected_components(G)
    curve.append(ncomp)
    GHt = G.subgraph(heavy)
    for comp in nx.connected_components(GHt):
        if len({info[v][2] % 4 for v in comp}) > 1:
            pure_all = False
print('rank(K_tau): %d (t=1мкс) -> %d (t=1e19лет) | чистота на всех уровнях: %s'
      % (curve[0], curve[-1], pure_all))
PN2 = pure_all

# P-N3: долина как канонический представитель
Zstar = lambda A: A / (1.98 + 0.0155 * A ** (2 / 3))
tot = imp = 0
for a, b, mode, bf in grading:
    Za, Aa = info[a][1], info[a][2]
    Zb = info[b][1]
    if Aa != info[b][2] or Za == Zb: continue  # только бета/EC
    tot += 1
    if abs(Zb - Zstar(Aa)) < abs(Za - Zstar(Aa)): imp += 1
share = imp / tot
PN3 = share >= 0.95
print('P-N3: к долине %d/%d = %.3f ->' % (imp, tot, share), 'PASS' if PN3 else 'FAIL')

# P-N4: монотон масс (Q > 0), допуск -10 кэВ
def mass_of(v):
    sym, Z, A, meta = info[v]
    try:
        m = pt.elements.symbol(sym)[A].mass
        return float(m) if m else None
    except Exception:
        return None
viol, checked, nomass, meta_viol = [], 0, 0, 0
for a, b, mode, bf in edges:
    ma, mb = mass_of(a), mass_of(b)
    if ma is None or mb is None: nomass += 1; continue
    dA = info[b][2] - info[a][2]
    if dA == -4:
        Q = (ma - mb - pt.He[4].mass) * U2KEV
    elif dA == 0 and info[a][1] != info[b][1]:
        if info[b][1] == info[a][1] - 1 and 'β+' in mode and 'EC' not in mode:
            Q = (ma - mb) * U2KEV - 2 * 510.999
        else:
            Q = (ma - mb) * U2KEV
    elif dA == 0:
        continue  # IT: массы основного состояния неинформативны
    else:
        Q = None
    if Q is None: continue
    checked += 1
    if Q < -10:
        if info[a][3]: meta_viol += 1
        else: viol.append((a, b, mode, round(Q, 1)))
print('P-N4: проверено %d, без масс %d, нарушений (осн. сост.) %d, метастабильных %d'
      % (checked, nomass, len(viol), meta_viol))
for v in viol[:6]: print('   ', v)
PN4 = len(viol) == 0
print('P-N4:', 'PASS' if PN4 else 'FAIL')

# P-N5: пик энергии связи
best = []
for el in pt.elements:
    if el.number == 0: continue
    for iso in el:
        try:
            m = iso.mass
        except Exception:
            continue
        A, Z = iso.isotope, el.number
        if not m or A < 2: continue
        B = (Z * M_H + (A - Z) * M_N - m) * 931.49410242 / A
        best.append((B, '%s-%d' % (el.symbol, A)))
best.sort(reverse=True)
top3 = [nm for _, nm in best[:3]]
PN5 = set(top3) <= {'Ni-62', 'Fe-58', 'Fe-56'}
print('P-N5: топ-3 B/A:', [(nm, round(b, 4)) for b, nm in best[:3]], '->',
      'PASS' if PN5 else 'FAIL')

# P-N6: воронки тяжёлого DAG
bt = nx.betweenness_centrality(GH)
top10 = sorted(bt, key=bt.get, reverse=True)[:10]
PN6 = all(81 <= info[v][1] <= 94 for v in top10)
print('P-N6 top-10 воронок:', [(v, round(bt[v], 3)) for v in top10])
print('P-N6:', 'PASS' if PN6 else 'FAIL')

json.dump(dict(nodes=len(nodes), edges=len(edges), grading=len(grading),
               other=dict(Counter(m for _, _, m, _ in other)),
               comps=len(comps), mixed=len(mixed),
               sinks={str(r): sorted(s) for r, s in sinks_by_res.items()},
               PN1=bool(PN1), curve=curve, PN2=bool(PN2),
               valley=[imp, tot, share], PN3=bool(PN3),
               q=dict(checked=checked, nomass=nomass, viol=viol, meta=meta_viol),
               PN4=bool(PN4), top3_BA=top3, PN5=bool(PN5),
               funnels=[[v, float(bt[v])] for v in top10], PN6=bool(PN6)),
          open('results_phys_003.json', 'w'), indent=1, ensure_ascii=False)

import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.figure(figsize=(6, 3.4))
plt.semilogx(taus, curve, 'o-')
plt.xlabel('порог наблюдения τ, с'); plt.ylabel('rank(K_τ) = число компонент')
plt.title('Лестница зарядов ядерного домена', fontsize=10)
plt.tight_layout(); plt.savefig('fig_phys_003.png', dpi=150)
print('fig ok')
